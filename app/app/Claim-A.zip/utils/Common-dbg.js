sap.ui.define([
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/core/Fragment",
    "sap/ui/core/BusyIndicator",
    "claima/model/models",
    "claima/utils/ClaimUtility",
    "claima/utils/Constants",
    "claima/utils/CustomValidator",
    "claima/utils/DateUtility",
    "claima/utils/RequestUtility",
    "claima/utils/Utility"
], function (MessageBox, MessageToast, Fragment, BusyIndicator, Models, ClaimUtility, Constants, CustomValidator, DateUtility, RequestUtility, Utility) {
	"use strict";

	return {
        /**
         * Initialize the Utility 
         * @public
         * @param {object} oOwnerComponent Caller component for accessing models
         * @param {object} oView View instance of caller
         */
        init: function (oOwnerComponent, oView) {
            this._oOwnerComponent = oOwnerComponent;
            this._oView = oView;

            this._aHeaderConfiguration = {
                [Constants.SubmissionTypePrefix.CLAIMHEADER]: {
                    pageId: "page_claimsubmission",
                    fragmentPath: "claima.fragment",
                    fragmentCache: "_oClaimFragments",
                    display: "claimsubmission_summary_claimheader",
                    edit: "claimsubmission_summary_claimheader_edit"
                },
                [Constants.SubmissionTypePrefix.REQUESTHEADER]: {
                    pageId: "request_form",
                    fragmentPath: "claima.fragment",
                    fragmentCache: "_oRequestFragments",
                    display: "request_header",
                    edit: "request_header_edit"
                }
            };
        },

        /**
         * Save header details for Claim Submission or Pre Approved Request
         * @public
         * @param {string} sClaimType claim type to be saved: Claim Submission or Pre Approved Request
         */
        saveHeader: async function (sClaimType) {
            const oODataModel = this._oOwnerComponent.getModel();
            var oInputModel = null;
            switch(sClaimType) {
                case Constants.SubmissionTypePrefix.REQUESTHEADER:
                    oInputModel = this._oView.getModel("request");

                    if ( DateUtility.getHanaDate(oInputModel.getProperty("/req_header/tripstartdate")) && DateUtility.getHanaDate(oInputModel.getProperty("/req_header/tripenddate")) ) {
                        try {
                            BusyIndicator.show(0);

                            const sReqID = oInputModel.getProperty("/req_header/reqid");
                            if (!sReqID) {
                                MessageBox.error(Utility.getText("msg_error_missing_claim_id"));
                                return;
                            }

                            CustomValidator.init(this._oOwnerComponent, this._oView);
                            if ( !await CustomValidator.validate(Constants.SubmissionTypePrefix.REQUESTHEADER) ) {
                                return;
                            }

                            // Cash advance is not allowed when the trip start date is in the past
                            if ( !this.validateCashAdvanceTripStartDate(oInputModel) ) {
                                return;
                            }

                            // Bind to existing claim header
                            const oContext = await RequestUtility.getReqHeader(oODataModel, sReqID);

                            const dLastModifiedDate = DateUtility.getHanaDate(new Date());

                            oContext.setProperty("LAST_MODIFIED_DATE", dLastModifiedDate);
                            oContext.setProperty("REMARK",
                                oInputModel.getProperty("/req_header/comment")
                            );
                            oContext.setProperty("LOCATION",
                                oInputModel.getProperty("/req_header/location")
                            );
                            oContext.setProperty("ALTERNATE_COST_CENTER",
                                oInputModel.getProperty("/req_header/altcostcenter")
                            );
                             oContext.setProperty("PROJECT_CODE",
                                oInputModel.getProperty("/req_header/projectcode")
                            );
                            oContext.setProperty("TRIP_START_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/req_header/tripstartdate"))
                            );
                            oContext.setProperty("TRIP_END_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/req_header/tripenddate"))
                            );
                            oContext.setProperty("EVENT_START_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/req_header/eventstartdate"))
                            );
                            oContext.setProperty("EVENT_END_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/req_header/eventenddate"))
                            );
                            oContext.setProperty("PAYMENT_DUE_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/req_header/cccduedate"))
                            );

                            var oProject = this._oView.byId("select_request_project_code");

                            if (oProject && oProject.getSelectedItem()) {

                                var oProjectData =
                                    oProject.getSelectedItem()
                                        .getBindingContext("employee_view")
                                        .getObject();

                                oInputModel.setProperty("/req_header/projectdesc",  oProjectData.PROJECT_DESC);
                            }

                            await oODataModel.submitBatch("$auto");

                            const oController =this._oView.getController();
                            await this.editHeaderChange(Constants.SubmissionTypePrefix.REQUESTHEADER, !this._oView.getModel("editButtonModel").getProperty("/state"));
                            MessageToast.show(
                                Utility.getText("msg_claimheader_updated", [sReqID])
                            );

                        } catch (oError) {
                            MessageToast.show(
                                Utility.getText("msg_claimsubmission_failed")
                            );
                        } finally {
                            BusyIndicator.hide();
                        }
                    }	
                    else {
                        BusyIndicator.hide();
                        MessageBox.error(Utility.getText("req_d_w_mandatory_field"));
                    }
                    break;

                case Constants.SubmissionTypePrefix.CLAIMHEADER:
                    oInputModel = this._oView.getModel("claimsubmission_input");

                    if ( DateUtility.getHanaDate(oInputModel.getProperty("/claim_header/trip_start_date")) && DateUtility.getHanaDate(oInputModel.getProperty("/claim_header/trip_end_date")) ) {
                        try {
                            BusyIndicator.show(0);

                            const sClaimId = oInputModel.getProperty("/claim_header/claim_id");
                            if (!sClaimId) {
                                MessageBox.error(Utility.getText("msg_error_missing_claim_id"));
                                return;
                            }

                            CustomValidator.init(this._oOwnerComponent, this._oView);
                            if ( !await CustomValidator.validate(Constants.SubmissionTypePrefix.CLAIMHEADER) ) {
                                return;
                            }

                            // Bind to existing claim header
                            const oContext = await ClaimUtility.getClaimHeader(oODataModel, sClaimId);
                            
                            const dLastModifiedDate = DateUtility.getHanaDate(new Date());

                            oContext.setProperty("LAST_MODIFIED_DATE", dLastModifiedDate);
                            oContext.setProperty("COMMENT",
                                oInputModel.getProperty("/claim_header/comment")
                            );
                            oContext.setProperty("LOCATION",
                                oInputModel.getProperty("/claim_header/location")
                            );
                            oContext.setProperty("ALTERNATE_COST_CENTER",
                                oInputModel.getProperty("/claim_header/alternate_cost_center")
                            );
                            oContext.setProperty("PROJECT_CODE",
                                oInputModel.getProperty("/claim_header/project_code")
                            );
                            oContext.setProperty("TRIP_START_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/claim_header/trip_start_date"))
                            );
                            oContext.setProperty("TRIP_END_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/claim_header/trip_end_date"))
                            );
                            oContext.setProperty("EVENT_START_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/claim_header/event_start_date"))
                            );
                            oContext.setProperty("EVENT_END_DATE",
                                DateUtility.getHanaDate(oInputModel.getProperty("/claim_header/event_end_date"))
                            );

                            var oProject = this._oView.byId("select_claimsummary_project_code");

                            if (oProject && oProject.getSelectedItem()) {

                                var oProjectData =
                                    oProject.getSelectedItem()
                                        .getBindingContext("employee_view")
                                        .getObject();

                                oInputModel.setProperty("/claim_header/descr/project_code",oProjectData.PROJECT_DESC);
                            }

                            await oODataModel.submitBatch("$auto");
                
                            // Update all claim item cost centers after header save
                            var itemCc =
                                oInputModel.getProperty("/claim_header/alternate_cost_center") ||
                                oInputModel.getProperty("/claim_header/cost_center") ||
                                null;
         
                            var aClaimItems = oInputModel.getProperty("/claim_items") || [];

                            for (let i = 0; i < aClaimItems.length; i++) {

                                const oItem = aClaimItems[i];

                                const sDefaultChargingCostCenter =
                                    await Utility.getDefaultChargingCostCenter(
                                        oODataModel,
                                        oItem.claim_type_id,
                                        oItem.claim_type_item_id
                                    );

                                if (sDefaultChargingCostCenter) {
                                    oInputModel.setProperty("/claim_items/" + i + "/cost_center",sDefaultChargingCostCenter);
                                } else {
                                    oInputModel.setProperty("/claim_items/" + i + "/cost_center",itemCc);
                                }
                            }

                            //calling from claim submission controller to update claim items after header save
                            const oController = this._oView.getController();
                            await oController._updateClaimItems();

                            await this.editHeaderChange(Constants.SubmissionTypePrefix.CLAIMHEADER, !this._oView.getModel("editButtonModel").getProperty("/state"));
                            MessageToast.show(
                                Utility.getText("msg_claimheader_updated", [sClaimId])
                            );

                        } catch (oError) {
                            MessageToast.show(
                                Utility.getText("msg_claimsubmission_failed")
                            );
                        } finally {
                            BusyIndicator.hide();
                        }
                    }	
                    else {
                        BusyIndicator.hide();
                        MessageBox.error(Utility.getText("req_d_w_mandatory_field"));
                    }
                    break;
            }
		},

		/**
		 * Whether the request has a cash-advance item — either already saved, or
		 * currently being created/edited with the cash-advance switch on.
		 * @public
         * @param {sap.ui.model.json.JSONModel} oReqModel the "request" model
         * @returns {boolean}
		 */
		hasCashAdvanceItem: function (oReqModel) {
			const aReqItems = oReqModel.getProperty("/req_item_rows") || [];
			// CASH_ADVANCE is a Boolean on the item entity, but the employee view
			// exposes it as "YES"/"NO", so accept both shapes.
			const bSavedCashAdvanceItem = aReqItems.some((oItem) =>
				oItem.CASH_ADVANCE === true || String(oItem.CASH_ADVANCE).toUpperCase() === "YES"
			);

			// Only count the item form's switch while the form is actually open
			const sView = oReqModel.getProperty("/view");
			const bItemFormOpen = sView === Constants.PARMode.CREATE || sView === Constants.PARMode.EDIT;
			const bInProgressCashAdvance = bItemFormOpen && !!oReqModel.getProperty("/req_item/cash_advance");

			return bSavedCashAdvanceItem || bInProgressCashAdvance;
		},

		/**
		 * Whether the header's trip start date is before today.
		 * Compares local YYYY-MM-DD strings (the same conversion used when the
		 * header is saved) so time-of-day can't skew the result.
		 * @public
         * @param {sap.ui.model.json.JSONModel} oReqModel the "request" model
         * @returns {boolean}
		 */
		isTripStartDateBackdated: function (oReqModel) {
			const sTripStart = DateUtility.getHanaDate(oReqModel.getProperty("/req_header/tripstartdate"));
			const sToday = DateUtility.getHanaDate(new Date());
			return !!sTripStart && sTripStart < sToday;
		},

		/**
		 * Cash advance is not allowed for a backdated trip. If the request has a
		 * cash-advance item and the header's trip start date is before today,
		 * show an error and report that the header must not be saved.
		 * @public
         * @param {sap.ui.model.json.JSONModel} oReqModel the "request" model
         * @returns {boolean} true if the header may be saved, false if blocked
		 */
		validateCashAdvanceTripStartDate: function (oReqModel) {
			if (this.hasCashAdvanceItem(oReqModel) && this.isTripStartDateBackdated(oReqModel)) {
				MessageBox.error(Utility.getText("msg_cash_advance_not_allow"));
				return false;
			}
			return true;
		},

		/**
		 * Set fields to be editable
		 * if there is a request tied to claim, do not allow editing for start and end trip dates
		 * if there is a default cost center tied to claim type, do not allow editing for alternate cost center
		 * @public
         * @param {string} sClaimType Claim submission or Pre Approval Request claim type
		 * @param {boolean} bEdit edit toggle
		 */
		setHeaderEditable: async function (sClaimType , bEdit) {
            ClaimUtility.init(this._oOwnerComponent, this._oView);
            switch(sClaimType) {
                case Constants.SubmissionTypePrefix.CLAIMHEADER:
                    const oClaimModel = this._oView.getModel("claimsubmission_input");
                    var oEditableFields = this._oView.getModel("claimSubmissionHeaderEditableModel");
                    if (bEdit) {
                        oEditableFields.setProperty("/startTrip", !bEdit);
                        oEditableFields.setProperty("/endTrip", !bEdit);
                        oEditableFields.setProperty("/altCostCenter", !bEdit)
                        oEditableFields.setProperty("/startEvent", !bEdit);
                        oEditableFields.setProperty("/endEvent", !bEdit);
                        oEditableFields.setProperty("/location", !bEdit);
                        oEditableFields.setProperty("/comment", !bEdit);
                        oEditableFields.setProperty("/saveHeader", !bEdit);

                        if(oClaimModel.getProperty("/claim_header/request_id")){
                            RequestUtility.init(this._oOwnerComponent, this._oView);
                            const oRequestData = await RequestUtility.getPARHeaderInfo(oClaimModel.getProperty("/claim_header/request_id"));
                            if (!oRequestData.tripStart) {
                                oEditableFields.setProperty("/startTrip", bEdit);
                            }
                            if (!oRequestData.tripEnd) {
                                oEditableFields.setProperty("/endTrip", bEdit);
                            }
                            if (!oRequestData.eventStart) {
                                oEditableFields.setProperty("/startEvent", bEdit);
                            }
                            if (!oRequestData.eventEnd) {
                                oEditableFields.setProperty("/endEvent", bEdit);
                            }
                            if (!oRequestData.altcc) {
                                const sDefaultCostCenter = await ClaimUtility.determineDefaultCostCenter(oClaimModel.getProperty("/claim_header/claim_type_id"))
                                if ( !sDefaultCostCenter && sDefaultCostCenter != null ){
                                    oEditableFields.setProperty("/altCostCenter", bEdit);
                                }
                            }
                        } else {
                            oEditableFields.setProperty("/startTrip", bEdit);
                            oEditableFields.setProperty("/endTrip", bEdit);
                            oEditableFields.setProperty("/startEvent", bEdit);
                            oEditableFields.setProperty("/endEvent", bEdit);
                            const sDefaultCostCenter = await ClaimUtility.determineDefaultCostCenter(oClaimModel.getProperty("/claim_header/claim_type_id"))
                            if ( !sDefaultCostCenter && sDefaultCostCenter != null ){
                                oEditableFields.setProperty("/altCostCenter", bEdit);
                            }
                        }

                        oEditableFields.setProperty("/location", bEdit);
                        oEditableFields.setProperty("/comment", bEdit);
                      
                        const sAltCC = oClaimModel.getProperty("/claim_header/alternate_cost_center");
                        const sProjectCode = oClaimModel.getProperty("/claim_header/project_code");
                        const bHasAltCC = sAltCC !== null && sAltCC !== undefined && String(sAltCC).trim() !== "";
                        const bHasProjectCode = sProjectCode !== null && sProjectCode !== undefined && String(sProjectCode).trim() !== "";
                        // Project Code editable only when Alt CC is blank
                        const bProjectCodeDropdown = bEdit && !bHasAltCC;

                        oEditableFields.setProperty("/projectCode", bProjectCodeDropdown);

                        // Alt CC editable only when Project Code is blank
                        if (bHasProjectCode) {
                            oEditableFields.setProperty("/altCostCenter", false);
                        }
                        oEditableFields.setProperty("/saveHeader", bEdit);
                    }
                    else {	
                        oEditableFields.setData(Models.createClaimHeaderEditableModel().getData(), bEdit);
                    }
                    break;
                case Constants.SubmissionTypePrefix.REQUESTHEADER:
                    const oReqModel = this._oView.getModel("request");
                    var oEditableFields = this._oView.getModel("reqHeaderEditableModel");
                    const sReqTypeID = oReqModel.getProperty("/req_header/reqtypeid");
                    if (bEdit) {
                        oEditableFields.setProperty("/startEvent", !bEdit);
                        oEditableFields.setProperty("/endEvent", !bEdit);
                        oEditableFields.setProperty("/startEventRequired", !bEdit);
                        oEditableFields.setProperty("/endEventRequired", !bEdit);
                        oEditableFields.setProperty("/startTrip", !bEdit);
                        oEditableFields.setProperty("/endTrip", !bEdit);
                        oEditableFields.setProperty("/location", !bEdit);
                        oEditableFields.setProperty("/altCostCenter", !bEdit);
                        oEditableFields.setProperty("/comment", !bEdit);
                        oEditableFields.setProperty("/saveHeader", !bEdit);

                        if ( sReqTypeID == Constants.RequestType.TRAVEL || sReqTypeID == Constants.RequestType.CORP_CC ) {
                            oEditableFields.setProperty("/startEvent", bEdit);
                            oEditableFields.setProperty("/endEvent", bEdit);
                            RequestUtility.init(this._oOwnerComponent, this._oView);
                            if (await RequestUtility.getEventDateRequired(sReqTypeID)) {
                                oEditableFields.setProperty("/startEventRequired", bEdit);
                                oEditableFields.setProperty("/endEventRequired", bEdit);
                            }
                        }
                        if ( sReqTypeID == Constants.RequestType.TRAVEL || sReqTypeID == Constants.RequestType.REIMBURSEMENT || sReqTypeID == Constants.RequestType.CORP_CC ) {
                            oEditableFields.setProperty("/startTrip", bEdit);
                            oEditableFields.setProperty("/endTrip", bEdit);
                            oEditableFields.setProperty("/location", bEdit);
                            const sDefaultCostCenter = await ClaimUtility.determineDefaultCostCenter(oReqModel.getProperty("/req_header/claimtype"))
                            if ( !sDefaultCostCenter && sDefaultCostCenter != null ){
                                oEditableFields.setProperty("/altCostCenter", bEdit);
                            }
                        }

                        oEditableFields.setProperty("/comment", bEdit);
                        
                        const sAltCC = oReqModel.getProperty("/req_header/altcostcenter");
                        const sProjectCode = oReqModel.getProperty("/req_header/projectcode");
                        const bHasAltCC = sAltCC !== null && sAltCC !== undefined && String(sAltCC).trim() !== "";
                        const bHasProjectCode = sProjectCode !== null && sProjectCode !== undefined && String(sProjectCode).trim() !== "";
                        // Project Code editable only when Alt CC is blank
                        const bProjectCodeDropdown = bEdit && !bHasAltCC;

                        oEditableFields.setProperty("/projectCode", bProjectCodeDropdown);

                        // Alt CC editable only when Project Code is blank
                        if (bHasProjectCode) {
                            oEditableFields.setProperty("/altCostCenter", false);
                        }
                        oEditableFields.setProperty("/saveHeader", bEdit);
                    }
                    else {
                        oEditableFields.setData(Models.createClaimHeaderEditableModel().getData(), bEdit);
                    }
                    break;
            }
		},

        /**
		 * Function for Edit button press
		 * 1. Swaps button state
		 * 2. Display fragment based on toggle
		 * 3. Enable or disable header fields to be editable
         * @public
         * @param {string} sClaimType claim type PAR or claim submission
		 * @param {boolean} bEdit toggle for edit or display
		 */
		editHeaderChange: async function (sClaimType, bEdit) {
            const oButtonModel = this._oView.getModel("editButtonModel");
			oButtonModel.setProperty("/state", bEdit);		
			await this._toggleHeaderFragment(sClaimType, bEdit);
            await this.setHeaderEditable(sClaimType, bEdit);
		},

        /**
         * Switch between editable and display fragments
         * @param {string} sClaimType claim type to apply toggle, claim submission or Pre Approval request
         * @param {boolean} bEdit editable state
         * @returns 
         */
        _toggleHeaderFragment: async function (sClaimType, bEdit) {
            const oHeaderConfiguration = this._aHeaderConfiguration[sClaimType];
            if (!oHeaderConfiguration) return;

            const oSubmissionTypePage = this._oView.byId(oHeaderConfiguration.pageId);
            const sLoadFragment = bEdit ? oHeaderConfiguration.edit : oHeaderConfiguration.display;
            const sDestroyFragment = bEdit ? oHeaderConfiguration.display : oHeaderConfiguration.edit;

            await this._removeFragment(oHeaderConfiguration, sDestroyFragment, oSubmissionTypePage);
            const oFragment = await this._loadFragment(oHeaderConfiguration, sLoadFragment);

            oSubmissionTypePage.insertContent(oFragment, 0);
        },

        /**
         * Remove fragment from display
         * @param {object} oHeaderConfiguration details of header to be removed
         * @param {string} sDestroyFragment name of fragment to be removed
         * @param {object} oSubmissionTypePage ID of page to remove fragment from
         * @returns 
         */
        _removeFragment: async function (oHeaderConfiguration, sDestroyFragment, oSubmissionTypePage) {
            const oController = this._oView.getController();
            const oCache = oController[oHeaderConfiguration.fragmentCache];
            const oFragment = oCache?.[sDestroyFragment];
            if (!oFragment) return;

            const oResolved = await oFragment;
            oSubmissionTypePage.removeContent(oResolved);
            oResolved.destroy(true);
            delete oCache[sDestroyFragment];
        },

        /**
         * Load header fragment for display
         * @param {object} oHeaderConfiguration details of header to be loaded
         * @param {string} sLoadFragment name of fragment to be loaded
         * @returns 
         */
        _loadFragment: async function (oHeaderConfiguration, sLoadFragment) {
            const oView = this._oView;
            const oController = this._oView.getController();
            const oCache = oController[oHeaderConfiguration.fragmentCache];

            if (!oCache[sLoadFragment]) {
                oCache[sLoadFragment] = Fragment.load({
                    id: oView.getId(),
                    name: `${oHeaderConfiguration.fragmentPath}.${sLoadFragment}`,
                    type: "XML",
                    controller: oController
                }).then(oFragment => {
                    oView.addDependent(oFragment);
                    return oFragment;
                });
            }

            return oCache[sLoadFragment];
        },

	}
});