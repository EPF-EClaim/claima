// claima/utils/ApproveDialog.js
sap.ui.define([
  "sap/ui/model/json/JSONModel",
  "sap/m/Dialog",
  "sap/m/Button",
  "sap/m/Label",
  "sap/m/Text",
  "sap/m/TextArea",
  "sap/ui/layout/form/SimpleForm"
], function (JSONModel, Dialog, Button, Label, Text, TextArea, SimpleForm) {
  "use strict";

  function ensureModels(oController) {
    const oView = oController.getView();

    // Reject (form data)
    let oReject = oView.getModel("Reject");
    if (!oReject) {
      oReject = new JSONModel({ approvalComment: "" });
      oView.setModel(oReject, "Reject");
    } else if (!oReject.getData()) {
      oReject.setData({ mode: "APPROVED", approvalComment: "" });
    }
    //Default
    oReject.setData(Object.assign({
      mode: "APPROVE",
      approvalComment: "",
    }, oReject.getData() || {}), true);

    // Type (UI state)
    let oType = oView.getModel("Type");
    if (!oType) {
      oType = new JSONModel({ mode: "" });
      oView.setModel(oType, "Type");
    } else if (!oType.getData()) {
      oType.setData({ mode: "" });
    }
  }

  function createApproveDialog(oController) {
    const oView = oController.getView();

    const oForm = new SimpleForm(oView.createId("approver_approve_form"), {
      editable: true,
      layout: "ResponsiveGridLayout",
      labelSpanXL: 2, labelSpanL: 2, labelSpanM: 2, labelSpanS: 12,
      adjustLabelSpan: true,
      emptySpanXL: 0, emptySpanL: 0, emptySpanM: 0, emptySpanS: 0,
      columnsXL: 2, columnsL: 2, columnsM: 2,
      content: [
        // Request fields
        new Label({ text: "{i18n>purpose}", visible: "{= ${Type>/mode} === 'APPROVE_REQ' }" }),
        new Text({ text: "{request>/req_header/purpose}", visible: "{= ${Type>/mode} === 'APPROVE_REQ' }", wrapping: false }),
        new Label({ text: "{i18n>preappreq_id}", visible: "{= ${Type>/mode} === 'APPROVE_REQ' }" }),
        new Text({ text: "{request>/req_header/reqid}", visible: "{= ${Type>/mode} === 'APPROVE_REQ' }", wrapping: false }),

        // Claim fields
        new Label({ text: "{i18n>purpose}", visible: "{= ${Type>/mode} === 'APPROVE_CLAIM' }" }),
        new Text({ text: "{claimsubmission_input>/claim_header/purpose}", visible: "{= ${Type>/mode} === 'APPROVE_CLAIM' }", wrapping: false }),
        new Label({ text: "{i18n>label_claimsummary_claimheader_claimid}", visible: "{= ${Type>/mode} === 'APPROVE_CLAIM' }" }),
        new Text({ text: "{claimsubmission_input>/claim_header/claim_id}", visible: "{= ${Type>/mode} === 'APPROVE_CLAIM' }", wrapping: false }),

        // Approval comment (always visible)
        new Label({ text: "{i18n>approval_remarks}"}),
        new TextArea(oView.createId("approvalCommentArea"), {
          value: "{Reject>/approvalComment}",
          width: "100%",
          growing: true,
          growingMaxLines: 5,
          placeholder: "{i18n>approval_comment_placeholder}"
        })
      ]
    });

    const cancelHandler =
      oController.onClickCancel_app ||
      function () { this._approveDialog && this._approveDialog.close(); };

    const fnCreateHandler =
      (oController.onClickCreate_app || oController.onApproveRequest).bind(oController);


    const oDialog = new Dialog({
      title: "{i18n>approve_claim}",
      contentWidth: "50%",
      content: [oForm],
      beginButton: new Button(oView.createId("approver_placeholder_cancel"), {
        text: "{i18n>req_b_cancel}",
        press: cancelHandler.bind(oController)
      }),
      endButton: new Button(oView.createId("approver_placeholder_create"), {
        text: "{i18n>approve_btn}",
        type: sap.m.ButtonType.Emphasized,
        press: fnCreateHandler.bind(oController)
      })
    });

    oDialog.addStyleClass("requestDialog");
    oView.addDependent(oDialog);
    return oDialog;
  }

  function getOrCreate(oController) {
    // Ensure both models exist BEFORE creating controls
    ensureModels(oController);
    if (!oController._approveDialog) {
      oController._approveDialog = createApproveDialog(oController);
    }
    return oController._approveDialog;
  }

  return {
    open: function (oController) {
      const oDlg = getOrCreate(oController);

      // Title per mode
      try {
        const rb = oController.getOwnerComponent().getModel("i18n").getResourceBundle();
        const mode = oController.getView().getModel("Type").getProperty("/mode");
        oDlg.setTitle(mode === "APPROVE_REQ" ? rb.getText("approve_request") : rb.getText("approve_claim"));
      } catch (e) { /* ignore */ }

      oDlg.open();
      return oDlg;
    }
  };
});
