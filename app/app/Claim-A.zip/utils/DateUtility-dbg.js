sap.ui.define([
    "sap/ui/core/format/DateFormat",
    "claima/utils/Constants",
    "claima/utils/Utility"
], function (
    DateFormat,
    Constants,
    Utility
) {
    "use strict";

    /**
     * Converts a date value (Date object, timestamp or 'yyyy-MM-dd' string) to a new Date at local midnight.
     * 'yyyy-MM-dd' strings are parsed as local dates (not UTC) to avoid off-by-one days.
     * Module-level on purpose: the min/max date formatters are invoked with the controller as `this`.
     * @private
     * @param {string|Date|number} vDate input date
     * @returns {Date|null} local date at 00:00:00.000, or null if empty/invalid
     */
    function _toLocalDate(vDate) {
        if (!vDate) return null;

        var dDate;
        if (typeof vDate === "string" && /^\d{4}-\d{2}-\d{2}/.test(vDate)) {
            var aParts = vDate.substring(0, 10).split("-").map(Number);
            dDate = new Date(aParts[0], aParts[1] - 1, aParts[2]);
        } else {
            dDate = new Date(vDate);
            dDate.setHours(0, 0, 0, 0);
        }

        return isNaN(dDate.getTime()) ? null : dDate;
    }

    return {

        /**
         * Pad numbers with leading zeros
         */
        pad: function (nNumber, iWidth = 2) {
            return String(nNumber).padStart(iWidth, "0");
        },

        /**
         * Format date using a custom or default pattern
         */
        formatDate: function (vDate, sPattern) {
            if (!vDate) return "";

            const oDate = new Date(vDate);
            if (isNaN(oDate)) return "";

            const oFormatter = DateFormat.getDateInstance({
                pattern: sPattern || "yyyy.MM.dd"
            });

            return oFormatter.format(oDate);
        },

        /**
         * Convert date into YYYY-MM-DD format
         */
        toYMD: function (vDate) {
            if (!vDate) return "";

            const oDate = new Date(vDate);
            if (isNaN(oDate)) return "";

            const sYear = oDate.getFullYear();
            const sMonth = this.pad(oDate.getMonth() + 1);
            const sDay = this.pad(oDate.getDate());

            return `${sYear}-${sMonth}-${sDay}`;
        },

        /**
         * Convert to local datetime
         */
        convertUTCToLocal: function (dUTCDate) {
            return !!dUTCDate ? new Date(dUTCDate).toLocaleString() : dUTCDate;  //converts UTC → local timezone
        },

        /**
         * Format date into Timestamp(9) format: YYYY-MM-DD HH:MM:SS.FFFFFF
         */
        formatTimestamp9: function (vDate, oOptions = { utc: true }) {
            const oDate = vDate ? new Date(vDate) : new Date();
            if (isNaN(oDate)) return "";

            const bUTC = oOptions.utc;

            const iYear = bUTC ? oDate.getUTCFullYear() : oDate.getFullYear();
            const iMonth = bUTC ? oDate.getUTCMonth() + 1 : oDate.getMonth() + 1;
            const iDay = bUTC ? oDate.getUTCDate() : oDate.getDate();

            const iHours = bUTC ? oDate.getUTCHours() : oDate.getHours();
            const iMinutes = bUTC ? oDate.getUTCMinutes() : oDate.getMinutes();
            const iSeconds = bUTC ? oDate.getUTCSeconds() : oDate.getSeconds();
            const iMillis = bUTC ? oDate.getUTCMilliseconds() : oDate.getMilliseconds();

            const sFractional = this.pad(iMillis, 3) + "000000";

            return `${this.pad(iYear, 4)}-${this.pad(iMonth)}-${this.pad(iDay)} `
                + `${this.pad(iHours)}:${this.pad(iMinutes)}:${this.pad(iSeconds)}.${sFractional}`;
        },

        /**
         * Get today's date
         */
        today: function () {
            return new Date();
        },

        /**
         * Get 1 January of the year N years before the current year, in HANA date format (yyyy-MM-dd).
         * Age is determined by birth year (current year - birth year), not by the exact birthday.
         * Usage for age-based DOB filters:
         *  - age N or below this year : DOB >= getDateNYearsAgo(N)
         *  - age above N this year    : DOB <  getDateNYearsAgo(N)
         * e.g. in 2026, getDateNYearsAgo(18) returns "2008-01-01"
         * @public
         * @param {integer} iYears - number of years to go back from the current year
         * @return {string} 1 January of (current year - iYears) in 'yyyy-MM-dd' format
         */
        getDateNYearsAgo: function (iYears) {
            return (this.today().getFullYear() - iYears) + "-01-01";
        },

        /**
         * Get Hana Date format for binding calls, used for passing dates when upserting records
         * @public
         * @param {date} dDateInput - date value to be transformed
         * @return {string} sDateString - readable value when submitting data to backend
         */
        getHanaDate: function (dDateInput) {
            if (dDateInput) {
                var dDate = new Date(dDateInput);
                var sDateString = dDate.getFullYear() + '-' + ('0' + (dDate.getMonth() + 1)).slice(-2) + '-' + ('0' + dDate.getDate()).slice(-2);
                return sDateString;
            } else {
                return null;
            }
        },

        /**
         * Calculate number of days between given date range based on claim type item
         * @public
         * @param {string} sSubmissionType - whether data is processed based on claim or request submission type
         * @param {object} oHeader - header data retrieved
         * @param {object} oItem - item data retrieved
         * @return {integer} iDiffDays - difference in days between start/end date; if invalid, return 0
         */
        calculateNumberOfDays: function (sSubmissionType, oHeader, oItem) {
            // determine header start/end based on submission type
            switch (sSubmissionType) {
                case Constants.SubmissionTypePrefix.REQUEST:
                    var dHeaderStart = oHeader.tripstartdate ? new Date(oHeader.tripstartdate) : null;
                    var dHeaderEnd = oHeader.tripenddate ? new Date(oHeader.tripenddate) : null;
                    break;
                case Constants.SubmissionTypePrefix.CLAIM:
                    // populate header values based on claim tyoe item
                    switch (oItem.claim_type_item_id) {
                        case Constants.ClaimTypeItem.DOBI:
                            dHeaderStart = oHeader.trip_start_date ? new Date(oHeader.trip_start_date) : null;
                            dHeaderEnd = oHeader.trip_end_date ? new Date(oHeader.trip_end_date) : null;
                            break;
                        default:
                            // no using header field for non-DOBI claim type items
                            dHeaderStart = null;
                            dHeaderEnd = null;
                            break;
                    }
                    break;
            }

            switch (oItem.claim_type_item_id) {
                case Constants.ClaimTypeItem.DOBI:
                    // no using item fields for DOBI claim type items
                    var dItemStart = null;
                    var dItemEnd = null;
                    break;
                case Constants.ClaimTypeItem.TRAVEL_INSURANCE:
                    dItemStart = oItem.insurance_cert_start_date ? new Date(oItem.insurance_cert_start_date) : null;
                    dItemEnd = oItem.insurance_cert_end_date ? new Date(oItem.insurance_cert_end_date) : null;
                    break;
                default:
                    dItemStart = oItem.start_date ? new Date(oItem.start_date) : null;
                    dItemEnd = oItem.end_date ? new Date(oItem.end_date) : null;
                    break;
            }

            const dFinalStart = dItemStart || dHeaderStart;
            const dFinalEnd = dItemEnd || dHeaderEnd;

            if (!dFinalStart || !dFinalEnd || isNaN(dFinalStart.getTime()) || isNaN(dFinalEnd.getTime())) {
                return 0;
            }

            const iStartMidnight = new Date(dFinalStart).setHours(0, 0, 0, 0);
            const iEndMidnight = new Date(dFinalEnd).setHours(0, 0, 0, 0);

            let iDiffDays = 0;

            if (iEndMidnight >= iStartMidnight) {
                const iMsPerDay = 1000 * 60 * 60 * 24;
                const iBaseDiff = Math.floor((iEndMidnight - iStartMidnight) / iMsPerDay);
                const bIsNightBased = Utility.isNightBasedCalculation(oHeader, oItem);
                iDiffDays = bIsNightBased ? iBaseDiff : iBaseDiff + 1;
            }

            return iDiffDays;
        },

        /**
         * Used to return date for Excel download functionality, based on object passed into method
         * @public
         * @param {object} oValue object to be converted into date value
         * @returns {date} returns date
         */
        toDate: function (oValue) {

            if (!oValue) return null;

            // ISO 8601 with or without milliseconds
            if (typeof oValue === "string" && /^\d{4}-\d{2}-\d{2}T/i.test(oValue)) {
                const oDate = new Date(oValue);
                if (!isNaN(oDate.getTime())) {
                    return new Date(Date.UTC(oDate.getUTCFullYear(), oDate.getUTCMonth(), oDate.getUTCDate()));
                }
                return null;
            }

            // YYYY-MM-DD
            if (typeof oValue === "string" && /^\d{4}-\d{2}-\d{2}$/.test(oValue)) {
                const [sYear, sMonth, sDay] = oValue.split("-").map(Number);
                return new Date(Date.UTC(sYear, sMonth - 1, sDay));
            }

            // JS Date
            if (oValue instanceof Date && !isNaN(oValue.getTime())) {
                return new Date(Date.UTC(oValue.getFullYear(), oValue.getMonth(), oValue.getDate()));
            }

            // SAP Edm.Date { year, month, day }
            if (typeof oValue === "object" && oValue.year && oValue.month && oValue.day) {
                return new Date(Date.UTC(oValue.year, oValue.month - 1, oValue.day));
            }

            return null;
        },

        /**
         * Used to return time for Excel download functionality, based on object passed into method
         * @public
         * @param {object} oValue object to be converted into date value
         * @returns {date} returns date variable with hours, minutes, seconds populated
         */
        toTime: function (oValue) {

            if (!oValue) return null;

            // ISO 8601 with or without milliseconds
            if (typeof oValue === "string" && /^\d{2}:\d{2}:\d{2}Z/i.test(oValue)) {
                const oDate = new Date(oValue);
                if (!isNaN(oDate.getTime())) {
                    return new Date(Date.UTC(0, 0, 0, oDate.getUTCHours(), oDate.getUTCMinutes(), oDate.getUTCSeconds()));
                }
                return null;
            }

            // HH:MM:SS
            if (typeof oValue === "string" && /^\d{2}:\d{2}:\d{2}$/.test(oValue)) {
                const [sHour, sMinute, sSecond] = oValue.split(":").map(Number);
                return new Date(Date.UTC(0, 0, 0, sHour, sMinute, sSecond));
            }

            // JS Date
            if (oValue instanceof Date && !isNaN(oValue.getTime())) {
                return new Date(Date.UTC(0, 0, 0, oValue.getHours(), oValue.getMinutes(), oValue.getSeconds()));
            }

            return null;
        },

        /**
         * Determines the minimum allowable date for specific date fields
         * based on submission type (REQUEST/CLAIM) & the following parameters.
         *
         * @param {string} sFieldName - The field name (e.g., RECEIPT_DATE, BILL_DATE).
         * @param {string} sId - Submission ID; first 3 chars determine submission type.
         * @param {string} sType - Claim Type.
         * @param {string} sItemType - Claim Item Type.
         * @param {object} oHeader - Header data.
         * @param {object} oItem - Item data.
         * @param {string} sFieldValue - Primary reference date for the bound (see field cases below).
         *                                    (e.g. request Event End Date min: Event Start Date, else header Start Date).
         * @returns {Date|null} Minimum allowed date or null if invalid input.
         *
        **/
        determineMinDate: function (sFieldName, sId, sType, sItemType, oHeader, oItem, sFieldValue) {
            if (!sId && !sType && !sItemType) return null;

            var _oAppModel = this.getOwnerComponent().getModel("appModel");
            var _oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            const _sSubmissionType = sId.substring(0, 3);
            var _dMinDate = null;

            switch (sFieldName) {
                case Constants.EntitiesFields.RECEIPT_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            // Default Claim Type - minimum date = 90 days before header start date 
                            if (sType === Constants.ClaimType.ELAUN_PINDAH || sType === Constants.ClaimType.ELAUN_TUKAR) {
                                _dMinDate = new Date(oHeader.trip_start_date);
                                _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_receipt_date_in_past"));
                            } else {
                                _dMinDate = new Date(oHeader.trip_start_date);
                                const dPastDate = new Date(_dMinDate);
                                dPastDate.setDate(dPastDate.getDate() - 90);
                                _dMinDate = dPastDate;
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_receiptdate_mindate"));
                            }

                            break;
                    }
                    break;
                case Constants.EntitiesFields.START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Request item - minimum date = header Start Date (sFieldValue)
                            // if header Start Date not set, default to null (no constraint)
                            _dMinDate = sFieldValue;
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.KURSUS_DLM_NEGARA) {
                                // Kursus Dalam Negara/Kursus Luar Negara - minimum date = 1 day before header start date
                                _dMinDate = new Date(oHeader.trip_start_date);
                                _dMinDate.setDate(_dMinDate.getDate() - 1);
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_start_date_kursus_mindate"));
                            } else if (sType === Constants.ClaimType.ELAUN_PINDAH || sType === Constants.ClaimType.ELAUN_TUKAR) {
                                // Elaun Perpindahan - minimum date = move-in date
                                _dMinDate = new Date(oHeader["trip_start_date"]);
                                const dPastDate = new Date(_dMinDate);
                                _dMinDate = dPastDate;
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_start_date_mknloan_header_mindate"));
                            }else if (sType === Constants.ClaimType.KURSUS_LUAR_NEGARA){
                                // Kursus Dalam Negara/Kursus Luar Negara - minimum date = 2 day before header start date
                                _dMinDate = new Date(oHeader.trip_start_date);
                                _dMinDate.setDate(_dMinDate.getDate() - 2);
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_start_date_kursus_mindate"));
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Request item - minimum date = header Start Date (sFieldValue)
                            // if header Start Date not set, default to null (no constraint)
                            _dMinDate = sFieldValue;
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.KURSUS_DLM_NEGARA) {
                                // Kursus Dalam Negara/Kursus Luar Negara - minimum date = item start date
                                // if item start date not set, use 1 day before header start date
                                if (!!new Date(oItem["start_date"]).getTime()) {
                                    _dMinDate = new Date(oItem["start_date"]);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_end_date_kursus_item_mindate"));
                                }
                                else {
                                    _dMinDate = new Date(oHeader.trip_start_date);
                                    _dMinDate.setDate(_dMinDate.getDate() - 1);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_end_date_kursus_mindate"));
                                }
                            } else if (sType === Constants.ClaimType.KURSUS_LUAR_NEGARA){
                                // Kursus Dalam Negara/Kursus Luar Negara - minimum date = item start date
                                // if item start date not set, use 2 day before header start date
                                if (!!new Date(oItem["start_date"]).getTime()) {
                                    _dMinDate = new Date(oItem["start_date"]);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_end_date_kursus_item_mindate"));
                                }
                                else {
                                    _dMinDate = new Date(oHeader.trip_start_date);
                                    _dMinDate.setDate(_dMinDate.getDate() - 2);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_end_date_kursus_mindate"));
                                }
                            } else if (sType === Constants.ClaimType.ELAUN_PINDAH || sType === Constants.ClaimType.ELAUN_TUKAR) {
                                // Elaun Perpindahan/Pertukaran - minimum date = item start date
                                // if item start date not set, use header trip start date
                                if (oItem?.start_date) {
                                    _dMinDate = oItem.start_date;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_end_date_mindate"));
                                } else {
                                    _dMinDate = oHeader?.trip_start_date;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_start_date_mknloan_header_mindate"));
                                }
                                // Elaun Perpindahan / Elaun Pertukaran (e.g. Elaun Pengangkutan items)
                                // minimum date = item start date if set, otherwise header trip start date
                                // (whichever is later), so End Date can never be earlier than Start Date
                                var dHeaderStart = new Date(oHeader["trip_start_date"]);
                                var dItemStart = (oItem && oItem["start_date"]) ? new Date(oItem["start_date"]) : null;
                                if (!!dItemStart && !isNaN(dItemStart.getTime()) &&
                                    (isNaN(dHeaderStart.getTime()) || dItemStart >= dHeaderStart)) {
                                    _dMinDate = dItemStart;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_end_date_mindate"));
                                } else {
                                    _dMinDate = dHeaderStart;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_start_date_mknloan_header_mindate"));
                                }
                            } else {
                                // Other Claim Type - minimum date = item start date
                                // if start date not set, default to null (no constraint)
                                _dMinDate = !!new Date(oItem["start_date"]).getTime() ? new Date(oItem["start_date"]) : null;
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_end_date_mindate"));
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.INSURANCE_CERT_END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sItemType === Constants.ClaimTypeItem.TRAVEL_INSURANCE) {
                                // Travel Insurance - minimum date = insurance certificate start date
                                // if start date not set, set 90 days before header start date
                                if (!!new Date(oItem["insurance_cert_start_date"]).getTime()) {
                                    _dMinDate = new Date(oItem["insurance_cert_start_date"]);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_insurance_cert_end_date_mindate"));
                                }
                                else {
                                    _dMinDate = new Date(oHeader.trip_start_date);
                                    const dPastDate = new Date(_dMinDate);
                                    dPastDate.setDate(dPastDate.getDate() - 90);
                                    _dMinDate = dPastDate;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_insurance_cert_end_date_header_mindate"));
                                }
                            }
                            break;


                    }
                    break;
                case Constants.EntitiesFields.MOVE_IN_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_PINDAH) {
                                if (!!sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_move_in_date_in_past"));
                                } else {
                                    const dPastDate = new Date();
                                    dPastDate.setDate(dPastDate.getDate() - 180);
                                    _dMinDate = dPastDate;
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_move_in_date_in_past"));
                                }
                            }

                            break;
                    }
                    break;
                case Constants.EntitiesFields.TRIP_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!oHeader["tripenddate"]) {
                                    _dMinDate = new Date(oHeader["tripenddate"]);
                                    _dMinDate.setDate(_dMinDate.getDate() - oHeader["req_no_of_days"]);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_trip_start_date_exceed_mode_of_transfer"));
                                }
                            }
                            else {
                                _dMinDate = null;
                            }
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_PINDAH) {
                                const dPastDate = new Date();
                                dPastDate.setDate(dPastDate.getDate() - 180);
                                _dMinDate = dPastDate;
                                _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                    _oResourceBundle.getText("error_trip_start_date_in_past"));
                            } else if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                    _dMinDate.setDate(_dMinDate.getDate() - oHeader["req_no_of_days"]);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_trip_start_date_exceed_mode_of_transfer"));

                                } else
                                    if (!!oHeader["trip_end_date"]) {
                                        _dMinDate = new Date(oHeader["trip_end_date"]);
                                        _dMinDate.setDate(_dMinDate.getDate() - oHeader["req_no_of_days"]);
                                        _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                            _oResourceBundle.getText("error_trip_start_date_exceed_mode_of_transfer"));
                                    }
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.TRIP_END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!new Date(oHeader["tripstartdate"]).getTime()) {
                                    _dMinDate = new Date(oHeader["tripstartdate"]);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("req_d_w_check_date"));
                                }
                            }
                            else {
                                if (sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_trip_end_date_in_past"));
                                }
                            }
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_PINDAH) {
                                if (!!sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("req_d_w_check_date"));
                                } else {
                                    const dPastDate = new Date();
                                    dPastDate.setDate(dPastDate.getDate() - 180);
                                    _dMinDate = dPastDate;
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_trip_end_date_in_past"));
                                }
                            } else if (sType === Constants.ClaimType.ELAUN_TUKAR) {

                                if (!!sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("req_d_w_check_date"));
                                } else
                                    if (!!new Date(oHeader["trip_start_date"]).getTime()) {
                                        _dMinDate = new Date(oHeader["trip_start_date"]);
                                        _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                            _oResourceBundle.getText("req_d_w_check_date"));
                                    }
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.TRANSFER_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                _dMinDate = new Date(oHeader.tripstartdate);
                                _dMinDate.setDate(_dMinDate.getDate());
                            }
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:

                            break;
                    }
                    break;

                case Constants.EntitiesFields.EVENT_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Event Start Date - minimum date = header Trip Start Date
                            _dMinDate = oHeader?.tripstartdate;
                            break;
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sFieldValue) {
                                _dMinDate = new Date(sFieldValue);
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.EVENT_END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Event End Date - minimum date = Event Start Date once it has a value,
                            // otherwise header Trip Start Date
                            _dMinDate = oHeader?.eventstartdate || oHeader?.tripstartdate;
                            break;
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sFieldValue) {
                                _dMinDate = new Date(sFieldValue);
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.POLICY_END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sItemType) {
                                if (sItemType === Constants.ClaimTypeItem.MED_ADVANCE) {
                                    const dYearStart = new Date(new Date().getFullYear(), 0, 1);

                                    if (sFieldValue) {
                                        const dPolicyStart = new Date(sFieldValue);

                                        _dMinDate = dPolicyStart > dYearStart
                                            ? dPolicyStart
                                            : dYearStart;
                                    } else {
                                        _dMinDate = dYearStart;
                                    }
                                } else {
                                    if (sFieldValue) {
                                        _dMinDate = new Date(sFieldValue);
                                    }
                                }
                            } else {
                                if (sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                }
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.POLICY_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sItemType) {
                                if (sItemType === Constants.ClaimTypeItem.MED_ADVANCE) {
                                    _dMinDate = new Date(new Date().getFullYear(), 0, 1);
                                }
                            } else {
                                if (sFieldValue) {
                                    _dMinDate = new Date(sFieldValue);
                                }
                            }
                            break;
                    }
                    break;
            }
            return _toLocalDate(_dMinDate);
        },

        /**
         * Determines the maximum allowable date for specific date fields
         * based on submission type (REQUEST/CLAIM) & the following parameters.
         *
         * @param {string} sFieldName - The field name (e.g., RECEIPT_DATE, BILL_DATE).
         * @param {string} sId - Submission ID; first 3 chars determine submission type.
         * @param {string} sType - Claim Type.
         * @param {string} sItemType - Claim Item Type.
         * @param {object} oHeader - Header data.
         * @param {object} oItem - Item data.
         * @param {string} sFieldValue - Primary reference date for the bound (see field cases below).
         *                                    (e.g. request Event Start Date max: Event End Date, else header End Date).
         * @returns {Date|null} Maximum allowed date or null if invalid input.
         *
        **/
        determineMaxDate: function (sFieldName, sId, sType, sItemType, oHeader, oItem, sFieldValue) {
            if (!sId && !sType && !sItemType) return null;

            var _oAppModel = this.getOwnerComponent().getModel("appModel");
            var _oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            const _sSubmissionType = sId.substring(0, 3);
            var _dMaxDate = null;

            switch (sFieldName) {
                case Constants.EntitiesFields.RECEIPT_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_PINDAH || sType === Constants.ClaimType.ELAUN_TUKAR) {
                                // Elaun Perpindahan - maximum date = trip end date
                                _dMaxDate = new Date(oHeader.trip_end_date);
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_receipt_date_in_future"));
                            } else {
                                // Default Claim Type - maximum date = header end date 
                                _dMaxDate = new Date(oHeader.trip_end_date);
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_receiptdate_maxdate"));
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.BILL_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            _dMaxDate = new Date(oHeader.trip_end_date); // default
                            _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                _oResourceBundle.getText("error_billdate_maxdate"));
                            break;
                    }
                    break;
                case Constants.EntitiesFields.START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Request item - maximum date = header End Date (sFieldValue)
                            // if header End Date not set, default to null (no constraint)
                            _dMaxDate = sFieldValue;
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.KURSUS_DLM_NEGARA) {
                                // Kursus Dalam Negara/Kursus Luar Negara - maximum date = item end date
                                // if end date not set, use 1 day after header end date
                                if (!!new Date(oItem["end_date"]).getTime()) {
                                    _dMaxDate = new Date(oItem["end_date"]);
                                    // set validator error message
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_start_date_kursus_item_maxdate"));
                                }
                                else {
                                    _dMaxDate = new Date(oHeader.trip_end_date);
                                    _dMaxDate.setDate(_dMaxDate.getDate() + 1);
                                    // set validator error message
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_start_date_kursus_maxdate"));
                                }
                            }
                            else if (sType === Constants.ClaimType.ELAUN_PINDAH || sType === Constants.ClaimType.ELAUN_TUKAR) {
                                // Elaun Perpindahan/Pertukaran / Elaun Pertukaran (e.g. Elaun Pengangkutan items)
                                // maximum date = item end date
                                // if item end date not set, use header item end date if set, otherwise header trip end date
                                // (whichever is earlier), so Start Date can never exceed End Date
                                var dHeaderEnd = new Date(oItem?.end_date) || new Date(oHeader?.trip_end_date);
                                var dItemEnd = (oItem && oItem["end_date"]) ? new Date(oItem["end_date"]) : null;
                                if (!!dItemEnd && !isNaN(dItemEnd.getTime()) &&
                                    (isNaN(dHeaderEnd.getTime()) || dItemEnd <= dHeaderEnd)) {
                                    _dMaxDate = dItemEnd;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_start_date_maxdate"));
                                } else {
                                    _dMaxDate = dHeaderEnd;
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_start_date_mknloan_item_maxdate"));
                                }
                            }
                            else if (sType === Constants.ClaimType.KURSUS_LUAR_NEGARA){
                                // Kursus Dalam Negara/Kursus Luar Negara - maximum date = item end date
                                // if end date not set, use 2 day after header end date
                                if (!!new Date(oItem["end_date"]).getTime()) {
                                    _dMaxDate = new Date(oItem["end_date"]);
                                    // set validator error message
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_start_date_kursus_item_maxdate"));
                                }
                                else {
                                    _dMaxDate = new Date(oHeader.trip_end_date);
                                    _dMaxDate.setDate(_dMaxDate.getDate() + 2);
                                    // set validator error message
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_start_date_kursus_maxdate"));
                                }
                            }
                            else {
                                // Other Claim Type - maximum date = item end date
                                // if end date not set, default to null (no constraint)
                                _dMaxDate = !!new Date(oItem["end_date"]).getTime() ? new Date(oItem["end_date"]) : null;
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_start_date_maxdate"));
                            }
                            
                            break;
                    }
                    break;
                case Constants.EntitiesFields.END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Request item - maximum date = header End Date (sFieldValue)
                            // if header End Date not set, default to null (no constraint)
                            _dMaxDate = sFieldValue;
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.KURSUS_DLM_NEGARA) {
                                // Kursus Dalam Negara/Kursus Luar Negara - maximum date = 1 day after header end date
                                _dMaxDate = new Date(oHeader.trip_end_date);
                                _dMaxDate.setDate(_dMaxDate.getDate() + 1);
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_end_date_kursus_maxdate"));
                            }
                            else if (sType === Constants.ClaimType.KURSUS_LUAR_NEGARA){
                                // Kursus Dalam Negara/Kursus Luar Negara - maximum date = 2 day after header end date
                                _dMaxDate = new Date(oHeader.trip_end_date);
                                _dMaxDate.setDate(_dMaxDate.getDate() + 2);
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_end_date_kursus_maxdate"));
                            }
                            else if (sType === Constants.ClaimType.ELAUN_PINDAH || sType === Constants.ClaimType.ELAUN_TUKAR) {
                                // Elaun Perpindahan - maximum date = trip end date
                                _dMaxDate = new Date(oHeader["trip_end_date"]);
                                // set validator error message
                                _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_start_date_mknloan_item_maxdate"));
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.INSURANCE_CERT_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            // Travel Insurance - maximum date = insurance certificate end date
                            // if end date not set, use header end date
                            if (sItemType === Constants.ClaimTypeItem.TRAVEL_INSURANCE) {
                                if (!!new Date(oItem["insurance_cert_end_date"]).getTime()) {
                                    _dMaxDate = new Date(oItem["insurance_cert_end_date"]);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_insurance_cert_start_date_maxdate"));
                                }
                                else {
                                    _dMaxDate = new Date(oHeader["trip_end_date"]);
                                    _oAppModel.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_insurance_cert_start_date_header_maxdate"));
                                }
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.MOVE_IN_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_PINDAH) {
                                if (!!sFieldValue) {
                                    _dMaxDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_move_in_date_in_future"));
                                } else {
                                    _dMaxDate = new Date();
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_move_in_date_in_future"));
                                }

                            } else {

                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.TRIP_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!new Date(oHeader["tripenddate"]).getTime()) {
                                    _dMaxDate = new Date(oHeader["tripenddate"]);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_trip_start_date_over_trip_end_date"));
                                }
                            }
                            else {
                                if (sFieldValue) {
                                    _dMaxDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_trip_start_date_in_past"));
                                }
                            }
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_PINDAH) {
                                if (!!sFieldValue) {
                                    _dMaxDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_trip_start_date_over_trip_end_date"));
                                } else {
                                    _dMaxDate = new Date();
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMinDateError",
                                        _oResourceBundle.getText("error_trip_start_date_in_past"));
                                }

                            } else if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!sFieldValue) {
                                    _dMaxDate = new Date(sFieldValue);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_trip_start_date_over_trip_end_date"));
                                } else {
                                    if (!!new Date(oHeader["trip_end_date"]).getTime()) {
                                        _dMaxDate = new Date(oHeader["trip_end_date"]);
                                        _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                            _oResourceBundle.getText("error_trip_start_date_over_trip_end_date"));
                                    }
                                }
                            } else {
                                _dMaxDate = new Date();
                                _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_trip_start_date_in_future"));
                            }
                            break;
                    }
                    break;
                case Constants.EntitiesFields.TRIP_END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!new Date(oHeader["tripstartdate"]).getTime()) {
                                    _dMaxDate = new Date(oHeader["tripstartdate"]);
                                    _dMaxDate.setDate(_dMaxDate.getDate() + oHeader["req_no_of_days"]);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_trip_end_date_exceed_mode_of_transfer"));
                                }
                            }
                            else {
                                _dMaxDate = null;
                            }
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                if (!!sFieldValue) {
                                    _dMaxDate = new Date(sFieldValue);
                                    _dMaxDate.setDate(_dMaxDate.getDate() + oHeader["req_no_of_days"]);
                                    _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                        _oResourceBundle.getText("error_trip_end_date_exceed_mode_of_transfer"));
                                } else
                                    if (!!new Date(oHeader["trip_start_date"]).getTime()) {
                                        _dMaxDate = new Date(oHeader["trip_start_date"]);
                                        //_dMaxDate.setDate(_dMaxDate.getDate() + oHeader["req_no_of_days"]);
                                        _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                            _oResourceBundle.getText("error_trip_end_date_exceed_mode_of_transfer"));
                                    }
                            } else if (sType === Constants.ClaimType.POST_EDUCATION_ASSISTANCE) {
                                _dMaxDate = null;
                            } else {
                                _dMaxDate = new Date();
                                _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("error_trip_end_date_in_future"));
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.TRANSFER_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            if (sType === Constants.ClaimType.ELAUN_TUKAR) {
                                _dMaxDate = new Date(oHeader.tripenddate);
                                _dMaxDate.setDate(_dMaxDate.getDate());
                            }
                            break;

                        case Constants.SubmissionTypePrefix.CLAIM:

                            break;
                    }
                    break;

                case Constants.EntitiesFields.EVENT_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Event Start Date - maximum date = Event End Date once it has a value,
                            // otherwise header End Date
                            _dMaxDate = oHeader?.eventenddate || oHeader?.tripenddate;
                            break;
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sFieldValue) {
                                _dMaxDate = new Date(sFieldValue);
                                _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("req_d_w_check_date"));
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.EVENT_END_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.REQUEST:
                            // Event End Date - maximum date = header End Date
                            _dMaxDate = oHeader?.tripenddate;
                            break;
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sFieldValue) {
                                _dMaxDate = new Date(sFieldValue);
                                _oAppModel?.setProperty("/fieldControl/" + sFieldName + "/customMaxDateError",
                                    _oResourceBundle.getText("req_d_w_check_date"));
                            }
                            break;
                    }
                    break;

                case Constants.EntitiesFields.POLICY_START_DATE:
                    switch (_sSubmissionType) {
                        case Constants.SubmissionTypePrefix.CLAIM:
                            if (sItemType) {
                                if (sItemType === Constants.ClaimTypeItem.MED_ADVANCE) {

                                    const dYearEnd = new Date(new Date().getFullYear(), 11, 31);

                                    if (sFieldValue) {
                                        const dPolicyEnd = new Date(sFieldValue);

                                        _dMaxDate = dPolicyEnd < dYearEnd
                                            ? dPolicyEnd
                                            : dYearEnd;
                                    } else {
                                        _dMaxDate = dYearEnd;
                                    }

                                } else if (sFieldValue) {
                                    _dMaxDate = new Date(sFieldValue);
                                }
                            } else {
                                _dMaxDate = new Date(sFieldValue);
                            }
                            break;
                    }
                    break;
            }

            return _toLocalDate(_dMaxDate);
        },

        /**
        * Convert various time formats to HANA-compatible HH:mm:ss
        * @public
        * @param {string|number|Date} iTime - time input
        * @returns {string|null} HH:mm:ss or null if invalid
        */
        getHanaTime: function (iTime) {
            if (!iTime) return null;

            var sTime = String(iTime).trim();

            // HH:mm:ss (e.g. "22:52:00")
            if (/^\d{2}:\d{2}:\d{2}$/.test(sTime)) {
                return sTime;
            }

            // HH:mm (e.g. "22:52")
            if (/^\d{2}:\d{2}$/.test(sTime)) {
                return sTime + ":00";
            }

            // 12-hour format (e.g. "10:52 PM" or "10:52:00 PM")
            var oTimeMatch = sTime.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)$/i);
            if (oTimeMatch) {
                var nHours = parseInt(oTimeMatch[1], 10);
                var nMinutes = parseInt(oTimeMatch[2], 10);
                var nSeconds = parseInt(oTimeMatch[3] || 0, 10);
                var sMeridiem = oTimeMatch[4].toUpperCase();

                if (sMeridiem === "PM" && nHours !== 12) {
                    nHours += 12;
                }
                if (sMeridiem === "AM" && nHours === 12) {
                    nHours = 0;
                }

                return this.pad(nHours) + ":" + this.pad(nMinutes) + ":" + this.pad(nSeconds);
            }

            // Timestamp / Date fallback
            var oDate = new Date(iTime);
            if (!isNaN(oDate.getTime())) {
                return this.pad(oDate.getHours()) + ":"
                    + this.pad(oDate.getMinutes()) + ":"
                    + this.pad(oDate.getSeconds());
            }

            return null;
        },


        /**
         * Checks whether a date value is valid.
         * @param {string|Date} vDate input date
         * @returns {boolean} true if valid date
         */
        isValidDate: function (vDate) {
            const oDate = new Date(vDate);
            return vDate && !isNaN(oDate.getTime());
        },

        /**
         * Returns a 2-year window (Previous Year → Current Year)
         * based on the supplied date.
         * @param {string|Date} vDate input date
         * @returns {{start: string, end: string}} date range in YYYY-MM-DD format
         */
        getPrevYearToYearEnd: function (vDate) {
            const oDate = new Date(vDate);
            if (isNaN(oDate)) return null;

            const iYear = oDate.getFullYear();

            return {
                start: `${iYear - 1}-01-01`,
                end: `${iYear}-12-31`
            };
        },

        /**
  * Converts a date into a specified format.
  * @public
  * @param {string|Date} vDate the input date
  * @param {string} sFormat output format (e.g. "YYYY-MM-DD", "DD/MM/YYYY")
  * @returns {string|null} formatted date or null if invalid
  */
        formatDateDynamic: function (vDate, sFormat = "YYYY-MM-DD") {
            if (!vDate) return null;

            const oDate = new Date(vDate);
            if (isNaN(oDate)) return null;

            const sYear = oDate.getFullYear().toString();
            const sMonth = this.pad(oDate.getMonth() + 1);
            const sDay = this.pad(oDate.getDate());


            return sFormat
                .replace("YYYY", sYear)
                .replace("MM", sMonth)
                .replace("DD", sDay);
        },

        /**
         * Parse Date and Time into DateTime format.
         * @public
         * @param {Date} Date from input
         * @param {Time} Time from input 
         * @returns {oBaseDate} 
         */
        parseDateTime: function (dDate, tTime) {
            let oBaseDate = new Date(dDate);

            if (isNaN(oBaseDate.getTime())) {
                console.error("Invalid Date format received:", dDate);
                return oBaseDate;
            }

            let iHours = 0, iMinutes = 0, iSeconds = 0;

            if (tTime instanceof Date) {
                iHours = tTime.getHours();
                iMinutes = tTime.getMinutes();
                iSeconds = tTime.getSeconds();
            } else if (tTime && tTime.ms !== undefined) {
                let dtempDate = new Date(tTime.ms);
                iHours = dtempDate.getUTCHours();
                iMinutes = dtempDate.getUTCMinutes();
                iSeconds = dtempDate.getUTCSeconds();
            } else if (typeof tTime === "string") {
                if (tTime.startsWith("PT")) {
                    iHours = parseInt((tTime.match(/(\d+)H/) || [0, 0])[1], 10);
                    iMinutes = parseInt((tTime.match(/(\d+)M/) || [0, 0])[1], 10);
                    iSeconds = parseInt((tTime.match(/(\d+)S/) || [0, 0])[1], 10);
                } else {
                    let isPM = tTime.toLowerCase().includes("pm");
                    let isAM = tTime.toLowerCase().includes("am");

                    let aTimeParts = tTime.replace(/[^0-9:]/g, "").split(":");

                    iHours = parseInt(aTimeParts[0] || 0, 10);
                    iMinutes = parseInt(aTimeParts[1] || 0, 10);
                    iSeconds = parseInt(aTimeParts[2] || 0, 10);

                    if (isPM && iHours < 12) iHours += 12;
                    if (isAM && iHours === 12) iHours = 0;
                }
            }

            oBaseDate.setHours(iHours, iMinutes, iSeconds, 0);
            return oBaseDate;
        },

        /**
         * Convert Timepicker value to HH:mm:ss which accepted by HANA Cloud.
         * @public
         * @param {string} sTimeStr from TimePicker value
         * @returns {string|null} formatted time
         */
        convertTo24Hour: function (sTimeStr) {
            if (!sTimeStr) return null;

            const sNormalized = sTimeStr.replace(/\s+/g, ' ').trim();

            const [sTime, sModifier] = sNormalized.split(' ');

            if (!sTime || !sModifier) return null;

            let [iHours, iMinutes, iSeconds] = sTime.split(':').map(Number);

            if (sModifier.toUpperCase() === 'AM' && iHours === 12) {
                iHours = 0;
            }
            if (sModifier.toUpperCase() === 'PM' && iHours !== 12) {
                iHours += 12;
            }

            return `${hours.toString().padStart(2, '0')}:${iMinutes
                .toString()
                .padStart(2, '0')}:${iSeconds.toString().padStart(2, '0')}`;
        },
    };
});