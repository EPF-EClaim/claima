sap.ui.define([
], function () {
    "use strict";
    return {
        "Approvers": {
            "AUTO": "AUTO",
            "AUTOASSIGN": "AA",
            "BUDGET": "Budget",
            "HEADOFSECTION": "HOS"
        },
        "BudgetCheckAction": {
            "APPROVE": "APPROVE",
            "REJECT": "REJECT",
            "SUBMIT": "SUBMIT"
        },
        "ClaimType": {
            "KURSUS_DLM_NEGARA": "KURSUS_DLM_NEGARA",
            "KURSUS_LUAR_NEGARA": "KURSUS_LUAR_NEGARA",
            "DLM_NEGARA": "DLM_NEGARA",
            "LUAR_NEGARA": "LUAR_NEGARA",
            "MEDICAL": "MEDICAL",
            "POST_EDUCATION_ASSISTANCE": "PEDU",
            "PELBAGAI": "PELBAGAI",
            "ELAUN_TUKAR": "ELAUN_TUKAR",
            "ELAUN_PINDAH": "ELAUN_PINDAH",
            "HANDPHONE": "HANDPHONE",
            "GALAKAN": "GALAKAN",
            "WILAYAH_ASAL": "WILAYAH_ASAL",
            "CERAMAH": "CERAMAH",
            "CORPO_CRED_CARD" : "CORPO_CRED_CARD",
            "MEDICAL_ADVANCE": "MEDICAL_ADVANCE"
        },
        "ClaimTypeKursus": {
            "KURSUS_DLM_NEGARA": "KURSUS_DLM_NEGARA",
            "KURSUS_LUAR_NEGARA": "KURSUS_LUAR_NEGARA"
        },
        "ClaimTypeItem": {
            "BAGAI": "BAGAI",
            "BYR_YURAN": "BYR_YURAN",
            "CERAMAH": "CERAMAH",
            "DAFTAR_KEN": "DAFTAR_KEN",
            "DARAT": "DARAT",
            "DOBI": "DOBI",
            "E_PENGAKUT": "E_PENGAKUT",
            "EXCESS": "EXCESS",
            "EXT_ENGAGE": "EXT_ENGAGE",
            "FLIGHT_L": "FLIGHT_L",
            "FLIGHT_O": "FLIGHT_O",
            "FLIGHT_WIL": "FLIGHT_WIL",
            "HOTEL_L": "HOTEL_L",
            "HOTEL_O": "HOTEL_O",
            "Jamuan Ringan Program Outreach": "Jamuan Ringan Program Outreach",
            "KATERER": "KATERER",
            "KECERIAAN": "KECERIAAN",
            "KESIHATAN": "KESIHATAN",
            "KILOMETER": "KILOMETER",
            "KM": "KM",
            "LAUT": "LAUT",
            "LEARN": "LEARN",
            "LOD_TUKAR": "LOD_TUKAR",
            "LODG_O": "LODG_O",
            "LODGING_L": "LODGING_L",
            "MAKAN_L": "MAKAN_L",
            "MAKAN_O": "MAKAN_O",
            "MATAWANG": "MATAWANG",
            "MISC": "MISC",
            "MKN_LOAN": "MKN_LOAN",
            "MKN_TUKAR": "MKN_TUKAR",
            "ONLINE_CRT": "ONLINE_CRT",
            "ONLINE_L": "ONLINE_L",
            "PARKING": "PARKING",
            "POST_EDUCATION_ASSISTANCE": "PEDU",
            "PELANGGAN": "PELANGGAN",
            "PELBAGAI": "PELBAGAI",
            "PEM_PINDAH": "PEM_PINDAH",
            "Pembelian Beg Bimbit": "Pembelian Beg Bimbit",
            "PENGHARGAAN": "PENGHARGAAN",
            "PINDAH": "PINDAH",
            "PKN_PANAS": "PKN_PANAS",
            "PUNSIAN_BG": "PUNSIAN_BG",
            "SERVICES": "SERVICES",
            "SEWA": "SEWA",
            "SUMPAH": "SUMPAH",
            "TGANTIAN": "T.GANTIAN",
            "TAKLIMAT": "TAKLIMAT",
            "TAMBANG": "TAMBANG",
            "TELEFON": "TELEFON",
            "TIPS": "TIPS",
            "TOLL": "TOLL",
            "TRAVEL_INSURANCE": "TRAVEL_INSURANCE",
            "VISA": "VISA",
            "YURAN": "YURAN",
            "YURAN_KLJ": "YURAN_KLJ",
            "CASH_REPAY": "CASH_REPAY",
            "GALAKAN": "GALAKAN",
            "TELEFON_B": "TELEFON_B",
            "ELEKTRIK": "ELEKTRIK",
            "BIL_AIR": "BIL_AIR",
            "IPAD":"I-PAD",
            "JENAZAH":"JENAZAH",
            "KEMATIAN": "KEMATIAN",
            "INSURANCE": "INSURANCE",
            "MED_ADVANCE": "MED_ADVANCE",
            "CASH_BACK" : "CASH_BACK",
            "STATMENT_DUE" : "STATMENT_DUE",
            "SERV_TAX" : "SERV_TAX",
            "MERCH_RETURN" : "MERCH_RETURN",
            "PERSONAL_EXP" : "PERSONAL_EXPENSE",
            "POTONGAN_ELAUN" : "POTONGAN_ELAUN"
        },
        "ClaimTypeItemOverseas": {
            "MAKAN_O": "MAKAN_O",
            "LODG_O": "LODG_O",
            "HOTEL_O": "HOTEL_O",
            "FLIGHT_O": "FLIGHT_O",
        },
        "ClaimTypeItemLodging": {
            "LOD_TUKAR": "LOD_TUKAR",
            "LODG_O": "LODG_O",
            "LODGING_L": "LODGING_L"
        },
        "ClaimTypeItemMakan": {
            "MAKAN_O": "MAKAN_O",
            "MAKAN_L": "MAKAN_L",
            "MKN_LOAN": "MKN_LOAN"
        },
        "ClaimTypeItemStatus": {
            "ACTIVE": "ACTIVE",
        },
        "ClaimStatus": {
            "DRAFT": "STAT01",
            "PENDING_APPROVAL": "STAT02",
            "SEND_BACK": "STAT03",
            "REJECTED": "STAT04",
            "APPROVED": "STAT05",
            "COMPLETED_DISBURSEMENT": "STAT06",
            "CANCELLED": "STAT07",
        },
        "ClaimTypeLuarNegara": {
            "KURSUS_LUAR_NEGARA": "KURSUS_LUAR_NEGARA", 
            "LUAR_NEGARA": "LUAR_NEGARA"
        },
        "EligibilityRule": {
            "ROLE_ID": "ROLE_ID",
            "PERSONAL_GRADE": "PERSONAL_GRADE",
            "POSITION_NO_DESC": "POSITION_NO_DESC",
            "ROW_COUNT": "ROW_COUNT",
            "ELIGIBLE_AMOUNT": "ELIGIBLE_AMOUNT",
            "RATE_PER_KM": "RATE",
            "SUBSIDISED_RATE": "SUBSIDISED_RATE"
        },
        "Departments": {
            "FI_DEPT": "0500000000"
        },
        "RequestStatus": {
            "DRAFT": "DRAFT",
            "PENDING_APPROVAL": "PENDING APPROVAL",
            "SEND_BACK": "PUSH BACK",
            "REJECTED": "REJECTED",
            "APPROVED": "APPROVED",
            "CANCELLED": "CANCELLED"
        },
        "WorkflowType": {
            "CLAIM": "CLM",
            "REQUEST": "REQ"
        },
        "Date": {
            "DATEFORMAT": "yyyy.MM.dd",
        },
        "ApprovalProcess": {
            "REQUEST": "REQ",
            "REQUESTTYPE": "Pre-Approval",
            "CLAIMTYPE": "Claim",
            "CLAIM_APPROVE": "APPROVE_CLAIM",
            "SET_GROUP": "approvalGroup",
            "ELIGIBLE_AMOUNT": "Eligible Amount",
            "TRAVEL_DAYS_ID": "Travel Days",
            "FARE_TYPE_ID": "Fare Type",
            "TRANSPORT_CLASS": "Transport Class",
            "FLIGHT_CLASS_ID": "Flight Class",
            "ROOM_TYPE_ID": "Room Type",
            "MOBILE_PHONE_BILL": "Mobile Phone Bill"
        },
        "ApprovalProcessStatus": {
            "STATUS_REJECT": "REJECT",
            "STATUS_SENDBACK": "PUSH BACK",
        },
        "ApprovalProcessAction": {
            "ACTION_NOTIFY": "Notify",
            "ACTION_APPROVE": "APPROVE",
            "RELEASE_IND": "release",
            "NOTAVAILABLE": "N/A",
        },
        "ApprovalProcessProjectCode": {
            "PROJ_CODE1": "1",
            "PROJ_CODE2": "2",
        },
        "Email_Action": {
            "NOTIFY": "Notify"
        },
        "Entities": {
            "ZAPPROVER_DETAILS_PREAPPROVAL": "/ZAPPROVER_DETAILS_PREAPPROVAL",
            "ZAPPROVER_DETAILS_CLAIMS": "/ZAPPROVER_DETAILS_CLAIMS",
            "ZBUDGET": "/ZBUDGET",
            "ZCONSTANTS": "/ZCONSTANTS",
            "ZCLAIM_HEADER": "/ZCLAIM_HEADER",
            "ZCLAIM_ITEM": "/ZCLAIM_ITEM",
            "ZCLAIM_TYPE_ITEM": "/ZCLAIM_TYPE_ITEM",
            "ZELIGIBILITY_RULE": "/ZELIGIBILITY_RULE",
            "ZEMP_APPROVER_REQUEST_DETAILS": "/ZEMP_APPROVER_REQUEST_DETAILS",
            "ZEMP_APPROVER_CLAIM_DETAILS": "/ZEMP_APPROVER_CLAIM_DETAILS",
            "ZEMP_CLAIM_BUDGET_CHECK": "/ZEMP_CLAIM_BUDGET_CHECK",
            "ZEMP_CLAIM_DETAILS": "/ZEMP_CLAIM_DETAILS",
            "ZEMP_DEPENDENT": "/ZEMP_DEPENDENT",
            "ZEMP_MASTER": "/ZEMP_MASTER",
            "ZEMP_REQUEST_BUDGET_CHECK": "/ZEMP_REQUEST_BUDGET_CHECK",
            "ZEMP_SUBSTITUTION_RULE": "/ZEMP_SUBSTITUTION_RULE",
            "ZOFFICE_DISTANCE": "/ZOFFICE_DISTANCE",
            "ZRATE_KM": "/ZRATE_KM",
            "ZREQUEST_HEADER": "/ZREQUEST_HEADER",
            "ZREQUEST_ITEM": "/ZREQUEST_ITEM",
            "ZREQUEST_TYPE": "/ZREQUEST_TYPE",
            "ZROLEHIERARCHY": "/ZROLEHIERARCHY",
            "ZCLAIM_HEADER": "/ZCLAIM_HEADER",
            "ZSUBMISSION_TYPE": "/ZSUBMISSION_TYPE",
            "ZSUBSTITUTION_RULES": "/ZSUBSTITUTION_RULES",
            "ZTRAIN_COURSE_PART": "/ZTRAIN_COURSE_PART",
            "ZWORKFLOW_RULE": "/ZWORKFLOW_RULE",
            "ZWORKFLOW_STEP": "/ZWORKFLOW_STEP",
            "ZREJECT_REASON": "/ZREJECT_REASON",
            "ZTRAIN_COURSE_PART": "/ZTRAIN_COURSE_PART",
            "ZDISBURSEMENT_STATUS": "/ZDISBURSEMENT_STATUS",
            "ZCOST_CENTER": "/ZCOST_CENTER",
            "ZDEPARTMENT": "/ZDEPARTMENT",
            "ZBRANCH": "/ZBRANCH",
            "ZMARITAL_STAT": "/ZMARITAL_STAT",
            "ZJOB_GROUP": "/ZJOB_GROUP",
            "ZOFFICE_LOCATION": "/ZOFFICE_LOCATION",
            "ZSTATE": "/ZSTATE",
            "ZCOUNTRY": "/ZCOUNTRY",
            "ZROLE": "/ZROLE",
            "ZUSER_TYPE": "/ZUSER_TYPE",
            "ZEMP_TYPE": "/ZEMP_TYPE",
        },
        "EntitiesFields": {
            "APPROVER_ID": "APPROVER_ID",
            "CLAIMID": "CLAIM_ID",
            "CLAIM_STATUS": "STATUS_ID",
            "CLAIM_TYPE_ITEM_ID": "CLAIM_TYPE_ITEM_ID",
            "COMMENTAPPOVAL": "COMMENT",
            "DEP": "DEP",
            "EEID": "EEID",
            "EMAIL": "EMAIL",
            "FUND_CENTER": "FUND_CENTER",
            "ID": "ID",
            "LEVEL": "LEVEL",
            "PREAPPROVALID": "PREAPPROVAL_ID",
            "REJECT_REASON_ID": "REJECT_REASON_ID",
            "REASON_ID": "REASON_ID",
            "REQUESTID": "REQUEST_ID",
            "FLIGHT_CLASS_ID": "FLIGHT_CLASS_ID",
            "TRAVEL_HOURS": "TRAVEL_HOURS",
            "TRAVEL_DAYS_ID": "TRAVEL_DAYS_ID",
            "ELIGIBLE_AMOUNT": "ELIGIBLE_AMOUNT",
            "ROOM_TYPE_ID": "ROOM_TYPE_ID",
            "FARE_TYPE_ID": "FARE_TYPE_ID",
            "REQUEST_TYPE_ID": "REQUEST_TYPE_ID",
            "ROLE": "ROLE",
            "SUBAPPROVER_ID": "SUBSTITUTE_APPROVER_ID",
            "SUBMISSION_TYPE_ID": "SUBMISSION_TYPE_ID",
            "STATUS": "STATUS",
            "TIMESTAMP": "PROCESS_TIMESTAMP",
            "USER_ID": "USER_ID",
            "VALID_FROM": "VALID_FROM",
            "VALID_TO": "VALID_TO",
            "WORKFLOW_CODE": "WORKFLOW_CODE",
            "WORKFLOW_TYPE": "WORKFLOW_TYPE",
            "YEAR": "YEAR",
            "SUBMITTED_DATE": "SUBMITTED_DATE",
            "BILL_DATE": "BILL_DATE",
            "RECEIPT_DATE": "RECEIPT_DATE",
            "START_DATE": "START_DATE",
            "END_DATE": "END_DATE",
            "MOVE_IN_DATE": "MOVE_IN_DATE",
            "INSURANCE_PURCH_DATE": "INSURANCE_PURCH_DATE",
            "INSURANCE_CERT_START_DATE": "INSURANCE_CERT_START_DATE",
            "INSURANCE_CERT_END_DATE": "INSURANCE_CERT_END_DATE",
            "VEHICLE_TYPE_ID": "VEHICLE_TYPE_ID",
            "VEHICLE_TYPE_DESC": "VEHICLE_TYPE_DESC",
            "STATE_ID": "STATE_ID",
            "STATE_DESC": "STATE_DESC",
            "LOCATION_DESC": "LOCATION_DESC",
            "FROM_STATE_ID": "FROM_STATE_ID",
            "FROM_LOCATION_ID": "FROM_LOCATION_ID",
            "TO_STATE_ID": "TO_STATE_ID",
            "TO_STATE_DESC": "TO_STATE_DESC",
            "TO_LOCATION_ID": "TO_LOCATION_ID",
            "TO_LOCATION_DESC": "TO_LOCATION_DESC",
            "LENDER_ID": "LENDER_ID",
            "LENDER_NAME": "LENDER_NAME",
            "HOUSING_LOAN_SCHEME_ID": "HOUSING_LOAN_SCHEME_ID",
            "HOUSING_LOAN_SCHEME_DESC": "HOUSING_LOAN_SCHEME_DESC",
            "RELATIONSHIP": "RELATIONSHIP",
            "DOB": "DOB",
            "STUDENT": "STUDENT",
            "EMP_ID": "EMP_ID",
            "REGION_ID": "REGION_ID",
            "TRIP_START_DATE" : "TRIP_START_DATE",
            "TRIP_END_DATE" : "TRIP_END_DATE",
            "DISBURSEMENT_STATUS": "DISBURSEMENT_STATUS",
            "TRANSFER_MODE_ID": "TRANSFER_MODE_ID",
            "CLAIM_TYPE_ID": "CLAIM_TYPE_ID",
            "REQUEST_TYPE": "REQUEST_TYPE",
            "WITH_FAMILY": "2",
            "TRAVEL_WITH_FAMILY_NOW": "Travel with Family Now",
            "TRANSFER_DATE": "TRANSFER_DATE",
            "EVENT_START_DATE": "EVENT_START_DATE",
            "EVENT_END_DATE": "EVENT_END_DATE",
            "VEHICLE_OWNERSHIP_ID": "VEHICLE_OWNERSHIP_ID",
            "COUNTRY": "COUNTRY",
            "PHONE_NO": "PHONE_NO",
            "ALT_CC" : "ALT_CC",
            "PROJECT_CODE" : "PROJECT_CODE",
            "POLICY_END_DATE" : "POLICY_END_DATE",
            "POLICY_START_DATE" : "POLICY_START_DATE",
            "DISABLED" : "DISABLED",
            "MEDICAL_BENEFICIARY" : "MEDICAL_BENEFICIARY",
            "COST_CENTER_ID": "COST_CENTER_ID",
            "COST_CENTER_DESC": "COST_CENTER_DESC",
            "DEPARTMENT_ID": "DEPARTMENT_ID",
            "DEPARTMENT_DESC": "DEPARTMENT_DESC",
            "BRANCH_ID": "BRANCH_ID",
            "BRANCH_DESC": "BRANCH_DESC",
            "MARRIAGE_STATUS_ID": "MARRIAGE_STATUS_ID",
            "MARRIAGE_STATUS_DESC": "MARRIAGE_STATUS_DESC",
            "JOB_GROUP_ID": "JOB_GROUP_ID",
            "JOB_GROUP_DESC": "JOB_GROUP_DESC",
            "LOCATION_ID": "LOCATION_ID",
            "COUNTRY_ID": "COUNTRY_ID",
            "COUNTRY_DESC": "COUNTRY_DESC",
            "ROLE_ID": "ROLE_ID",
            "ROLE_DESC": "ROLE_DESC",
            "USER_TYPE_ID": "USER_TYPE_ID",
            "USER_TYPE_DESC": "USER_TYPE_DESC",
            "EMP_TYPE_ID": "EMP_TYPE_ID",
            "EMP_TYPE_DESC": "EMP_TYPE_DESC",
            "SUBMISSION_TYPE_DESC": "SUBMISSION_TYPE_DESC",
            "OBJECTIVE_PURPOSE": "OBJECTIVE_PURPOSE"
        },
        "Operators": {
            "EQUAL": "EQ",
            "GREATEREQUAL": "GE",
            "GREATERTHAN": "GT",
            "LESSEQUAL": "LE",
            "LESSTHAN": "LT",
            "NOTEQUAL": "NE"
        },
        "Risk_Category": {
            "LOW": "L",
            "HIGH": "H"
        },
        "Role": {
            "APPROVER": "Approver",
            "CEO": "CEO",
            "DTD_ADMIN": "DTD Admin",
            "GA_ADMIN": "GA Admin",
            "JKEW_ADMIN": "JKEW Admin",
            "SUPER_ADMIN": "Super Admin",
            "HEADOFDEP": "HOD",
            "CCC_ADMIN" : "CCC Admin"
        },
        "User_Type": {
            "CASH_FI": "CASH_FI",
            "CEO_FI": "CEO_FI",
            "FI_SETTLEMENT_A": "FI_SETTLEMENT_A",
            "FI_SETTLEMENT_B": "FI_SETTLEMENT_B",
            "HOD_JKEW": "HOD_JKEW"
        },
        "EmployeeType": {
            "PERMANENT": "A",
            "CONTRACTOR": "B",
            "PROTEGE": "C",
            "INTERN": "D",
            "RETIREE": "E",
            "CONTRACTOR2": "F"
        },
        "Configuration": {
            "ZEMP_MASTER": "ZEMP_MASTER",
            "ZEMP_MASTER_DTD": "ZEMP_MASTER_DTD",
            "ZEMP_DEPENDENT": "ZEMP_DEPENDENT",
            "ZEMP_DEPENDENT_DTD": "ZEMP_DEPENDENT_DTD",
            "ZNUM_RANGE": "ZNUM_RANGE",
            "ZNUM_RANGE_DTD": "ZNUM_RANGE_DTD",
            "ZBUDGET": "ZBUDGET",
            "ZEMP_CA_PAYMENT" : "ZEMP_CA_PAYMENT",
            "ZCORPORATE_CARD" : "ZCORPORATE_CARD"
        },
        "BudgetCheckStatus": {
            "NOT_FOUND": "RECORD NOT FOUND",
            "INSUFFICIENT": "INSUFFICIENT BALANCE",
            "SUFFICIENT": "OK",
            "UPDATED": "RECORD UPDATED"
        },
        "GroupType": {
            "GROUP": "Group",
            "INDIVIDUAL": "Individual"
        },
        "RequestFieldVisibilityConfig": {
            "SUBMISSION_TYPE": "PREAPPROVAL_R",
            "HEADER": "HEADER",
            "ITEM": "ITEM"
        },
        "ClaimFieldVisibilityConfig": {
            "SUBMISSION_TYPE": "CLAIM",
            "ITEM": "ITEM"
        },
        "SubmissionTypePrefix": {
            "REQUEST": "REQ",
            "CLAIM": "CLM",
            "REQUESTHEADER": "REQHD",
            "CLAIMHEADER": "CLMHD"
        },
        "CashAdvanceInfo": {
            "COST_CENTER": "100000000",
            "GL_ACCOUNT": "214005"
        },
        "SubmissionType": {
            "DIRECT_CLAIM": "ST0001",
            "AUTO_APPROVE": "ST0002",
            "PRE_APPROVE": "ST0003",
            "CASH_REPAYMENT": "ST0004",
            "CURR_SUBSIDY": "ST0005"
        },
        "Default": {
            "PROJECT_CODE": "NA",
            "NULL": "null",
            "CASH_REPAY_GL": "244002",
            "NA": "NA"
        },
        "BudgetCheckAction": {
            "SUBMIT": "SUBMIT",
            "REJECT": "REJECT",
            "APPROVE": "APPROVE"
        },
        "PARMode": {
            "VIEW": "view",
            "APPROVER": "approver",
            "EDIT": "i_edit",
            "LIST": "list",
            "CREATE": "create",
            "VIEWAPPR": "view_appr",
            "APPROVE": "APPROVE",
        },
        "RequestType": {
            "TRAVEL": "RT0001",
            "MOBILE": "RT0002",
            "EVENTS": "RT0003",
            "REIMBURSEMENT": "RT0004",
            "MEDICAL": "RT0005",
            "PROJECT": "RT0006",
            "CORP_CC" : "RT0007"
        },
        "ClaimFooterMode": {
            "SUMMARY": "SUMMARY",
            "DETAILS": "DETAILS",
            "APPROVER": "APPROVER",
            "VIEW_ONLY": "VIEW_ONLY"
        },
        "LocationType": {
            "OTHER": "1",
            "KWSP": "2"
        },
        "LocationTypeOffice": {
            "FROM": "from",
            "TO": "to"
        },
        "OfficeDistance": {
            "MILEAGE": "MILEAGE"
        },
        "MaritalStatus": {
            "WIDOWED": "W",
            "SINGLE": "S",
            "MARRIED": "M",
            "SEPARATED": "E",
            "DIVORCED": "D"
        },
        "InsuranceProvider": {
            "OTHERS": "4",
        },
        "Status": {
            "ACTIVE": "ACTIVE"
        },
        "CourseSessionStatus": {
            "ACTIVE": "1"
        },
        "Claim_Action": {
            "DRAFT": "Save Draft",
            "DELETE": "Delete Report",
            "SUBMIT": "Submit Report",
            "BACK": "Back",
            "REJECT": "Reject",
            "PUSHBACK": "Push Back",
            "APPROVE": "Approve"

        },
        "DependentType": {
            "ANGGOTA": "1",
            "DEPENDENT": "2"
        },
        "Relationship": {
            "SPOUSE": "01",
            "CHILD": "02",
            "FATHER": "03",
            "MOTHER": "04",
            "SIBLING": "05",
            "RELATIVES": "06",
            "ADDITIONAL_SPOUSE": "07"
        },
        "MarriageCategory": {
            "SINGLE": "01",
            "MARRIED_NO_CHILDREN": "02",
            "MARRIED_1_TO_3_CHILDREN": "03",
            "MARRIED_4_OR_MORE_CHILDREN": "04"
        },
        "ConfigAccess":
            [
                "ZRISK", "ZREQUEST_TYPE", "ZCLAIM_TYPE", "ZNUM_RANGE", "ZCLAIM_CATEGORY",
                "ZSTATUS", "ZLODGING_CAT", "ZROOM_TYPE", "ZCOUNTRY", "ZAREA",
                "ZMARITAL_STAT", "ZVEHICLE_TYPE", "ZJOB_GROUP", "ZSTATE", "ZDEPARTMENT",
                "ZROLE", "ZUSER_TYPE", "ZEMP_TYPE", "ZFLIGHT_CLASS", "ZEMP_MASTER",
                "ZREGION", "ZSUBMISSION_TYPE", "ZLENDER_NAME", "ZHOUSING_LOAN_SCHEME",
                "ZPERDIEM_ENT", "ZEMP_CA_PAYMENT", "ZBRANCH", "ZPROJECT_HDR", "ZMARITAL_CAT",
                "ZEMP_RELATIONSHIP", "ZINDIV_GROUP", "ZMATERIAL_GROUP", "ZLOC_TYPE",
                "ZOFFICE_DISTANCE", "ZOFFICE_LOCATION", "ZRATE_KM", "ZEMP_DEPENDENT",
                "ZREJECT_REASON", "ZCURRENCY", "ZVEHICLE_OWNERSHIP", "ZTRAVEL_DAYS",
                "ZMETER_CUBE", "ZFARE_TYPE", "ZHOTEL_LODGING", "ZCLAIM_BASIS",
                "ZEMP_DEPENDENT_TYPE", "ZPOSITION_EVENT_REASON", "ZSPORTS_REPRESENTATION",
                "ZFAMILY_TIMING", "ZTRAVEL_TYPE", "ZTRANSPORT_PASSING", "ZTRANSFER_MODE",
                "ZSTUDY_LEVELS", "ZPROFESIONAL_BODY", "ZINSURANCE_PACKAGE", "ZINSURANCE_PROVIDER",
                "ZVEHICLE_CLASS", "ZMOBILE_CATEGORY_PURPOSE", "ZBUDGET", "ZDB_STRUCTURE",
                "ZDISBURSEMENT_STATUS", "ZCONSTANTS", "ZROLEHIERARCHY", "ZELIGIBILITY_RULE",
                "ZWORKFLOW_STEP", "ZWORKFLOW_RULE", "ZTRAIN_COURSE_PART", "ZEMP_PENDING_LIST", "ZSUBSTITUTION_RULES_CONFIG",
                "ZCORPORATE_CARD", "ZCORPORATE_CARD_ADVANCED", "ZCLAIM_TYPE_ITEM_CHARGING_CC"
            ],
        "ExcludeField":
        {
            "CLAIM_TYPE_ITEM_ID": "claim_type_item_id",
            "CLAIM_TYPE_ID": "claim_type_id",
            "CLAIM_ID": "claim_id",
            "CLAIM_SUB_ID": "claim_sub_id",
            "DESCR": "descr",
            "GL_ACCOUNT": "gl_account",
            "COST_CENTER": "cost_center",
            "IS_NEW": "is_new",
            "REQUEST_SUB_ID": "req_subid"
        },
        "Region": {
            "SEMENANJUNG": "01",
            "SABAH_SARAWAK": "02",
            "OVERSEA": "03"
        },
        "ViewName": {
            "ZREGION": "ZREGION"
        },
        "FareType":
        {
            "BUS": "01",
            "EHAILING": "02",
            "FERRY": "03",
            "FLIGHT": "04",
            "TRAIN": "05",
            "TAXI": "06"
        },
        "CurrencyCode": {
            "MYR": "MYR",
            "USD": "USD"
        }, 
        "DependentIndicator": {
            "Spouse_Child": "IND1"
        },
        "LenderName":{
            "FINANCIAL_INSTITUTION" : "FN"
        },
        "ModeOfTransfer":{
            "DALAM_STESEN": "DALAM_STESEN",
            "LUAR_STESEN": "LUAR_STESEN",
            "WILAYAH": "WILAYAH"
        },
        "FlightClass": {
            "FIRSTCLASS": "01",
            "BUSINESS": "02",
            "ECONOMY": "03"
        },
        "TravelAloneOrWithFamily": {
            "ALONE": "1",
            "WITH_FAMILY": "2",
            "ALONE_DESC": "Alone",
            "WITH_FAMILY_DESC": "With Family"
        },
        "TravelWithFamilyNowOrLater": {
            "NOW": "1",
            "LATER": "2",
            "LATER_DESC": "Travel with Family on Later Date",
            "NOW_DESC": "Travel with Family Now"
        }, 
        "PARSpecialFieldVisibilityForElaunTukar": {
            "NumberOfFamilyMember": "i_no_of_family_member",
            "NumberOfTraveller": "i_no_of_traveler"
        },
        "RequestFormFields": {
            "NO_OF_TRAVELERS": "input_no_of_traveler",
            "KILOMETER": "input_kilometer"
        },
        "ElaunTukarStatus": {
            "ALLOWED_CREATION": "01",
            "ALLOWED_FAMILY_NOW_ONLY": "02",
            "ON_GOING": "03",
            "NOT_ALLOWED": "04"
        },
        "Age": {
            "EIGHTEEN": "18",
            "NINETEEN": "19",
            "TWENTY_FIVE": "25"
        },
        "ClaimTypeItemDesc": {
            "AFIDAVIT": "Tuntutan Afidavit",
            "ALATULIS": "Alatulis & Percetakan",
            "BACAAN": "Bahan Bacaan & Rujukan",
            "BAGAI": "Pelbagai",
            "BEG_BIMBIT": "Pembelian Beg Bimbit",
            "BIL_AIR": "Bil Air Bangunan Disewa",
            "BRAND_CO": "Brand Collateral",
            "BYRN_SAKSI": "Perbelanjaan Saksi",
            "BYR_YURAN": "Bayaran Yuran Sijil",
            "B_BERKUNCI": "Beg Berkunci",
            "CAJ_BAHAN": "Caj Penghantaran Bahan Bacaan",
            "CASH_REPAY": "Cash Repayment",
            "CERAMAH": "Elaun Penceramah Dalaman",
            "CERAMAH_L": "Bayaran Penceramah Luar KWSP",
            "DAFTAR_KEN": "Nombor Pendaftaran Kenderaan",
            "DARAT": "Elaun Pengangkutan Darat",
            "DATA_LINE": "Talian Data Komputer & Lain-Lain",
            "DOBI": "Dobi",
            "DUTI_SETEM": "Duti Setem",
            "ELEKTRIK": "Bil Elektrik Bangunan Sendiri",
            "EVENTS": "Events",
            "EXCESS": "Excess Baggage",
            "EXT_ENGAGE": "Ext. Engagement/Events",
            "E_PENGAKUT": "Elaun Pengangkutan",
            "FIN_LIT": "Financial Literacy Campaign",
            "FIRST_AID": "First Aid Kit",
            "FLIGHT_L": "Tambang Kapal Terbang Tempatan",
            "FLIGHT_O": "Tambang Kapal Terbang Antarabangsa",
            "FLIGHT_WIL": "Kapal Terbang Wilayah Asal",
            "GALAKAN": "Elaun Galakan",
            "GDL": "Lesen GDL Kelas E (MT)",
            "GELNGGANG": "Sewa Gelanggang",
            "HANTAR": "Caj Penghantaran Surat Khabar",
            "HIASAN": "Hiasan Kaunter",
            "HIASAN_BGN": "Hiasan Bangunan Sendiri",
            "HIAS_BGN_S": "Hiasan Bangunan Disewa",
            "HOTEL_L": "Hotel Dalam Negeri",
            "HOTEL_O": "Hotel Oversea",
            "I-PAD": "Tuntutan Bil iPad",
            "IKLAN_PUB": "Iklan dan Penerbitan",
            "INSURANCE": "Insurance",
            "ISTIADAT": "Elaun Pakaian Istiadat",
            "JALUR_LEB": "Jalur Lebar",
            "JAM": "Jam Dinding",
            "JAMUAN_O": "Jamuan Ringan Program Outreach",
            "JAMUAN_R": "Jamuan Ringan",
            "JENAZAH": "Kemudahan Membawa Jenazah",
            "JKKP": "Program JKKP",
            "KATERER": "Bayaran Katerer",
            "KECERIAAN": "Keceriaan Kaunter",
            "KEMATIAN": "Bantuan Kebajikan Kematian",
            "KERAIAN": "Tuntutan Keraian KWSP Cawangan",
            "KESIHATAN": "Program Promosi Kesihatan",
            "KILOMETER": "Kilometer",
            "KM": "Kilometer",
            "KURIER": "Bayaran Perkhidmatan Kurier",
            "LAPOR_THN": "Laporan Tahunan",
            "LAUNDRY": "Tuntutan Dobi",
            "LAUT": "Elaun Pengangkutan Laut",
            "LEARN": "Learning Award",
            "LESEN": "Lesen & Cukai Jalan",
            "LESENPAPAN": "Lesen Papan Tanda",
            "LODGING_L": "Elaun Lodging Tempatan",
            "LODG_O": "Lodging Oversea",
            "LOD_TUKAR": "Elaun Lodging Pertukaran",
            "MAHKAMAH": "Elaun Pakaian Mahkamah",
            "MAKAN_L": "Elaun Makan/Harian Tempatan",
            "MAKAN_O": "Elaun Makan/Harian Antarabangsa",
            "MAKLUMAT": "Carian Maklumat Ahli/Majikan",
            "MATAWANG": "3% Kerugian Matawang",
            "MED_ADVANCE": "Medical Advance",
            "MISC": "Pelbagai",
            "MKN_LOAN": "Elaun Makan",
            "MKN_TUKAR": "Elaun Makan Pertukaran-Arahan Pengurusan",
            "ONLINE_CRT": "Online Certification",
            "ONLINE_L": "Online Learning",
            "PENGHARGAAN": "Majlis Penghargaan Kepada Majikan",
            "PARKING": "Parking",
            "PEDU": "Post Education Assistance",
            "PELANGGAN": "Program Hari Pelanggan",
            "PELBAGAI": "Belanja Pelbagai",
            "PEM_PINDAH": "Pemberian Perpindahan",
            "PENY.KOMP": "Penyelenggaraan Perkakasan Komputer",
            "PENY._PEJ": "Penyelenggaraan Peralatan Kelengkapan Pejabat",
            "PENYGGARAN": "Perabot dan Kelengkapan",
            "PETROL": "Petrol",
            "PINDAH": "Pemberian Perpindahan",
            "PKN_PANAS": "Elaun Pakaian Panas",
            "POS": "Belanja Pos",
            "PROMOSI": "Product Promotions",
            "PUNSIAN_BG": "Pengungsian Bangunan",
            "RUNCIT": "Belanja Runcit",
            "SELENGGARA": "Penyelenggaraan Kenderaan Pejabat / Lesen",
            "SERVICES": "Caj Perkhidmatan",
            "SEWA": "Bayaran Sewa Dewan Utk Promotion At Hall",
            "SEWAPETAK": "Sewa Petak Kereta",
            "SUMPAH": "Yuran Pesuruhjaya Sumpah",
            "S_K.KELAB": "Kemudahan Keahlian Kelab",
            "S_KHABAR": "Pembelian Surat Khabar",
            "S_VALUE": "Shared Value Internalization",
            "TAKLIMAT": "Taklimat Umum",
            "TAMBANG": "Tambang",
            "TAX": "Yuran Ejen Percukaian",
            "TELEFON": "Telefon / Internet",
            "TELEFON_B": "Elaun Telefon",
            "THERMO": "Thermometer",
            "TIPS": "Tips, Gratuities/Porterage",
            "TOLL": "Toll",
            "TRAVEL_INSURANCE": "Medical Travel Insurance",
            "VISA": "Visa & Passport",
            "YURAN": "Yuran Penyertaan Bagi Tugas Rasmi",
            "YURAN_KLJ": "Bayaran Yuran KLJ",
            "INSURANCE": "INSURANCE"
        },
        "FrequencyCheckClaimTypeItem": {
            "MAHKAMAH": "MAHKAMAH",
            "PKN_PANAS": "PKN_PANAS",
            "FLIGHT_WIL": "FLIGHT_WIL",
            "ISTIADAT": "ISTIADAT",
            "GALAKAN": "GALAKAN"
        },
        "TransportPassing": {
            "DALAM_STESEN": "1",
            "LUAR_STESEN": "2",
            "FLIGHT": "3"
        },
        "SubmissionOwnerType": {
            "REQUESTOR": "Requestor",
            "CLAIMANT": "Claimant"
        },
        "SpecialApprover" : {
            "VERIFIER" : "Verifier"
        },
        "SuccessFactorCompanyCode": {
            "EPFSFUAT" : "https://hcm-ap20.hr.cloud.sap/login?company=EPFSFUAT",
            "EPFSFPRD" : "https://hcm-ap20.hr.cloud.sap/login?company=EPFSFPRD"
        },
        "RelationshipType": {
            "SPOUSE": "01",
            "CHILD": "02",
            "ADDITIONAL_SPOUSE": "07"
        },
        "PeduResult": {
            "EXCEEDED": "EXCEEDED",
            "NOT_EXCEEDED": "NOT_EXCEEDED"
        },

        "TravelClaimType" :{
            "DLM_NEGARA" : "DLM_NEGARA",
            "LUAR_NEGARA" : "LUAR_NEGARA",
            "KURSUS_DLM_NEGARA" : "KURSUS_DLM_NEGARA",
            "KURSUS_LUAR_NEGARA" : "KURSUS_LUAR_NEGARA"
        },

        "TravelClaimItems" : {
            "FLIGHT_L" : "FLIGHT_L",
            "HOTEL_L" : "HOTEL_L",
            "YURAN" : "YURAN",
            "CASH_REPAY"  : "CASH_REPAY",
            "DOBI" : "DOBI",
            "TAMBANG" : "TAMBANG",
            "MISC" : "MISC",
            "PARKING" : "PARKING",
            "EXCESS" : "EXCESS",
            "FLIGHT_O" : "FLIGHT_O",
            "HOTEL_O" : "HOTEL_O",
            "PELBAGAI" : "PELBAGAI",
            "SERVICES" : "SERVICES",
            "TELEFON" : "TELEFON",
            "VISA" : "VISA",
        },
        "StatementDueInfo" : {
            "GL_CODE" : "214229",
            "MATERIAL_CODE" : "NA"
        },
        "CashBackInfo" : {
            "GL_CODE" : "690003",
            "MATERIAL_CODE" : "NA",
            "COST_CENTER" : "100050505"
        },
        "ServiceTaxInfo" : {
            "GL_CODE" : "721001",
            "MATERIAL_CODE" : "721001006",
            "COST_CENTER" : "100050505"
        },
        "InsuranceMedicalProvider": {
            "OTHERS": "4",
        },
        "MedicalAdvanceInfo": {
            "COST_CENTER": "100000000",
            "GL_ACCOUNT": "214230"
        },
        "WorkflowArea": {
            "WORKFLOW_GENERAL"          : "WORKFLOW_GENERAL",
            "WORKFLOW_DETERMINATION"    : "WORKFLOW_DETERMINATION",
            "APPROVER_DETERMINATION"    : "APPROVER_DETERMINATION",
            "WORKFLOW_TABLE_SAVING"     : "WORKFLOW_TABLE_SAVING",
            "WORKFLOW_NOTIFICATION"     : "WORKFLOW_NOTIFICATION",
            "WORKFLOW_ACTION"           : "WORKFLOW_ACTION",
            "BUDGET_CHECKING"           : "BUDGET_CHECKING",
            "BUDGET_ACTUALIZATION"      : "BUDGET_ACTUALIZATION"
        }

    }
});