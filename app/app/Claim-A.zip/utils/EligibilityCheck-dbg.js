sap.ui.define([
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/core/ValueState",
	"sap/ui/core/format/NumberFormat",
	"sap/ui/model/Filter", 
	"sap/ui/model/FilterOperator", 
	"sap/ui/model/Sorter",
	"claima/utils/Constants",
	"claima/utils/Utility"
], function (MessageBox,
	Fragment,
	ValueState,
	NumberFormat,
	Filter,
	FilterOperator,
	Sorter,
	Constants,
	Utility) {
	"use strict";

	return {

		/* =========================================================
		* Eligibility Checking Function
		* ======================================================= */

		/**
		 * Generate the payload needed for eligibility check.
		 * For WILAYAH_ASAL, the state field is mapped to the eClaim STATE_ID via ZSTATE.
		 * @public
		 * @param {Object} oController       - Calling controller
		 * @param {string} sSubmissionType   - Submission type prefix (Request or Claim)
		 * @param {Object} oClaimItemPayload - Claim item to duplicate (fallback when no item model data)
		 * @returns {Promise<Object[]>} One payload per participant, with CheckFields populated
		 */
		generateEligibilityCheckPayload: async function (oController, sSubmissionType, oClaimItemPayload) {
			let oItemData, aItemPartData, sRecordId, sRecordSubId, sClaimType, sClaimTypeItem, oMapping, sStateKey;

			switch (sSubmissionType) {
				case Constants.SubmissionTypePrefix.REQUEST:
					oItemData = oController._oReqModel.getProperty('/req_item');
					aItemPartData = oController._oReqModel.getProperty('/participant');
					sRecordId = oController._oReqModel.getProperty('/req_header/reqid');
					sRecordSubId = oItemData?.req_subid || null;
					sClaimType = oController._oReqModel.getProperty('/req_header/claimtype');
					sClaimTypeItem = oItemData.claim_type_item_id;
					sStateKey = "to_state";

					oMapping = {
						// field                : db technical name
						"vehicle_ownership": "VEHICLE_OWNERSHIP_ID",
						"est_amount": "ELIGIBLE_AMOUNT",
						"cat_purpose": "MOBILE_PHONE_BILL",
						"sss": "REGION_ID",
						"no_of_days": "TRAVEL_DAYS_ID",
						"rate_per_kilometer": "RATE",
						"room_type": "ROOM_TYPE_ID",
						"flight_class": "FLIGHT_CLASS_ID",
						"marriage_cat": "MARRIAGE_CATEGORY",
						"fare_type": "FARE_TYPE_ID",
						"vehicle_class": "TRANSPORT_CLASS",
						"no_of_hours": "TRAVEL_HOURS",
						"no_of_traveler": "TOTAL_TRAVELLER",
						"trip_start_date": "RECEIPT_DATE",
						"lodging_cat": "LODGING_CATEGORY",
						"vehicle_ownership_id": "VEHICLE_OWNERSHIP_ID",
						"to_state": "TO_STATE_ID",
						"dependent_national_id": "DEPENDENT_NATIONAL_ID",
						"policy_year": "POLICY_YEAR"
					};
					break;

				case Constants.SubmissionTypePrefix.CLAIM: {
					const sEmpId = oController._oSessionModel.getProperty("/userId");
					const oHeaderModel = oController.getView().getModel("claimsubmission_input");
					const oItemModel = oController.getView().getModel("claimitem_input");
					aItemPartData = [{ PARTICIPANTS_ID: sEmpId }];
					oItemData = oItemModel?.getProperty('/claim_item') || oClaimItemPayload;
					sRecordId = oHeaderModel.getProperty("/claim_header/claim_id");
					sRecordSubId = oItemData?.claim_sub_id;
					sClaimType = oHeaderModel.getProperty('/claim_header/claim_type_id');
					sClaimTypeItem = oItemData.claim_type_item_id;
					sStateKey = "to_state_id";
					const sAmount = sClaimTypeItem === Constants.ClaimTypeItem.PEM_PINDAH ? "actual_amount" : "amount";
					var receipt_date = oItemData.receipt_date ? "receipt_date" : "bill_date"

					oMapping = {
						// field                        : db technical name
						[sAmount]: "ELIGIBLE_AMOUNT",
						"no_of_days": "TRAVEL_DAYS_ID",
						"fare_type_id": "FARE_TYPE_ID",
						"vehicle_class_id": "TRANSPORT_CLASS",
						"flight_class": "FLIGHT_CLASS_ID",
						"room_type": "ROOM_TYPE_ID",
						"mobile_category_purpose_id": "MOBILE_PHONE_BILL",
						[receipt_date]: "RECEIPT_DATE",
						"no_of_hours": "TRAVEL_HOURS",
						"region": "REGION_ID",
						"number_of_travellers": "TOTAL_TRAVELLER",
						"lodging_category": "LODGING_CATEGORY",
						"funeral_transportation": "FUNERAL_TRANSPORTATION",
						"dependent_type": "DEPENDENT_TYPE",
						"vehicle_ownership_id": "VEHICLE_OWNERSHIP_ID",
						"country": "COUNTRY",
						"insurance_package_id": "INSURANCE_PACKAGE_ID",
						"dependent": "DEPENDENT",
						"phone_no": "PHONE_NO",
						"to_state_id": "TO_STATE_ID",
						"dependent_national_id": "DEPENDENT_NATIONAL_ID",
						"policy_start_date": "POLICY_START_DATE",
						"policy_year": "POLICY_YEAR"
					};
					break;
				}

				default:
					return [];   // unknown submission type: nothing to check
			}

			// State-of-origin mapping applies to WILAYAH_ASAL only
			let sMappedState;
			if (sClaimType === Constants.ClaimType.WILAYAH_ASAL) {
				sMappedState = await this._mapStateOfOrigin(oController, oItemData[sStateKey]);
			}

			const aActiveFields = Object.entries(oMapping).map(([sKey, sTargetName]) => {
				// Use the mapped state for the state field; all other fields unchanged
				const vVal = (sKey === sStateKey && sMappedState !== undefined) ? sMappedState : oItemData[sKey];
				return { fieldName: sTargetName, value: String(vVal), result: null };
			});

			const aPayload = [];
			aItemPartData.forEach((row) => {
				if (row.PARTICIPANTS_ID) {
					// Copy fields per participant so the shared array is not mutated
					const aNewActiveFields = aActiveFields.map(field => {
						const oNewField = { ...field };
						if (oNewField.fieldName === Constants.EntitiesFields.ELIGIBLE_AMOUNT &&
							sSubmissionType === Constants.SubmissionTypePrefix.REQUEST) {
							oNewField.value = String(row.ALLOCATED_AMOUNT);
						}
						return oNewField;
					});

					aPayload.push({
						EmpId: row.PARTICIPANTS_ID,
						RecordId: sRecordId,
						RecordSubId: sRecordSubId,
						ClaimType: sClaimType,
						ClaimTypeItem: sClaimTypeItem,
						CheckFields: aNewActiveFields
					});
				}
			});

			return aPayload;
		},

		/**
		 * Maps a state value to the eClaim STATE_ID using ZSTATE.STATE_OF_ORIGIN_ID.
		 * @private
		 * @param {Object} oController - Calling controller (used to get the OData V4 model)
		 * @param {string} sStateId    - State value to map
		 * @returns {Promise<string>} 
		 */
		async _mapStateOfOrigin(oController, sStateId) {
			if (!sStateId) return sStateId;

			const oModel = oController.getOwnerComponent().getModel();
			const oBinding = oModel.bindList(
				"/ZSTATE",
				null,
				[new Sorter("STATE_ID")],                                   // stable "first match"
				[new Filter("STATE_ID", FilterOperator.EQ, String(sStateId).trim())],
				{ $select: "STATE_OF_ORIGIN_ID" }
			);

			try {
				const [oCtx] = await oBinding.requestContexts(0, 1);
				return oCtx?.getProperty("STATE_OF_ORIGIN_ID") ?? sStateId;
			} catch (oError) {
				return sStateId;                                            // don't block the check on lookup failure
			} finally {
				oBinding.destroy();
			}
		},

		/**
		* Validation for eligibility
		* @public
		* @param {Object} oController - Object Model from Controller;
		* @param {String} aPayload - the generated payload from the EligibleScenarioCheck
		* @param {String} sSubmissionType - Submission Type of the request E.g Claim or Request
		* @returns {Boolean} Boolean to determine if there is an error with the checking
		*/
		eligibilityHandling: function (oController, aPayload, sSubmissionType) {
			let oDBToUIControlMap = {};

			switch (sSubmissionType) {
				case Constants.SubmissionTypePrefix.REQUEST:
					oDBToUIControlMap = {
						"VEHICLE_OWNERSHIP_ID": "i_vehicle_ownership",
						"ELIGIBLE_AMOUNT": "TABLE_ALLOC_AMOUNT", // <-- Special flag for table handling
						"MOBILE_PHONE_BILL": "i_category_purpose",
						"REGION_ID": "i_sss",
						"RATE": "i_rate_per_kilometer",
						"ROOM_TYPE_ID": "i_room_type",
						"FLIGHT_CLASS_ID": "i_flight_class",
						"MARRIAGE_CATEGORY": "i_marriage_cat",
						"TRANSPORT_CLASS": "i_vehicle_class"
					};
					break;

				case Constants.SubmissionTypePrefix.CLAIM:
					oDBToUIControlMap = {
						"ELIGIBLE_AMOUNT": "input_claimdetails_input_amount",
						"TRAVEL_DAYS_ID": "input_claimdetails_input_no_of_days",
						"FARE_TYPE_ID": "select_claimdetails_input_fare_type_id",
						"TRANSPORT_CLASS": "select_claimdetails_input_vehicle_class_id",
						"FLIGHT_CLASS_ID": "select_claimdetails_input_flight_class",
						"ROOM_TYPE_ID": "select_claimdetails_input_room_type",
						"MOBILE_PHONE_BILL": "select_claimdetails_input_mobile_category_purpose_id",
						"RECEIPT_DATE": "datepicker_claimdetails_input_receipt_date",
						"VEHICLE_OWNERSHIP_ID": "select_claimdetails_input_vehicle_ownership_id",
						"COUNTRY": "select_claimdetails_input_country"
					};
					break;

				default:
					break;
			}

			const aErrorMessages = [];

			const getControl = (sId) => {
				if (!sId || sId === "TABLE_ALLOC_AMOUNT") return null;
				const oFormElement = Fragment.byId("request", sId) || oController.byId(sId);
				return oFormElement?.getFields?.()[0] || oFormElement;
			};

			Object.values(oDBToUIControlMap).forEach(sId => {
				if (sId === "TABLE_ALLOC_AMOUNT") {
					this._setTableValueState(oController, null, ValueState.None);
				} else {
					const oInputControl = getControl(sId);
					if (oInputControl?.setValueState) {
						oInputControl.setValueState(ValueState.None);
						oInputControl.setValueStateText("");
					}
				}
			});

			var oFloatFormat = NumberFormat.getFloatInstance({
				minFractionDigits: 2,
				maxFractionDigits: 2,
				groupingEnabled: true
			});

			aPayload.forEach((oSinglePayload) => {
				const aCheckFields = oSinglePayload.CheckFields || [];
				const sEmpId = oSinglePayload.EmpId;
				const sClaimType = oSinglePayload.ClaimType;
				const sClaimTypeItem = Constants.ClaimTypeItemDesc[oSinglePayload.ClaimTypeItem] || oSinglePayload.ClaimTypeItem;

				aCheckFields.forEach((oField) => {
					if (oField.result === true || oField.result === null) {
						return;
					}

					var sErrorField = Constants.ApprovalProcess[oField.fieldName] || oField.fieldName;
					let sErrorMsg;

					switch (oField.fieldName) {
						case Constants.EntitiesFields.ELIGIBLE_AMOUNT:
							if (typeof oField.result === "number" || (typeof oField.result === "object" && oField.result !== null)) {
								if (sClaimType === Constants.ClaimType.POST_EDUCATION_ASSISTANCE) {
									sErrorMsg = Utility.getText("eligibility_validation_amount_pedu", [oFloatFormat.format(oField.result.defaultLimit), oFloatFormat.format(oField.result.limit)]);
								} else {
									sErrorMsg = Utility.getText("eligibility_validation_amount", [oFloatFormat.format(oField.result), sEmpId]);
								}
							} else{
								// backend found no eligibility rule for the employee (e.g. grade not configured)
								sErrorMsg = Utility.getText("eligibility_validation_rule_not_found", [sClaimTypeItem]);
							}
							break;

						case Constants.EntitiesFields.TRAVEL_DAYS_ID:
							sErrorMsg = Utility.getText("eligibility_validation_travel_days", [oField.result, sClaimTypeItem, sEmpId]);
							break;

						case Constants.EntitiesFields.FLIGHT_CLASS_ID:
							sErrorMsg = Utility.getText("eligibility_validation_flight_class", [sEmpId]);
							break;

						case Constants.EntitiesFields.ROOM_TYPE_ID:
							sErrorMsg = Utility.getText("eligibility_validation_room_type", [sEmpId]);
							break;

						case Constants.EntitiesFields.VEHICLE_OWNERSHIP_ID:
							sErrorMsg = Utility.getText("eligibility_validation_vehicle_ownership", [oField.value, sEmpId]);
							break;

						case Constants.EntitiesFields.COUNTRY:
							sErrorMsg = Utility.getText("eligibility_validation_country", [oField.value, sEmpId]);
							break;

						case Constants.EntitiesFields.PHONE_NO:
							sErrorMsg = Utility.getText("eligibility_validation_phone_no", [oField.value, sEmpId]);
							break;

						case Constants.EntitiesFields.TO_STATE_ID:
							if (oField.result === Constants.Default.NA) {
								sErrorMsg = Utility.getText("eligibility_validation_to_state_not_found", [sEmpId]);
							} else {
								sErrorMsg = Utility.getText("eligibility_validation_to_state", [sEmpId]);
							}
							break;

						case Constants.EntitiesFields.TRAVEL_HOURS:
							sErrorMsg = Utility.getText("eligibility_validation_travel_hours_insufficient", [oField.result]);
							break;


						default:
							sErrorMsg = Utility.getText("eligibility_validation_default_msg", [sErrorField, sEmpId]);
							break;
					}
					if (!aErrorMessages.includes(sErrorMsg) && sErrorMsg) {
						aErrorMessages.push(sErrorMsg);
					}

					const sMappedId = oDBToUIControlMap[oField.fieldName];

					if (sMappedId === "TABLE_ALLOC_AMOUNT") {
						this._setTableValueState(oController, sEmpId, ValueState.Error);
					} else {
						const oInputControl = getControl(sMappedId);
						if (oInputControl?.setValueState) {
							oInputControl.setValueState(ValueState.Error);
						}
					}
				});
			});

			const bIsEligible = aErrorMessages.length === 0;

			if (!bIsEligible) {
				// Build one bullet per error, each on its own line
				const sFormattedErrors = aErrorMessages
					.map(sMsg => "• " + sMsg)
					.join("\n");
				MessageBox.error(Utility.getText("req_e_validation_msg") + sFormattedErrors, {
					title: Utility.getText("req_e_validation_title"),
					actions: [MessageBox.Action.CLOSE]
				});
			}

			return bIsEligible;
		},

		_setTableValueState(oController, sEmpIdToMatch, sValueState) {
			const oTable = Fragment.byId("request", "req_participant_table") || oController.byId("req_participant_table");
			if (!oTable) return;

			oTable.getRows().forEach(oRow => {
				const oContext = oRow.getBindingContext("request");
				if (oContext) {
					const sRowEmpId = oContext.getProperty("PARTICIPANTS_ID");

					if (!sEmpIdToMatch || sRowEmpId === sEmpIdToMatch) {
						oRow.getCells().forEach(oCell => {
							if (oCell.getId().includes("alloc_amount") && oCell.setValueState) {
								oCell.setValueState(sValueState);
							}
						});
					}
				}
			});
		},

		/**
		 * Check the Specific Claim Type Eligibility prior to any claim or PAR creation or submission.
		 * @param {Object} oDataModel 
		 * @param {String} sClaimType 
		 * @param {Boolean} bIsClaim 
		 * @returns Boolean
		 */
		checkClaimTypeEligibility: async function (oDataModel, sClaimType, bIsClaim) {
			let oFunction;
			switch (sClaimType) {
				case Constants.ClaimType.ELAUN_TUKAR:
					oFunction = oDataModel.bindContext("/checkElaunTukarEligible(...)");
					oFunction.setParameter("IS_CLAIM", bIsClaim);
					break;
				case Constants.ClaimType.GALAKAN:
					oFunction = oDataModel.bindContext("/checkGalakanEligible(...)");
					break;
				default:
					return false;
			}

			try {
				await oFunction.execute();
				const oContext = oFunction.getBoundContext();
				return oContext.getObject().value;

			} catch (oError) {
				return false;
			}
		}

	};
});