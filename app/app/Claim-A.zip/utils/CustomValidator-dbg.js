sap.ui.define([
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "claima/utils/Constants",
    "claima/utils/ClaimUtility",
    "claima/utils/Utility",
    "claima/utils/RequestUtility",
    "claima/utils/DateUtility"
], function (
    MessageBox,
    Fragment,
    Constants,
    ClaimUtility,
    Utility,
    RequestUtility,
    DateUtility
) {
    "use strict";

    return {
        /**
         * Initialize the Utility 
         * @public
         */
        init: function (oOwnerComponent, oView) {
            this._oOwnerComponent = oOwnerComponent;
            this._oView = oView;
        },

        /**
         * Validates all common and scenario-specific rules during submission
         *
         * This method retrieves the necessary validation data from
         * `this._oOwnerComponent`, including both common fields and scenario-based
         * input values. It is to ensure data consistency before proceeding with submission or
         * further processing.
         * @public
         */
        validate: async function (sSubmissionType) {
            var bCanProceed = true;
            // Common validations (Applicable for both scenarios)

            // Type and Item Type checking (Applicable for both scenarios))

            // Scenario-based checking (Only limited to certain submission type)
            switch (sSubmissionType) {
                case Constants.SubmissionTypePrefix.REQUEST:

                    var oReqModel = this._oOwnerComponent.getModel("request");
                    var sClaimType = oReqModel.getProperty("/req_header/claimtype");
                    var sClaimTypeItem = oReqModel.getProperty("/req_item/claim_type_item_id");

                    // check number of traveller
                    if (sClaimType === Constants.ClaimType.ELAUN_TUKAR) {
                        var iNumberOfFamily = oReqModel.getProperty("/req_item/no_of_family_member");
                        var iNumberOfTraveler = oReqModel.getProperty("/req_item/no_of_traveler");

                        if (iNumberOfTraveler > iNumberOfFamily) {
                            var oInput = this._oView.byId("input_no_of_traveler");
                            oInput.setValueState("Error");
                            oInput.setValueStateText(Utility.getText("req_vs_e_exceed_no_of_family", [iNumberOfFamily]));
                            MessageBox.error(Utility.getText("req_vs_e_exceed_no_of_family", [iNumberOfFamily]));
                            bCanProceed = false;
                        }
                    }

                    // departure/arrival time checking (same time only blocked for international flight)
                    if (!this._validateFlightTimes(
                        oReqModel.getProperty("/req_item/departure_time"),
                        oReqModel.getProperty("/req_item/arrival_time"),
                        sClaimTypeItem === Constants.ClaimTypeItem.FLIGHT_O
                    )) {
                        bCanProceed = false;
                    }
                    break;
                case Constants.SubmissionTypePrefix.CLAIM:
                    var oClaimSubmissionModel = this._oView.getModel("claimsubmission_input");
                    var oInputModel = this._oView.getModel("claimitem_input");
                    var sClaimTypeItem = oInputModel ? oInputModel.getProperty("/claim_item/claim_type_item_id") : null;
                    var oPropertyModel = this._oView.getModel("claimitem_property");

                    if (!!sClaimTypeItem) {
                        switch (sClaimTypeItem) {
                            case Constants.ClaimTypeItem.TELEFON_B:
                                if (!oInputModel.getProperty("/claim_item/disclaimer")) {
                                    MessageBox.error(Utility.getText("msg_claimdetails_no_check_disclaimer"));
                                    bCanProceed = false;
                                }
                                break;
                            case Constants.ClaimTypeItem.MATAWANG:
                                if (!oInputModel.getProperty("/claim_item/amount")) {
                                    MessageBox.error(Utility.getText("msg_claimsubmission_invalid_amount_in_claim_item"));
                                    bCanProceed = false;
                                    return;

                                }
                                break;
                            case Constants.ClaimTypeItem.MKN_LOAN:
                                if (oInputModel.getProperty("/claim_item/no_of_days") > 2) {
                                    MessageBox.error(Utility.getText("msg_claimsubmission_invalid_no_of_days_in_claim_item"));
                                    bCanProceed = false;

                                }
                                break;
                            case Constants.ClaimTypeItem.KM:
                                if (oInputModel.getProperty("/claim_item/km") < 0.01) {
                                    MessageBox.error(Utility.getText("msg_claimdetails_km_amount_zero"));
                                    bCanProceed = false;
                                    return;

                                }
                                break;

                            default:
                                break;
                        }
                    }

                    // the Amount (MYR) must not be zero (e.g. rate could not be determined for that date).
                    if (parseFloat(oInputModel.getProperty("/claim_item/amount")) <= 0 || oInputModel.getProperty("/claim_item/amount") === null || oInputModel.getProperty("/claim_item/amount") === undefined) {
                        MessageBox.error(Utility.getText("msg_claimdetails_amount_zero"));
                        bCanProceed = false;
                        return;

                    }

                    if (Object.values(Constants.ClaimTypeItemMakan).includes(sClaimTypeItem)) {
                        var nEntBfast = oInputModel.getProperty("/claim_item/travel_duration_day") - oInputModel.getProperty("/claim_item/provided_breakfast");
                        var nEntLunch = oInputModel.getProperty("/claim_item/travel_duration_day") - oInputModel.getProperty("/claim_item/provided_lunch");
                        var nEntDinner = oInputModel.getProperty("/claim_item/travel_duration_day") - oInputModel.getProperty("/claim_item/provided_dinner");

                        if (nEntBfast < 0 || nEntLunch < 0 || nEntDinner < 0) {
                            MessageBox.error(Utility.getText("msg_provided_meal_exceed"));
                            bCanProceed = false
                        }
                    }

                    if (oInputModel?.getProperty("/claim_item/receipt_date") < oClaimSubmissionModel?.getProperty("/claim_header/trip_start_date")) {
                        const bConfirm = await this.onShowConfirmation(Utility.getText("msg_claimdetails_receipt_date_before_trip_start_date"));
                        if (!bConfirm) {
                            bCanProceed = false;
                        }
                    }

                    if (oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") == Constants.ClaimType.ELAUN_TUKAR) {
                        if (oPropertyModel.getProperty("/number_of_traveller/is_visible") && oPropertyModel.getProperty("/no_of_family_member/is_visible")) {
                            if (oInputModel.getProperty("/claim_item/number_of_travellers") > oInputModel.getProperty("/claim_item/no_of_family_member")) {
                                MessageBox.error(Utility.getText("msg_number_of_traveller_exceed"));
                                bCanProceed = false
                            }
                        }
                    }

                    if (!!oInputModel?.getProperty("/claim_item/receipt_date") && this._oView.byId("datepicker_claimdetails_input_receipt_date").getVisible() && !!oClaimSubmissionModel?.getProperty("/claim_header/trip_end_date")) {
                        var dTripEndDate = this._getMaxReceiptDate(oClaimSubmissionModel);
                        var dReceiptDate = new Date(oInputModel.getProperty("/claim_item/receipt_date")).toLocaleDateString('en-CA');

                        if (dReceiptDate > dTripEndDate) {
                            MessageBox.error(Utility.getText("msg_claimsubmission_invalid_receipt_date"));
                            bCanProceed = false;
                        }
                    }

                    // departure/arrival time checking (same time only blocked for international flight)
                    if (!this._validateFlightTimes(
                        oInputModel?.getProperty("/claim_item/departure_time"),
                        oInputModel?.getProperty("/claim_item/arrival_time"),
                        sClaimTypeItem === Constants.ClaimTypeItem.FLIGHT_O
                    )) {
                        bCanProceed = false;
                    }

                    if (!!oInputModel && sClaimTypeItem === Constants.ClaimTypeItem.E_PENGAKUT) {
                        // check if previous claim with elaun pengangkutan has already been approved; if found, return message based on status
                        var sClaimStatus = await ClaimUtility.fetchUserClaimStatusElaunPengangkutan();
                        if (!!sClaimStatus) {
                            switch (sClaimStatus) {
                                case Constants.ClaimStatus.APPROVED:
                                    MessageBox.error(Utility.getText("error_msg_epengakut_already_approved"));
                                    bCanProceed = false;
                                    break;
                                case Constants.ClaimStatus.PENDING_APPROVAL:
                                    MessageBox.error(Utility.getText("error_msg_epengakut_already_pending"));
                                    bCanProceed = false;
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    // validate item date + time range (end must not be earlier than start)
                    var oItem = oInputModel.getProperty("/claim_item");
                    if ((oItem.start_date && oItem.start_time && oItem.end_date && oItem.end_time &&
                        DateUtility.parseDateTime(oItem.end_date, oItem.end_time) < DateUtility.parseDateTime(oItem.start_date, oItem.start_time)) ||
                        (oItem.trip_start_date && oItem.trip_start_time && oItem.trip_end_date && oItem.trip_end_time &&
                            DateUtility.parseDateTime(oItem.trip_end_date, oItem.trip_end_time) < DateUtility.parseDateTime(oItem.trip_start_date, oItem.trip_start_time))) {
                        MessageBox.error(Utility.getText("req_d_e_end_date_less_then_start_date"));
                        return false;
                    }

                    // // validate item date range
                    if (!!oInputModel?.getProperty("/claim_item/start_date") || !!oInputModel?.getProperty("/claim_item/end_date")) {
                        if (!this._isValidDateRange(oInputModel.getProperty("/claim_item/start_date"), oInputModel.getProperty("/claim_item/end_date"))) {
                            // stop claim details if incomplete
                            bCanProceed = false;
                        }
                    }

                    break;
                case Constants.SubmissionTypePrefix.REQUESTHEADER:
                    var oReqModel = this._oOwnerComponent.getModel("request");
                    RequestUtility.init(this._oOwnerComponent, this._oView)
                    //// trip start/end date (mandatory only when editable - see Common.setHeaderEditable)
                    if (this._oView.getModel("reqHeaderEditableModel").getProperty("/startTrip") ||
                        oReqModel.getProperty("/req_header/tripstartdate") || oReqModel.getProperty("/req_header/tripenddate")) {
                        if (!this._isValidDateRange(oReqModel.getProperty("/req_header/tripstartdate"), oReqModel.getProperty("/req_header/tripenddate"))) {
                            // stop claim submission if incomplete
                            bCanProceed = false;
                        }
                    }
                    const bIsEventDateRequired = RequestUtility.getEventDateRequired(oReqModel.getProperty("/req_header/reqtypeid"));
                    //// event start/end date (optional)
                    if (oReqModel.getProperty("/req_header/eventstartdate") || oReqModel.getProperty("/req_header/eventenddate") || bIsEventDateRequired) {
                        if (!this._isValidDateRange(oReqModel.getProperty("/req_header/eventstartdate"), oReqModel.getProperty("/req_header/eventenddate"))) {
                            // stop claim submission if incomplete
                            bCanProceed = false;
                        }
                    }
                    break;
                case Constants.SubmissionTypePrefix.CLAIMHEADER:
                    var oClaimSubmissionModel = this._oView.getModel("claimsubmission_input");

                    if (!!oClaimSubmissionModel) {
                        if (!this._isValidDateRange(oClaimSubmissionModel.getProperty("/claim_header/trip_start_date"), oClaimSubmissionModel.getProperty("/claim_header/trip_end_date"))) {
                            // stop claim submission if incomplete
                            bCanProceed = false;
                        }
                        //// event start/end date (optional)
                        if (oClaimSubmissionModel.getProperty("/claim_header/event_start_date") || oClaimSubmissionModel.getProperty("/claim_header/event_end_date")) {
                            if (!this._isValidDateRange(oClaimSubmissionModel.getProperty("/claim_header/event_start_date"), oClaimSubmissionModel.getProperty("/claim_header/event_end_date"))) {
                                // stop claim submission if incomplete
                                bCanProceed = false;
                            }
                        }

                        // existing claim items must still fall within the (possibly edited) header dates
                        // runs on both header save and claim submission
                        if (bCanProceed && !this._isReceiptDatesWithinHeaderRange(oClaimSubmissionModel)) {
                            bCanProceed = false;
                        }

                        var sClaimType = oClaimSubmissionModel ? oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") || oClaimSubmissionModel.getProperty("/claimtype/type") : null;
                        if (Object.values(Constants.ClaimTypeKursus).includes(sClaimType)) {
                            // course code pre-check
                            var sCourseCode = oClaimSubmissionModel.getProperty("/claim_header/course_code") || oClaimSubmissionModel.getProperty("/claimtype/course_code/course_id");
                            var sSessionNumber = oClaimSubmissionModel.getProperty("/claim_header/session_number") || oClaimSubmissionModel.getProperty("/claimtype/course_code/session_number");
                            var sActiveStatus = await ClaimUtility.checkExistingCourseCode(sCourseCode, sSessionNumber, this._oOwnerComponent.getModel("session").getProperty("/userId"), oClaimSubmissionModel.getProperty("/claim_header/claim_id"));
                            if (sActiveStatus === Constants.ClaimStatus.APPROVED || sActiveStatus === Constants.ClaimStatus.COMPLETED_DISBURSEMENT) {
                                MessageBox.error(Utility.getText("error_msg_course_already_approved"));
                                bCanProceed = false;
                            } else if (sActiveStatus === Constants.ClaimStatus.PENDING_APPROVAL) {
                                MessageBox.error(Utility.getText("error_msg_course_already_pending"));
                                bCanProceed = false;
                            } else if (!!sActiveStatus && sActiveStatus !== Constants.ClaimStatus.CANCELLED && sActiveStatus !== Constants.ClaimStatus.REJECTED) {
                                MessageBox.error(Utility.getText("error_msg_active_course_claim"));
                                bCanProceed = false;
                            }
                        }
                    }
                    break;
            }
            return bCanProceed;

        },
        onShowConfirmation: function (sPromptMessage) {
            return new Promise((oResolve) => {
                MessageBox.warning(
                    sPromptMessage,
                    {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        emphasizedAction: MessageBox.Action.OK,

                        onClose: function (sAction) {
                            if (sAction === MessageBox.Action.OK) {
                                oResolve(true);
                            } else {
                                oResolve(false);
                            }
                        }
                    }
                );
            });
            return Promise.resolve(true);
        },

        /**
         * Validates the departure and arrival time of a flight
         * Shared by both request and claim submission
         * @param {string|Date} vDeparture departure date time
         * @param {string|Date} vArrival arrival date time
         * @param {boolean} bCheckSameTime true to block departure and arrival time being the same
         * @returns {boolean} true if valid (or either value is empty / unparseable)
         * @private
         */
        _validateFlightTimes: function (vDeparture, vArrival, bCheckSameTime) {
            if (!vDeparture || !vArrival) {
                return true;
            }

            const iDiffMs = new Date(vArrival).getTime() - new Date(vDeparture).getTime();
            if (Number.isNaN(iDiffMs)) {
                return true;
            }

            if (iDiffMs < 0) {
                MessageBox.error(Utility.getText("req_d_e_arrival_time_departure_time"));
                return false;
            }

            if (bCheckSameTime && iDiffMs === 0) {
                MessageBox.error(Utility.getText("req_vs_e_invalid_flight_time"));
                return false;
            }

            return true;
        },

        /**
         * Latest allowed receipt date (YYYY-MM-DD) = header End Date, plus the same extra days the
         * item Start/End Date pickers allow for Kursus (see DateUtility.determineMaxDate):
         * Kursus Dlm Negara +1 day, Kursus Luar Negara +2 days.
         * @param {sap.ui.model.json.JSONModel} oClaimSubmissionModel claimsubmission_input model
         * @returns {Date} return the receipt date
         * @private
         */
        _getMaxReceiptDate: function (oClaimSubmissionModel) {
            var dMax = new Date(oClaimSubmissionModel.getProperty("/claim_header/trip_end_date"));
            var sClaimType = oClaimSubmissionModel.getProperty("/claim_header/claim_type_id");
            var iExtraDays = Constants.ClaimType.KURSUS_DLM_NEGARA === sClaimType ? 1 : Constants.ClaimType.KURSUS_LUAR_NEGARA === sClaimType ? 2 : 0;
            dMax.setDate(dMax.getDate() + iExtraDays);

            return DateUtility.toYMD(dMax);
        },

        /**
         * Check that the receipt date of every claim item is not later than the header End Date.
         * @private
         * @param {sap.ui.model.json.JSONModel} oClaimSubmissionModel claimsubmission_input model
         * @returns {boolean} true if all claim items are within range, false (with error message shown) otherwise
         */
        _isReceiptDatesWithinHeaderRange: function (oClaimSubmissionModel) {
            var sHeaderEnd = DateUtility.toYMD(oClaimSubmissionModel.getProperty("/claim_header/trip_end_date"));

            // missing/invalid header dates are reported by _isValidDateRange
            if (!sHeaderEnd) {
                return true;
            }

            var sMaxReceiptDate = this._getMaxReceiptDate(oClaimSubmissionModel);
            var aInvalidItems = [];
            (oClaimSubmissionModel.getProperty("/claim_items") || []).forEach(function (oItem) {
                var sReceiptDate = DateUtility.toYMD(oItem.receipt_date);
                if (sReceiptDate && sReceiptDate > sMaxReceiptDate) {
                    aInvalidItems.push("\u2022 " + oItem.claim_sub_id + " (" + DateUtility.formatDate(sReceiptDate, "dd-MMM-yyyy") + ")");
                }
            });

            if (aInvalidItems.length > 0) {
                MessageBox.error(Utility.getText("msg_claimheader_receipt_date_out_of_range", [
                    DateUtility.formatDate(sHeaderEnd, "dd-MMM-yyyy"),
                    aInvalidItems.join("\n")
                ]));
                return false;
            }
            return true;
        },

        /**
         * Check if start and end dates are empty
         * Check if start date is set before end date
         * @private
         * @param {string} sStartdate start date to be checked
         * @param {string} sEnddate end date to be checked
         * @returns {boolean} if start and end dates are valid, returns true, if dates are invalid, returns false
         */
        _isValidDateRange: function (sStartdate, sEnddate) {
            // check for missing value
            if (!sStartdate || !sEnddate) {
                MessageBox.error(Utility.getText("msg_daterange_missing"));
                return false;
            }
            else {
                // check if values can be converted to valid dates
                if (isNaN(new Date(sStartdate).getTime()) || isNaN(new Date(sEnddate).getTime())) {
                    MessageBox.error(Utility.getText("msg_daterange_missing"));
                    return false;
                }
            }

            // check if end date earlier than start date
            if (new Date(sStartdate) > new Date(sEnddate)) {
                MessageBox.error(Utility.getText("msg_daterange_order"));
                return false;
            }
            return true;
        },

        /**
         * Checks that every claim item has an amount greater than zero.
         * @public
         * @throws {Error} if any item amount is missing, non-numeric or <= 0
         */
        checkAllItemsAmount: function () {
            const aItems = this._oView.getModel("claimsubmission_input").getProperty("/claim_items") || [];
            const oInvalid = aItems.find((oItem) => !(Number(oItem.amount) > 0));
            if (oInvalid) {
                throw new Error(oInvalid.claim_type_item_id === Constants.ClaimTypeItem.MATAWANG
                    ? Utility.getText("msg_error_matawang_zero_amount")
                    : Utility.getText("msg_claimdetails_item_amount_zero", [oInvalid.claim_sub_id]));
            }
        },
    };
});