sap.ui.define([],function(){"use strict";return{async onEligibleCheck(e,i){}}});
//# sourceMappingURL=Pelbagai.js.map