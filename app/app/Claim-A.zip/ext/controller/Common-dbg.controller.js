sap.ui.define([
	'sap/ui/core/mvc/ControllerExtension',
	'sap/m/MessageBox',
	'sap/m/MessageToast'
], function (ControllerExtension, MessageBox, MessageToast) {
	'use strict';

	return ControllerExtension.extend('claima.ext.controller.Common', {

		_navToken: 0,
		_reportTimer: null,
		_detailTimer: null,
		_searchTimer: null,
		_sCurrentRouteName: null,
		_oAttachedTable: null,
		_fnAttachedItemPress: null,
		_fnAttachedCellClick: null,

		override: {

			onInit: function () {
				const oRouter = this.base.getAppComponent().getRouter();
				oRouter.attachRouteMatched(this._onRouteMatched, this);
			},

			editFlow: {
				onBeforeCreate: function (mParameters) {
					const aData = mParameters.createParameters;

					const START_DATE = aData.find(i => i.START_DATE)?.START_DATE;
					const END_DATE = aData.find(i => i.END_DATE)?.END_DATE;

					if (START_DATE && END_DATE) {
						const dStart = new Date(START_DATE);
						const dEnd = new Date(END_DATE);

						if (dEnd < dStart) {
							MessageToast.show("End date cannot be earlier than start date");
							return Promise.reject();
						}
					}

					return Promise.resolve();
				}
			}
		},

		/* ==============================
		 * ROUTE HANDLING
		 * ============================== */
		_onRouteMatched: function (oEvent) {

			const sRouteName = oEvent.getParameter("name");
			this._sCurrentRouteName = sRouteName;

			if (
				this._oPendingTable &&
				this._fnPendingCellClick &&
				this._oPendingTable.detachCellClick
			) {
				this._oPendingTable.detachCellClick(
					this._fnPendingCellClick
				);
				this._oPendingTable = null;
				this._fnPendingCellClick = null;
			}

			this._navToken = (this._navToken || 0) + 1;
			const currentToken = this._navToken;

			clearTimeout(this._reportTimer);
			clearTimeout(this._detailTimer);
			clearTimeout(this._searchTimer);

			const oView = this.base.getView();

			const fnGetInnerTable = () => {
				const aTables = oView.findAggregatedObjects(true, oControl =>
					oControl.isA("sap.ui.mdc.Table")
				);

				if (!aTables.length) return null;

				const oMdcTable = aTables[0];
				return oMdcTable.getTable?.() || oMdcTable._oTable || null;
			};

			/* =========================
			 * LIST REPORT
			 * ========================= */
			if (sRouteName === "ZEMP_CC_BUDGET_REPORT") {

				this._reportTimer = setTimeout(() => {
					if (currentToken !== this._navToken) return;

					const oTable = fnGetInnerTable();
					if (!oTable) return;

					this._attachItemPressOnce(oTable, this._onRowPress);
				}, 800);
			}

			/* =========================
			 * DETAIL PAGE
			 * ========================= */
			if (sRouteName === "ZEMP_CC_BUDGET_DETAIL") {

				this._detailTimer = setTimeout(() => {
					if (currentToken !== this._navToken) return;

					const oTable = fnGetInnerTable();
					if (!oTable) return;

					this._attachItemPressOnce(oTable, this._onRowPressClaimDetails);

					// Apply filters
					const oFilterBar = oView.byId("fe::FilterBar::ZEMP_CC_BUDGET_DETAIL");
					if (!oFilterBar) return;

					const oArgs = oEvent.getParameter("arguments");
					if (!oArgs) return;

					const oConditions = {
						FUND_CENTER: [{ operator: "EQ", values: [decodeURIComponent(oArgs.FUND_CENTER || "")] }],
						COMMITMENT_ITEM: [{ operator: "EQ", values: [decodeURIComponent(oArgs.COMMITMENT_ITEM || "")] }],
						MATERIAL_GROUP: [{ operator: "EQ", values: [decodeURIComponent(oArgs.MATERIAL_GROUP || "")] }],
						PROJECT_CODE: [{ operator: "EQ", values: [decodeURIComponent(oArgs.PROJECT_CODE || "")] }]
					};

					oFilterBar.setFilterConditions(oConditions);

					this._searchTimer = setTimeout(() => {
						if (currentToken !== this._navToken) return;
						oFilterBar.fireSearch();
					}, 400);
				}, 800);
			}

			if (sRouteName === "ZEMP_PENDING_LIST") {

				this._reportTimer = setTimeout(() => {
					if (currentToken !== this._navToken) return;

					const oTable = fnGetInnerTable();
					if (!oTable) return;

					// Detach previous pending list cell click handler first
					if (this._oPendingTable && this._fnPendingCellClick && this._oPendingTable.detachCellClick) {
						this._oPendingTable.detachCellClick(this._fnPendingCellClick);
					}

					this._oPendingTable = oTable;

					this._fnPendingCellClick = (oEvent) => {

						// Extra safety: only allow popup in ZEMP_PENDING_LIST
						if (this._sCurrentRouteName !== "ZEMP_PENDING_LIST") {
							return;
						}

						const iRowIndex = oEvent.getParameter("rowIndex");

						// Ignore header click / invalid row
						if (iRowIndex < 0) {
							return;
						}

						const oContext = oTable.getContextByIndex(iRowIndex);

						if (!oContext) {
							return;
						}

						this._onPendingListRowPress({
							getParameter: function (sName) {
								if (sName === "listItem") {
									return {
										getBindingContext: function () {
											return oContext;
										}
									};
								}
								return null;
							}
						});
					};
					oTable.attachCellClick(this._fnPendingCellClick);
				}, 800);
			}
		},

		/* ==============================
		 * SAFE ATTACH HELPER
		 * ============================== */
		_attachItemPressOnce: function (oTable, fnHandler) {

			if (!oTable) return;

			if (oTable.attachItemPress) {
				this._oAttachedTable = oTable;
				this._fnAttachedItemPress = fnHandler;
				oTable.attachItemPress(fnHandler, this);
				return;
			}

			if (oTable.attachCellClick) {

				if (!oTable.__cellClickAttached) {

					oTable.attachCellClick((oEvent) => {

						const iRowIndex = oEvent.getParameter("rowIndex");
						const oContext = oTable.getContextByIndex(iRowIndex);

						if (!oContext) return;

						fnHandler.call(this, {
							getParameter: (sName) => {
								if (sName === "listItem") {
									return {
										getBindingContext: () => oContext
									};
								}
								return null;
							}
						});

					});

					oTable.__cellClickAttached = true;
				}
			}
		},

		/* ==============================
		 * LIST NAVIGATION
		 * ============================== */
		_onRowPress: function (oEvent) {

			const oItem = oEvent.getParameter("listItem");
			if (!oItem) return;

			const oData = oItem.getBindingContext()?.getObject();
			if (!oData) return;

			this.base.getAppComponent().getRouter().navTo("ZEMP_CC_BUDGET_DETAIL", {
				FUND_CENTER: encodeURIComponent(oData.FUND_CENTER),
				COMMITMENT_ITEM: encodeURIComponent(oData.COMMITMENT_ITEM),
				MATERIAL_GROUP: encodeURIComponent(oData.MATERIAL_GROUP || "DEFAULT"),
				PROJECT_CODE: encodeURIComponent(oData.PROJECT_CODE || "")
			});
		},

		/* ==============================
		 * DETAIL NAVIGATION
		 * ============================== */
		_onRowPressClaimDetails: function (oEvent) {

			const oItem = oEvent.getParameter("listItem");
			if (!oItem) return;

			const oData = oItem.getBindingContext()?.getObject();
			if (!oData) return;

			this.base.getAppComponent().getRouter().navTo("ClaimSubmission", {
				claim_id: encodeURIComponent(String(oData.CLAIM_ID))
			});
		},

		_detachRowPress: function () {
			if (!this._oAttachedTable) {
				return;
			}

			if (this._fnAttachedItemPress && this._oAttachedTable.detachItemPress) {
				this._oAttachedTable.detachItemPress(this._fnAttachedItemPress, this);
			}

			if (this._fnAttachedCellClick && this._oAttachedTable.detachCellClick) {
				this._oAttachedTable.detachCellClick(this._fnAttachedCellClick, this);
			}

			this._oAttachedTable = null;
			this._fnAttachedItemPress = null;
			this._fnAttachedCellClick = null;
		},

		_onPendingListRowPress: function (oEvent) {

			if (this._sCurrentRouteName !== "ZEMP_PENDING_LIST") {
				return;
			}

			const oItem = oEvent.getParameter("listItem");
			if (!oItem) return;

			const oContext = oItem.getBindingContext();
			if (!oContext) return;

			sap.ui.require([
				"claima/ext/controller/ApproverPopup"
			], function (ApproverPopup) {

				ApproverPopup.onClickChangeApprover([oContext]);

			});
		}

	});
});