sap.ui.define([
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Element",
    "claima/utils/ReassignUtility",
    "claima/utils/Utility",
    "sap/ui/core/BusyIndicator",
    "claima/utils/Constants"
], function (Fragment, Filter, FilterOperator, MessageToast, MessageBox, Element, ReassignUtility, Utility, BusyIndicator, Constants) {
    "use strict";
    var oApproverFragment = null;
    var oApproverPopupModule = {
        onClickChangeApprover: function (oBindingContext, aSelectedContexts) {
            var aContexts = Array.isArray(oBindingContext) ? oBindingContext : aSelectedContexts;
            if (!aContexts || aContexts.length === 0) return;
            var oSelectedContext = aContexts[0];
            var sId = oSelectedContext.getProperty("ID");
            var oView = Element.registry.filter(function (oElement) {
                return oElement.isA("sap.ui.core.mvc.View");
            })[0];
            if (!oView) return;
            var oControllerMapping = {
                onSaveApprovers: oApproverPopupModule.onSaveApprovers,
                onCloseDialog: oApproverPopupModule.onCloseDialog,
                onApproverValueHelpRequest: oApproverPopupModule.onApproverValueHelpRequest,
                onCommentLiveChange: oApproverPopupModule.onCommentLiveChange
            };
            var fnApplyTableFilter = function () {
                var oTable = Fragment.byId(oView.getId(), "popupTable");
                if (oTable) {
                    var oBinding = oTable.getBinding("items");
                    if (oBinding) {
                        var oFilter = new Filter("ID", FilterOperator.EQ, sId);
                        oBinding.filter([oFilter]);
                    }
                }
            };
            if (!oApproverFragment) {
                Fragment.load({
                    id: oView.getId(),
                    name: "claima.ext.fragment.ApproverChange",
                    controller: oControllerMapping
                }).then(function (oDialog) {
                    oApproverFragment = oDialog;
                    oView.addDependent(oDialog);
                    fnApplyTableFilter();
                    oApproverFragment.open();
                });
            } else {
                fnApplyTableFilter();
                oApproverFragment.open();
            }
        },
        onSaveApprovers: function (oEvent) {
            var oSource = oEvent.getSource();
            var oModel = oSource.getModel();
            var oView = Element.registry.filter(function (oEl) {
                return oEl.isA("sap.ui.core.mvc.View");
            })[0];
            if (!oView) return;
            var oTable = Fragment.byId(oView.getId(), "popupTable");
            if (!oTable) return;
            var aItems = oTable.getItems();
            if (aItems.length === 0) {
                if (oApproverFragment) { oApproverFragment.close(); }
                return;
            }
            // 1. Reverted back to standard OData property check: at least one row has NEW_APPROVER_ID
            var bHasAtLeastOneNewApprover = aItems.some(function (oItem) {
                var oContext = oItem.getBindingContext();
                if (!oContext) return false;
                var sNewApproverId = oContext.getProperty("NEW_APPROVER_ID");
                return sNewApproverId && sNewApproverId.trim() !== "";
            });
            if (!bHasAtLeastOneNewApprover) {
                MessageBox.error(
                    Utility.getText("msg_at_least_one_approver_required") ||
                    "Please select a new approver for at least one item before saving."
                );
                return;
            }
            // 2. Mandatory Comment Check
            var oCommentTextArea = Fragment.byId(oView.getId(), "commentTextArea");
            var sComment = oCommentTextArea ? oCommentTextArea.getValue().trim() : "";
            if (!sComment) {
                if (oCommentTextArea) {
                    oCommentTextArea.setValueState("Error");
                    oCommentTextArea.setValueStateText(Utility.getText("msg_comment_required") || "Comment is required");
                }
                MessageBox.error(Utility.getText("msg_comment_required") || "Please enter a comment before saving.");
                return;
            } else if (oCommentTextArea) {
                oCommentTextArea.setValueState("None");
            }
            BusyIndicator.show(0);
            ReassignUtility.saveApproverData(aItems, oModel, sComment).then(function () {
                if (oCommentTextArea) {
                    oCommentTextArea.setValue("");
                    oCommentTextArea.setValueState("None");
                }

                // 1. FIRST: Reset all dirty/pending changes on the popup table contexts so UI5 allows refreshing
                if (oTable) {
                    var oBinding = oTable.getBinding("items");
                    if (oBinding && typeof oBinding.resetChanges === "function") {
                        oBinding.resetChanges();
                    }
                }
                // 2. Also reset model pending changes if using a custom group ID
                if (oModel && typeof oModel.hasPendingChanges === "function" && oModel.hasPendingChanges()) {
                    if (typeof oModel.resetChanges === "function") {
                        oModel.resetChanges();
                    }
                }
                // 3. NOW: Refresh the main page table/filterbar (it will work now without throwing the error)
                var oFilterBar = Element.registry.filter(function (oControl) {
                    return oControl.isA("sap.ui.comp.filterbar.FilterBar") ||
                        oControl.isA("sap.ui.mdc.FilterBar") ||
                        oControl.isA("sap.fe.macros.filterbar.FilterBarAPI");
                })[0];
                if (oFilterBar) {
                    if (typeof oFilterBar.search === "function") {
                        oFilterBar.search();
                    } else if (typeof oFilterBar.fireSearch === "function") {
                        oFilterBar.fireSearch();
                    }
                } else if (oModel && typeof oModel.refresh === "function") {
                    oModel.refresh("$auto");
                }
                BusyIndicator.hide();
                MessageToast.show(Utility.getText("msg_approver_save_success"));
                if (oApproverFragment) { oApproverFragment.close(); }
            }).catch(function (oError) {

                BusyIndicator.hide();

                var sMsg = "";
                if (oError) {
                    if (oError.error && oError.error.message) {
                        sMsg = oError.error.message;
                    } else if (oError.message) {
                        sMsg = oError.message;
                    } else if (typeof oError.getParameter === "function") {
                        sMsg = oError.getParameter("message");
                    }
                }

                var sFinalMessage = sMsg || Utility.getText("msg_approver_save_fail");

                MessageBox.error(sFinalMessage);
            });
        },
        onCloseDialog: function (oEvent) {
            var oSource = oEvent.getSource();
            var oModel = oSource.getModel();
            var oView = Element.registry.filter(function (oEl) {
                return oEl.isA("sap.ui.core.mvc.View");
            })[0];
            if (oView) {
                var oCommentTextArea = Fragment.byId(oView.getId(), "commentTextArea");
                if (oCommentTextArea) {
                    oCommentTextArea.setValue("");
                    oCommentTextArea.setValueState("None");
                }
            }
            if (oModel && oModel.hasPendingChanges("manualGroup")) {
                var oResetPromise = oModel.resetChanges("manualGroup");
                if (oResetPromise && typeof oResetPromise.catch === "function") {
                    oResetPromise.catch(function () { });
                }
            }
            if (oApproverFragment) {
                oApproverFragment.close();
            }
        },
        onCommentLiveChange: function (oEvent) {
            var oTextArea = oEvent.getSource();
            if (oTextArea.getValue().trim()) {
                oTextArea.setValueState("None");
            }
        },
        onApproverValueHelpRequest: function (oEvent) {
            var oInput = oEvent.getSource();
            var oBindingContext = oInput.getBindingContext();
            var sDept = "";
            var sApproverID = "";
            var iCurrentSeq = null;
            if (oBindingContext) {
                var sStatus = oBindingContext.getProperty("STATUS");
                var sNormalizedStatus = sStatus ? sStatus.trim() : "";
                if (sNormalizedStatus !== Constants.ClaimStatus.PENDING_APPROVAL && sNormalizedStatus !== "") {
                    MessageToast.show(Utility.getText("msg_disable_edit"));
                    return;
                }

                // sDept = oBindingContext.getProperty("APPROVER_DEP");
                // sApproverID = oBindingContext.getProperty("APPROVER_ID");
                // var sSeqRaw = oBindingContext.getProperty("GRADE_SEQUENCE");
                // if (sSeqRaw) {
                //     iCurrentSeq = parseInt(sSeqRaw, 10);
                // }               
            }
            var oModel = oInput.getModel();
            if (oApproverPopupModule._oApproverVHDialog) {
                oApproverPopupModule._oApproverVHDialog.destroy();
                oApproverPopupModule._oApproverVHDialog = null;
            }

            var aInitialFilters = [];
            // if (sDept) {
            //     aInitialFilters.push(new Filter("DEP", FilterOperator.EQ, sDept));
            // }
            // if (iCurrentSeq !== null) {
            //     aInitialFilters.push(new Filter("GRADE_SEQUENCE", FilterOperator.GE, iCurrentSeq));
            // }
            // if (sApproverID) {
            //     aInitialFilters.push(new Filter("EEID", FilterOperator.NE, sApproverID));
            // }

            oApproverPopupModule._oApproverVHDialog = new sap.m.TableSelectDialog({
                title: "Select Approver",
                contentWidth: "35rem",
                columns: [
                    new sap.m.Column({
                        header: new sap.m.Label({ text: "Name" })
                    }),
                    new sap.m.Column({
                        header: new sap.m.Label({ text: "Employee ID" })
                    })
                ],

                items: {
                    path: "/ZEMP_APPROVER_LIST_VH",
                    template: new sap.m.ColumnListItem({
                        cells: [
                            new sap.m.Text({ text: "{NAME}" }),
                            new sap.m.Text({ text: "{EEID}" })
                        ]
                    }),
                    filters: aInitialFilters
                },

                confirm: function (oConfirmEvent) {
                    var oSelectedItem = oConfirmEvent.getParameter("selectedItem");
                    if (oSelectedItem) {
                        // Grab the context data straight from the selected table row cells
                        var aCells = oSelectedItem.getCells();
                        var sNewApproverId = aCells[1].getText(); // Index 1 is Employee ID
                        var oInputContext = oInput.getBindingContext();
                        if (oInputContext) {
                            oInputContext.setProperty("NEW_APPROVER_ID", sNewApproverId);
                        }
                    }
                },
                search: function (oSearchEvent) {
                    var sValue = oSearchEvent.getParameter("value");

                    var aFilters = [];

                    if (sValue) {
                        aFilters.push(
                            new Filter({
                                filters: [
                                    new Filter("NAME_SEARCH", FilterOperator.Contains, sValue.toUpperCase()),
                                    new Filter("EEID", FilterOperator.Contains, sValue)
                                ],
                                and: false
                            })
                        );
                    }

                    oSearchEvent.getSource().getBinding("items").filter(aFilters);
                }
            });
            if (oModel) {
                oApproverPopupModule._oApproverVHDialog.setModel(oModel);
            }
            oApproverPopupModule._oApproverVHDialog.open();
        }
    };
    return oApproverPopupModule;
});