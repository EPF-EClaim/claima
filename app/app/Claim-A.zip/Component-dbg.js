sap.ui.define([
    "sap/fe/core/AppComponent",
    "claima/model/models",
    "sap/ui/core/routing/HashChanger",
    "claima/utils/Utility",
    "sap/ui/model/json/JSONModel",
    "claima/utils/PARequestSharedFunction",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "claima/utils/Validator",
    "claima/utils/CustomValidator",
	"claima/utils/RequestUtility"
],
    (AppComponent,
	models,
	HashChanger,
	Utility,
	JSONModel,
	PARequestSharedFunction,
	Filter,
	FilterOperator,
	MessageToast,
    MessageBox,
	Validator,
	CustomValidator,
	RequestUtility) => {
        "use strict";

        return AppComponent.extend("claima.Component", {
            metadata: {
                manifest: "json"
            },

            countdown: 840000,
            resetCountdown: 840000,

             init() {
                AppComponent.prototype.init.apply(this, arguments);

                this._oReqModel = this.getModel("request");

                // Initialize the utility 
                Utility.init(this);
                // Initialize Custom Validator
                CustomValidator.init(this);
                // Initialize Request Utility
                RequestUtility.init(this);

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
                this.setModel(models.createSessionModel(), "session");
                this.setModel(models.createUserIdModel(), "userId");
                this.setModel(models.createImageModel(), "imageModel");
                this.setModel(models.createRoleModel(), "roleModel");
                this.setModel(models.createConstantModel(), "constant");

                const fmt = sap.ui.getCore().getConfiguration().getFormatSettings();
                fmt.setDatePattern("medium", "dd MMM yyyy");
                fmt.setDatePattern("short", "dd MMM yyyy");

                // enable routing
                // this.getRouter().initialize();

                // const sHash = HashChanger.getInstance().getHash();
                // if (sHash === "") this.getRouter().navTo("Dashboard", {}, true);

                PARequestSharedFunction._ensureRequestModelDefaults(this._oReqModel);
                
                this._oRolesLoadedPromise = new Promise((resolve) => {
                    this._fnRolesLoaded = resolve;
                });

                this._loadExternalLibraries();
                //this._loadCurrentUser();
                this._initializeUserSession();
                this.setInactivityTimeout(600000);
                this._initActivityTracking();
                this.startInactivityTimer();

                this.getRouter().attachBeforeRouteMatched(this._onBeforeRouteMatched, this);
                this.getRouter().attachRouteMatched(this._onRouteMatched, this);
            },

            _initializeUserSession: async function () {
                const oModel = this.getModel();
                const oUserTypeContext = oModel.bindContext("/getUserType(...)");

                try {
                    // the backend response
                    await oUserTypeContext.execute();

                    const oUserData = oUserTypeContext.getBoundContext().getObject();
                    const oSessionModel = this.getModel("session");
                    const oRoleModel = this.getModel("roleModel");

                    const oUserRoles = oUserData.roles;
                    const sEmail = oUserData.id;
                    const sName = oUserData.name || "";
                    const sInitials = sName.substring(0, 2).toUpperCase();

                    // populate Session Model
                    oSessionModel.setProperty("/userId", oUserData.userId || "UNKNOWN");
                    oSessionModel.setProperty("/email", sEmail);
                    oSessionModel.setProperty("/initials", sInitials);
                    oSessionModel.setProperty("/userName", sName);
                    oSessionModel.setProperty("/position", oUserData.position);
                    oSessionModel.setProperty("/grade", oUserData.grade || "UNKNOWN");
                    oSessionModel.setProperty("/department", oUserData.department || "UNKNOWN");
                    oSessionModel.setProperty("/origin", oUserData.origin);
                    oSessionModel.setProperty("/costCenters", oUserData.costcenters || "UNKNOWN");

                    // update Request Model
                    this._oReqModel.setProperty("/user", {
                        emp_id: oUserData.userId,
                        name: oUserData.name,
                        cost_center: oUserData.costcenters
                    });

                    oRoleModel.setProperty("/isClaimant", oUserRoles.isClaimant);
                    oRoleModel.setProperty("/isApprover", oUserRoles.isApprover);
                    oRoleModel.setProperty("/isDTDAdmin", oUserRoles.isDTDAdmin);
                    oRoleModel.setProperty("/isAdminSystem", oUserRoles.isAdminSystem);
                    oRoleModel.setProperty("/isAdminCC", oUserRoles.isAdminCC);
                    oRoleModel.setProperty("/isCCCAdmin", oUserRoles.isCCCAdmin);

                    // userType is a single display label - priority order
                    // determines which one shows when a user has multiple roles.
                    if (oUserRoles.isDTDAdmin) {
                        oSessionModel.setProperty("/userType", "DTD Admin");
                        oRoleModel.setProperty("/Admin_role", true);
                        oRoleModel.setProperty("/DTDAdmin_role", true);
                    } else if (oUserRoles.isAdminSystem) {
                        oSessionModel.setProperty("/userType", "JKEW Admin");
                        oRoleModel.setProperty("/Admin_role", true);
                        oRoleModel.setProperty("/JKEW_role", true);
                    } else if (oUserRoles.isAdminCC) {
                        oSessionModel.setProperty("/userType", "GA Admin");
                        oRoleModel.setProperty("/GA_role", true);
                    } else if (oUserRoles.isCCCAdmin) {
                        oSessionModel.setProperty("/userType", "CCC Admin");
                    } else if (oUserRoles.isApprover) {
                        oSessionModel.setProperty("/userType", "Approver");
                    } else {
                        oSessionModel.setProperty("/userType", "Claimant");
                    }

                    // Role-visibility flags are independent - a user can hold
                    // multiple admin roles at once (e.g. Admin_CC AND
                    // CCC_Admin), so each flag must be set on its own
                    // condition rather than an else-if chain that stops at
                    // the first match and silently skips the rest.
                    if (oUserRoles.isDTDAdmin) {
                        oRoleModel.setProperty("/Admin_role", true);
                        oRoleModel.setProperty("/DTD_JKEW_role", true);
                        oRoleModel.setProperty("/DTDAdmin_role", true);
                    }
                    if (oUserRoles.isAdminSystem) {
                        oRoleModel.setProperty("/Admin_role", true);
                        oRoleModel.setProperty("/DTD_JKEW_role", true);
                    }
                    if (oUserRoles.isAdminCC) {
                        oRoleModel.setProperty("/Admin_role", true);
                    }
                    if (oUserRoles.isCCCAdmin) {
                        oRoleModel.setProperty("/CCC_Admin", true);
                    }

                    this._fnRolesLoaded();

                    if (this.getModel()) {
                        this.getModel().refresh();
                    }

                    var sBrowserHash = window.location.hash || "";
                    if (sBrowserHash.indexOf("?") > -1) {
                        sBrowserHash = sBrowserHash.split("?")[0];
                    }
                    if (sBrowserHash.endsWith("/")) {
                        sBrowserHash = sBrowserHash.slice(0, -1);
                    }

                    if (!sBrowserHash || sBrowserHash === "" || sBrowserHash === "#" || sBrowserHash === "#/") {
                        this.getRouter().navTo("Dashboard", {}, true);
                    }

                } catch (oError) {
                    console.error("User Session Initialization Failed:", oError);
                    this._fnRolesLoaded();
                }
            },

            _loadExternalLibraries: function () {
                const aLibs = [
                    'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.2/jszip.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.2/xlsx.js'
                ];
                aLibs.forEach(src => {
                    const script = document.createElement('script');
                    script.setAttribute('src', src);
                    document.head.appendChild(script);
                });
            },

            _initActivityTracking: function () {
                this._fnResetActivity = () => {
                    this.resetInactivityTimeout();
                };

                ["mousemove", "keydown", "click", "scroll", "touchstart"].forEach(sEvent => {
                    document.addEventListener(sEvent, this._fnResetActivity, true);
                });

                const oModel = this.getModel();
                if (oModel && oModel.attachEventOnce) {
                    oModel.attachPropertyChange(this._fnResetActivity, this);
                }

                sap.ui.getCore().getEventBus().subscribe(
                    "sap.ui",
                    "interaction",
                    this._fnResetActivity,
                    this
                );
            },

            /**
             * Returns the validator
             * @public
             * @return {Validator} returns the validator
             */
            getValidator: function () {
                if (!this._oValidator) {
                    this._oValidator = new Validator();
                }
                return this._oValidator;
            },

            getInactivityTimeout: function () {
                return this.countdown;
            },

            setInactivityTimeout: function (timeout_millisec) {
                this.countdown = timeout_millisec;
                this.resetCountdown = this.countdown;
            },

            resetInactivityTimeout: function () {
                this.countdown = this.resetCountdown;
            },

            startInactivityTimer: function () {
                var self = this;
                this.intervalHandle = setInterval(function () {
                    self._inactivityCountdown();
                }, 10000);
            },

            stopInactivityTimer: function () {
                if (this.intervalHandle != null) {
                    clearInterval(this.intervalHandle);
                    this.intervalHandle = null;
                }
            },

            _inactivityCountdown: function () {
                this.countdown -= 10000;

                const iFiveMinMs = 5 * 60 * 1000;
                if (this.countdown === iFiveMinMs) {
                    this._showSessionWarning();
                }

                if (this.countdown <= 0) {
                    this.stopInactivityTimer();
                    this.resetInactivityTimeout();
                    this._doLogout();
                }
            },

            _showSessionWarning: function () {
                //countdown another 5 mins if no response to the prompt message
                //direct force user to logout
                this.stopInactivityTimer();
                this._promptExpireHandle = setTimeout(() => {
                    this._doLogout();
                }, 5 * 60 * 1000);

                sap.m.MessageBox.warning(
                    "Session will expire. Click OK to stay logged in.",
                    {
                        title: "Session Expiring Soon",
                        actions: [
                            sap.m.MessageBox.Action.OK,
                            "Logout"
                        ],
                        emphasizedAction: sap.m.MessageBox.Action.OK,
                        onClose: (sAction) => {
                            clearTimeout(this._promptExpireHandle);
                            this._promptExpireHandle = null;
                            if (sAction === "Logout") {
                                this._doLogout();
                            } else {
                                this._resumeSession();
                            }
                        }
                    }
                );
            },

            _resumeSession: function () {
                $.ajax({
                    type: "GET",
                    url: "/user-api/currentUser",
                    success: () => {
                        this.resetInactivityTimeout();
                        this.startInactivityTimer();
                    },
                    error: () => {
                        MessageToast.show("Session logout due to inactivity");
                        this._doLogout();
                    }
                })
            },

            _doLogout: function () {
                this.stopInactivityTimer();

                ["keydown", "click", "scroll", "touchstart"].forEach(sEvent => {
                    document.removeEventListener(sEvent, this._fnResetActivity, true);
                });

                sap.ui.getCore().getEventBus().unsubscribe(
                    "sap.ui",
                    "interaction",
                    this._fnResetActivity,
                    this
                );

                window.location.href = "/claima/do/logout";
            },

            // get backend data
            async _getEmpIdDetail(sEMAIL) {
                const oListBinding = this.getModel().bindList("/ZEMP_MASTER", null, null, [
                    new Filter({
                        path: "EMAIL",
                        operator: FilterOperator.EQ,
                        value1: sEMAIL,
                        caseSensitive: false
                    }) // non case-sensitive search
                ]);

                try {
                    const aContexts = await oListBinding.requestContexts(0, 1);

                    if (aContexts.length > 0) {
                        const oData = aContexts[0].getObject();
                        return {
                            eeid: oData.EEID,
                            name: oData.NAME,
                            grade: oData.GRADE,
                            cc: oData.CC,
                            pos: oData.POS,
                            dep: oData.DEP,
                            unit_section: oData.UNIT_SECTION,
                            b_place: oData.B_PLACE,
                            marital: oData.MARITAL,
                            job_group: oData.JOB_GROUP,
                            office_location: oData.OFFICE_LOCATION,
                            address_line1: oData.ADDRESS_LINE1,
                            address_line2: oData.ADDRESS_LINE2,
                            address_line3: oData.ADDRESS_LINE3,
                            postcode: oData.POSTCODE,
                            state: oData.STATE,
                            country: oData.COUNTRY,
                            contact_no: oData.CONTACT_NO,
                            email: oData.EMAIL,
                            direct_supperior: oData.DIRECT_SUPPERIOR,
                            role: oData.ROLE,
                            user_type: oData.USER_TYPE,
                            mobile_bill_eligibility: oData.MOBILE_BILL_ELIGIBILITY,
                            mobile_bill_elig_amount: oData.MOBILE_BILL_ELIG_AMOUNT,
                            employee_type: oData.EMPLOYEE_TYPE,
                            position_name: oData.POSITION_NAME,
                            position_start_date: oData.POSITION_START_DATE,
                            position_event_reason: oData.POSITION_EVENT_REASON,
                            confirmation_date: oData.CONFIRMATION_DATE,
                            effective_date: oData.EFFECTIVE_DATE,
                            updated_date: oData.UPDATED_DATE,
                            inserted_date: oData.INSERTED_DATE,
                            medical_insurance_entitlement: oData.MEDICAL_INSURANCE_ENTITLEMENT,
                            descr: {
                                cc: null,
                                dep: null,
                                unit_section: null,
                                marital: null,
                                job_group: null,
                                state: null,
                                country: null,
                                direct_supperior: null,
                                role: null,
                                user_type: null,
                                employee_type: null
                            }
                        };
                    } else {
                        console.warn("No employee found with email: " + sEMAIL);
                        return null;
                    }
                } catch (oError) {
                    console.error("Error fetching employee detail", oError);
                    return null; // Return null so the app doesn't crash
                }
            },

            destroy: function () {
                this.stopInactivityTimer();
                // UIComponent.prototype.destroy.apply(this, arguments);
                clearTimeout(this._promptExpireHandle);
                AppComponent.prototype.destroy.apply(this, arguments);
            },

            _onRouteMatched: function (oEvent) {
                // To set current key of Side Navigation
                var _sRoute = oEvent.getParameter("name");
                var _oSideNavigation = this.getRootControl().byId("sideNavigation");
                var _oRouteKeyMapping = {
                    "Dashboard": "dashboard",
                    "RequestFormStatus": "myrequest",
                    "ClaimStatus": "myreport",
                    "MyApproval": "approval",
                    "ManageSub": "mysubstitution",
                    "Analytics": "analytics",
                    "Configuration": "config"
                };

                var _sKey = _oRouteKeyMapping[_sRoute];

                if (_oSideNavigation && _sKey) {
                    _oSideNavigation.setSelectedKey(_sKey);
                }

                //clear all message
                sap.ui.getCore().getMessageManager().removeAllMessages();
            },

            _onBeforeRouteMatched: function (oEvent) {
                var sRoute = oEvent.getParameter("name");
                var oRoleModel = this.getModel("roleModel");
                var oRouter = this.getRouter();

                this._oRolesLoadedPromise.then(function () {
                    const bAdmin = oRoleModel.getProperty("/isAdminSystem") ||
                                  oRoleModel.getProperty("/isDTDAdmin") ||
                                  oRoleModel.getProperty("/isAdminCC") || 
                                  oRoleModel.getProperty("/isCCCAdmin") ;
                    // restriction for manual url change to Analytics and Configuration without admin role
                    if ((sRoute.startsWith("Z") || sRoute === "Analytics") && !bAdmin) {
                        oRouter.navTo("Dashboard");
                        MessageBox.error(Utility.getText("msg_unauthorized_role"));
                    } else {
                        oRouter.navTo(sRoute, {}, true);
                    }
                }.bind(this));
            }

        });
    });