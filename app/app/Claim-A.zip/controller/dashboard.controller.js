sap.ui.define(["sap/ui/core/mvc/Controller"],r=>{"use strict";return r.extend("claima.controller.dashboard",{onInit(){var r=this}})});
//# sourceMappingURL=dashboard.controller.js.map