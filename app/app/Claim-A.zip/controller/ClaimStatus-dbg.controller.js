sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"claima/utils/Utility",
	"sap/suite/ui/commons/BusinessCard",
	"sap/m/BusyIndicator",
	"sap/m/SelectDialog",
	"claima/utils/DateUtility"
], function (Controller,
	JSONModel,
	MessageToast,
	Filter,
	FilterOperator,
	Sorter,
	Utility,
	BusinessCard,
	BusyIndicator,
	SelectDialog,
	DateUtility) {
	"use strict";

	return Controller.extend("claima.controller.ClaimStatus", {

		DateUtility: DateUtility,
		onInit: function () {
			// Track current sort direction per path: true = DESC, false = ASC
			this._mSortState = {};
			this._oConstant = this.getOwnerComponent().getModel("constant").getData();
			this._oSessionModel = this.getOwnerComponent().getModel("session");
			this.getOwnerComponent().getRouter().getRoute("ClaimStatus").attachPatternMatched(this._onMatched, this);
		},

		_onMatched: async function () {
			const _oReq = this.getOwnerComponent().getModel("claim_status2");
			const _oModel = this.getOwnerComponent().getModel("employee_view");

			const oListBinding = _oModel.bindList("/ZEMP_CLAIM_EE_VIEW", undefined,
				[new Sorter("modifiedAt", true)],
				null,
				{
					$$ownRequest: true,
					$$groupId: "$auto",
					$$updateGroupId: "$auto",
					$count: true
				}
			);
			try {
				const oContext = await oListBinding.requestContexts(0, Infinity);
				const oContextItems = oContext.map((ctx) => ctx.getObject());

				_oReq.setProperty("/claim_header_list", oContextItems);
				_oReq.setProperty("/claim_header_count", oContextItems.length);
			} catch (err) {
				console.error("OData bindList failed:", err);
				_oReq.setProperty("/claim_header_list", []);
				_oReq.setProperty("/claim_header_count", 0);
			}
		},

		_getClaimModel() {
			return this.getOwnerComponent().getModel("claim");
		},

		_getClaimStatModel() {
			return this.getOwnerComponent().getModel("claim_status2");
		},

		async onRowPress(oEvent) {
			try {
				this.getView().setBusy(true);

				const oListItem = oEvent?.getParameter("listItem");

				let oCtx =
					oListItem?.getBindingContext("claim_status2") ||
					oListItem?.getBindingContext("request_status") ||
					oListItem?.getBindingContext() || null;

				if (!oCtx) {
					const oTable = this.byId("tb_myapproval_claim"); // adjust ID if different
					const oSelected = oTable?.getSelectedItem?.();
					if (oSelected) {
						oCtx =
							oSelected.getBindingContext("claim_status2") ||
							oSelected.getBindingContext("request_status") ||
							oSelected.getBindingContext();
					}
				}

				if (!oCtx) {
					MessageToast.show(Utility.getText("msg_claimstatus_select"));
					return;
				}

				const row = oCtx.getObject();

				const sClaimId =
					row.CLAIM_ID ||
					row.CLAIM_REQUEST_ID ||
					row.CLAIMID ||
					null;

				if (!sClaimId) {
					MessageToast.show(Utility.getText("msg_claimstatus_missing"));
					return;
				}
				// Navigate to claim submission ID
				const oRouter = this.getOwnerComponent().getRouter();

				const oClaimSubmissionInputModel = this.getOwnerComponent().getModel("claimsubmission_input");
				if (oClaimSubmissionInputModel) {
					oClaimSubmissionInputModel.setProperty("/from_my_approval", false);
				}
				oRouter.navTo("ClaimSubmission", { claim_id: encodeURIComponent(String(sClaimId)) });
			} catch (e) {
				MessageToast.show(Utility.getText("msg_claimstatus_failed"));
			} finally {
				this.getView().setBusy(false);
			}
		},

		/* =========================================================
		 *                        SORTING (OData V4)
		 * ========================================================= */

		onSortToggle: function (oEvent) {
			// Property to sort by, passed via core:CustomData on the header button
			var sPath = oEvent.getSource().data("path");
			if (!sPath) { return; }

			var oTable = this.byId("tb_myexpenserepo");
			if (!oTable) { return; }

			var oBinding = oTable.getBinding("items");
			if (!oBinding) { return; }

			// Toggle direction for this path (default first click = ASC)
			var bDesc = !!this._mSortState[sPath];

			// IMPORTANT: For OData V4, do not pass comparator; backend does the ordering ($orderby)
			var oSorter = new Sorter(sPath, bDesc);

			// Apply sort -> triggers a backend request with $orderby
			oBinding.sort([oSorter]);

			// Flip state for next press and update icon for user feedback
			this._mSortState[sPath] = !bDesc;
			oEvent.getSource().setIcon(this._mSortState[sPath] ? "sap-icon://sort-descending" : "sap-icon://sort-ascending");
		},

		/** Reset all sort button icons inside a table to neutral "sort" */
		_resetSortIcons: function (oTable) {
			if (!oTable) { return; }

			// Loop through table columns and search their header content
			oTable.getColumns().forEach(function (oCol) {
				var oHeader = oCol.getHeader();
				if (oHeader && oHeader.findAggregatedObjects) {
					// Find all Button controls that have data("path") - our sort buttons
					var aSortBtns = oHeader.findAggregatedObjects(true, function (oCtrl) {
						return oCtrl.isA("Button") && !!oCtrl.data("path");
					});
					aSortBtns.forEach(function (oBtn) {
						oBtn.setIcon("sap-icon://sort"); // back to neutral
					});
				}
			});
		},

		onOpenFilterDialog: function () {
			Utility.openClaimTypeFilterDialog(
				this,
				'claim_status2',
				'/claim_header_list'
			);
		},

		onFilterSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("title", FilterOperator.Contains, sValue);
			oEvent.getParameter("itemsBinding").filter([oFilter]);
		},

		onFilterCancel: function () {
			if (this._oFilterDialog) this._oFilterDialog.close();
		},

		onFilterConfirm: function (oEvent) {
			Utility.confirmClaimTypeFilter(
				this,
				'claim_status2',
				'/claim_header_list',
				'/claim_header_count',
				oEvent
			);
		},

		onResetSort: function () {
			this._mSortState = {};
			var oTable = this.byId("tb_myexpenserepo"); 
			this._resetSortIcons(oTable);
			var oBinding = oTable?.getBinding("items");
			if (oBinding) oBinding.sort(null);

			this._aActiveClaimTypeFilters = [];
			var oModel = this.getView().getModel('claim_status2');
			var sFullListPath = '/claim_header_list_full'; 
			var aFullList = oModel.getProperty(sFullListPath);
			if (aFullList) {
				oModel.setProperty('/claim_header_list', aFullList); 
				oModel.setProperty('/claim_header_count', aFullList.length); 
			}
		},
	});
});
