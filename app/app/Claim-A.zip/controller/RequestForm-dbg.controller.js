sap.ui.define([
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Label",
	"sap/m/library",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/ui/core/BusyIndicator",
	"sap/ui/core/Fragment",
	"sap/ui/core/library",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/export/Spreadsheet",
	"sap/ui/mdc/enums/FieldEditMode",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"claima/utils/ApprovalLog",
	"claima/utils/ApproveDialog",
	"claima/utils/ApproverUtility",
	"claima/utils/Attachment",
	"claima/utils/budgetCheck",
	"claima/utils/Constants",
	"claima/utils/CustomValidator",
	"claima/utils/DateUtility",
	"claima/utils/EligibilityCheck",
	"claima/utils/EligibilityScenarios/EligibleScenarioCheck",
	"claima/utils/PARequestSharedFunction",
	"claima/utils/RejectDialog",
	"claima/utils/RequestUtility",
	"claima/utils/SendBackDialog",
	"claima/utils/Utility",
	"claima/utils/workflowApproval",
	"claima/model/models",
	"claima/utils/Common",
], function (
	Button,
	Dialog,
	Label,
	mLibrary,
	MessageBox,
	MessageToast,
	Text,
	BusyIndicator,
	Fragment,
	coreLibrary,
	Controller,
	History,
	Spreadsheet,
	FieldEditMode,
	Filter,
	FilterOperator,
	JSONModel,
	Sorter,
	ApprovalLog,
	ApproveDialog,
	ApproverUtility,
	Attachment,
	budgetCheck,
	Constants,
	CustomValidator,
	DateUtility,
	EligibilityCheck,
	EligibleScenarioCheck,
	PARequestSharedFunction,
	RejectDialog,
	RequestUtility,
	SendBackDialog,
	Utility,
	workflowApproval,
	Models,
	Common
) {
	"use strict";

	const DialogType = mLibrary.DialogType;
	const ValueState = coreLibrary.ValueState;
	const ButtonType = mLibrary.ButtonType;

	return Controller.extend("claima.controller.RequestForm", {

		DateUtility: DateUtility,

		/* =========================================================
		* Lifecycle
		* ======================================================= */

		onInit() {
			this._oRouter = this.getOwnerComponent().getRouter();
			this._oConstant = this.getOwnerComponent().getModel("constant").getData();
			this._oReqModel = this.getOwnerComponent().getModel("request");
			this._oApprovalLogModel = this.getOwnerComponent().getModel('approval_log');
			this._oOwnerDetail = this.getOwnerComponent().getModel("owner_detail");
			this._oDataModel = this.getOwnerComponent().getModel();
			this._oViewModel = this.getOwnerComponent().getModel("employee_view");
			this._oSessionModel = this.getOwnerComponent().getModel("session");
			this._oRequestFragments = Object.create(null);
			this._oWorkflowModel = this.getOwnerComponent().getModel("workflow");
			this._sDeleteTarget = null; //doc 1 or doc 2
			this._oDeleteAttachmentDialog = null;

			RequestUtility.init(this.getOwnerComponent(), this.getView());
			Utility.init(this.getOwnerComponent(), this.getView());
			CustomValidator.init(this.getOwnerComponent(), this.getView());

			// URL Access
			this._oRouter.getRoute("RequestForm").attachPatternMatched(this._onMatched, this);

			this.getView().setModel(Models.createClaimHeaderEditableModel(), "reqHeaderEditableModel");
			this.getView().setModel(Models.createEditButtonModel(), "editButtonModel");
		},

		/* =========================================================
		* URL Access
		* ======================================================= */

		async _onMatched(oEvent) {
			let sRequestId = oEvent.getParameter("arguments").request_id;

			try { sRequestId = decodeURIComponent(sRequestId); } catch (e) { }

			console.log("Deep-link request ID:", sRequestId);
			const bAllowed = await Utility.checkClaimAccess(sRequestId);
			if (!bAllowed) {
				return;
			}

			this._oReqModel.setProperty("/req_header/reqid", sRequestId);
			this._oReqModel.setProperty('/view', 'view');

			this.getView().getModel("editButtonModel").setProperty("/state", false);

			await this._loadRequest(sRequestId);
		},

		async _loadRequest(sReqId) {
			BusyIndicator.show(0);
			const oRequestFormPage = this.byId("request_form");
			// hard reset
			oRequestFormPage.removeAllContent();

			// destroy ALL fragments
			if (this._oRequestFragments) {
				for (const sFrag of Object.keys(this._oRequestFragments)) {
					try {
						const oFrag = await this._oRequestFragments[sFrag];
						oFrag?.destroy(true);
					} catch { }
				}
			}
			this._oRequestFragments = Object.create(null);
			try {
				await PARequestSharedFunction.getHeader(this, sReqId);

				const sClaimType = this._oReqModel.getProperty("/req_header/claimtype");

				if (sClaimType === this._oConstant.ClaimType.MEDICAL_ADVANCE) {

					await Utility.getRemainingMedicalEntitlement(
						this._oReqModel,
						this._oReqModel.getProperty("/req_header/empid"),
						"/req_header/medical_remaining"
					);
				}

				await PARequestSharedFunction._getItemList(this, sReqId);
				await this._showHeaderFragment();
				await this._showItemList(sReqId);

				//add a participant set for CCC
				if (this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD) {
					await this._setParticipantsForCC();
					await this._loadCorpoCardsForItem(sReqId);
					this._computeCorpoCardTotals();
				}
			} catch (error) {
				console.log(error);
			} finally {
				BusyIndicator.hide();
			}
		},

		async _loadCorpoCardsForItem(sReqId) {

			const aCorpoCards = this._oReqModel.getProperty("/corpo_cards") || [];

			if (!sReqId || aCorpoCards.length === 0) {
				return;
			}

			try {
				const oFunction = this._oDataModel.bindContext("/getCorpoCardsForItem(...)");
				oFunction.setParameter("sReqId", sReqId);
				oFunction.setParameter("sCorpoCards", JSON.stringify(aCorpoCards));

				await oFunction.execute();

				const oContext = oFunction.getBoundContext();
				const sResult = oContext.getObject("value");
				const aEnrichedCards = sResult ? JSON.parse(sResult) : [];

				this._oReqModel.setProperty("/corpo_cards", aEnrichedCards);

			} catch (e) {
				console.error("Load corpo cards failed:", e);
			}
		},

		/* =========================================================
		* Helpers: Fragment Management
		* ======================================================= */

		async _getFormFragment(sName) {
			const oView = this.getView();
			if (!this._oRequestFragments[sName]) {
				this._oRequestFragments[sName] = Fragment.load({
					id: oView.getId(),
					name: "claima.fragment." + sName,
					type: "XML",
					controller: this
				}).then((oFrag) => {
					oView.addDependent(oFrag);
					return oFrag;
				});
			}
			return this._oRequestFragments[sName];
		},

		async _replaceContentAt(oPage, iIndex, oControl) {
			// Ensure the slot exists
			const iSafe = Math.min(iIndex, oPage.getContent().length);
			oPage.insertContent(oControl, iSafe);
		},

		/**
		 * Remove fragment from display
		 * @param {string} sLocalId name of fragment to be removed
		 * @returns 
		 */
		async _removeByLocalId(sLocalId) {
			const oCache = this._oRequestFragments;
			const oFragment = oCache?.[sLocalId];
			if (!oFragment) return;

			const oResolved = await oFragment;
			this.byId("request_form").removeContent(oResolved);
			oResolved.destroy(true);
			delete oCache[sLocalId];
		},

		async _showItemCreate(bEdit) {
			this._loadSelections();
			const oPage = this.byId("request_form");
			if (!oPage) return;

			await this._removeByLocalId("req_item_list");
			await this._removeByLocalId("approval_log");

			const oCreate = await this._getFormFragment("req_create_item");
			await this._replaceContentAt(oPage, 2, oCreate);

			if (bEdit && this._oReqModel.getProperty("/req_item/doc1_filename")) {
				this.byId("i_attachment_1_file").setRequired(false);
			}

			if (bEdit && this._oReqModel.getProperty("/req_item/doc2_filename")) {
				this.byId("i_attachment_2_file").setRequired(false);
			}

			if (bEdit && this._oReqModel.getProperty("/req_item/doc3_filename")) {
				this.byId("i_attachment_3_file").setRequired(false);
			}

			PARequestSharedFunction.determineFooterButton(this);
		},

		/**
		 * Display editable/non-editable header fragment based on edit button state
		 * If edit button state is true, displays editable fragment, if false, displays non-editable fragment
		 */
		_showHeaderFragment: async function () {
			this._removeByLocalId("request_header");
			var oRequestFormPage = this.byId("request_form");

			const sFragmentName = this.getView().getModel("editButtonModel").getProperty("/state") ? "request_header_edit" : "request_header"
			await this._getFormFragment(sFragmentName).then(function (oVBox) {
				oRequestFormPage.insertContent(oVBox, 1);
			});
		},


		async _showItemList(sReqId) {
			const oPage = this.byId("request_form");
			if (!oPage) return;

			await this._removeByLocalId("req_item_list");
			await this._removeByLocalId("req_create_item");
			await this._removeByLocalId("approval_log");

			const oList = await this._getFormFragment("req_item_list");
			await this._replaceContentAt(oPage, 2, oList);

			var sReqStatus = this._oReqModel.getProperty("/req_header/reqstatus");
			var bApproval = sReqStatus !== this._oConstant.RequestStatus.DRAFT && sReqStatus !== this._oConstant.RequestStatus.CANCELLED;
			if (bApproval) {
				var aApprover = await ApprovalLog.getApproverList(this._oApprovalLogModel, this._oViewModel, sReqId);

				var sCurrentUserId = this._oSessionModel.getProperty("/userId");
				var sRequestOwnerId = this._oReqModel.getProperty("/req_header/empid");

				var bCurrentUserIsApprover = aApprover.some((row) =>
					row.APPROVER_ID == sCurrentUserId ||
					row.SUBSTITUTE_APPROVER_ID == sCurrentUserId
				);

				// Special case after Push Back reload: 
				// If current user is the approver and not the requester, 
				// do not show requester/claimant buttons. 
				if (
					sReqStatus === this._oConstant.RequestStatus.SEND_BACK &&
					bCurrentUserIsApprover &&
					sRequestOwnerId != sCurrentUserId
				) {
					this._oReqModel.setProperty("/view", this._oConstant.PARMode.VIEWAPPR);
				} else {
					var bPendingApprover = false;

					for (const row of aApprover) {
						if (row.STATUS === this._oConstant.ClaimStatus.PENDING_APPROVAL &&
							(
								row.SUBSTITUTE_APPROVER_ID == sCurrentUserId ||
								row.APPROVER_ID == sCurrentUserId
							)
						) {
							bPendingApprover = true;
							break;
						}
					}

					if (bPendingApprover) {
						this._oReqModel.setProperty("/view",
							this._oConstant.PARMode.APPROVER);
					} else {
						this._oReqModel.setProperty("/view", this._oConstant.PARMode.VIEW);
					}
				}
				const oOwnerDetail = await this._getFormFragment("claimant_detail");
				await this._replaceContentAt(oPage, 0, oOwnerDetail);
				await ApprovalLog.getApprovalLogHistory(this._oApprovalLogModel, this._oDataModel, sReqId);
				const oApproval = await this._getFormFragment("approval_log");
				await this._replaceContentAt(oPage, 3, oApproval);
			} else {
				PARequestSharedFunction.getCurrentState(this);
			}

			Common.init(this.getOwnerComponent(), this.getView());
			if (sReqStatus !== this._oConstant.RequestStatus.DRAFT && sReqStatus !== this._oConstant.RequestStatus.SEND_BACK) {
				await Common.setHeaderEditable(Constants.SubmissionTypePrefix.REQUESTHEADER, false);
			}
			PARequestSharedFunction.determineFooterButton(this);
		},

		/* =========================================================
		* Footer / Navigation Buttons
		* ======================================================= */

		onBack() {
			const sReqStatus = this._oReqModel.getProperty("/req_header/reqstatus");

			if (sReqStatus == this._oConstant.RequestStatus.DRAFT ||
				sReqStatus == this._oConstant.RequestStatus.SEND_BACK) {
				if (!this.oBackDialog) {
					this.oBackDialog = new Dialog({
						title: "Warning",
						type: DialogType.Message,
						state: ValueState.Warning,
						content: [new Label({ text: Utility.getText("req_d_w_back") })],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Confirm",
							press: async function () {
								this.oBackDialog.close();
								await PARequestSharedFunction._ensureRequestModelDefaults(this._oReqModel);
								await this._removeByLocalId("approval_log");
								var oHistory = History.getInstance();
								var sPreviousHash = oHistory.getPreviousHash();
								if (sPreviousHash) {
									window.history.go(-1);
								} else {
									this._oRouter.navTo("Dashboard");
								}
							}.bind(this)
						}),
						endButton: new Button({ text: "Cancel", press: () => this.oBackDialog.close() })
					});
				}
				this.oBackDialog.open();
			} else {
				this.onBackView();
			}
		},

		/**
		 * Handles the "Delete Request" action.
		 *
		 * Guard: returns early with an error if employee ID or request ID can't
		 * be resolved.
		 *
		 * Lazily creates and opens a confirmation dialog (only built once, reused
		 * on later calls). On Delete:
		 *   - Disables the Delete button and shows the busy indicator.
		 *   - Calls the `cancelRecord` OData action with the request ID.
		 *   - On success, shows a toast and reloads the request via `_loadRequest`.
		 *   - On failure, shows an error message.
		 *   - `finally` always hides the busy indicator, closes the dialog, and
		 *     re-enables the Delete button.
		 *
		 * Cancel just closes the dialog.
		 *
		 * @returns {void} opens the dialog synchronously; delete logic runs later in the Delete button's press handler
		 */
		onDeleteRequest() {
			const sEmpId = this._oSessionModel.getProperty("/userId");
			const sReqId = String(this._oReqModel.getProperty("/req_header/reqid") || "").trim();

			if (!sEmpId || !sReqId) {
				MessageBox.error(Utility.getText("req_tm_w_emp_id_req_id_not_found"));
				return;
			}

			if (!this.oDeleteDialog) {
				this.oDeleteDialog = new Dialog({
					title: "Delete Request",
					type: DialogType.Message,
					state: ValueState.Warning,
					content: [
						new Label({ text: Utility.getText("req_d_w_delete") })
					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Delete",
						press: async () => {
							this.oDeleteDialog.getBeginButton().setEnabled(false);
							BusyIndicator.show(0);

							const sCurrentReqId = String(this._oReqModel.getProperty("/req_header/reqid") || "").trim();

							const oDeleteAction = this._oDataModel.bindContext("/cancelRecord(...)");
							oDeleteAction.setParameter("sRecordId", sCurrentReqId)

							try {
								await oDeleteAction.execute();
								const bSuccess = await oDeleteAction.getBoundContext().requestObject();	

								if (bSuccess) {								
									MessageToast.show(Utility.getText("req_tm_s_delete_request"));
									await this._loadRequest(sCurrentReqId);
								}
							} catch (oError) {
								MessageBox.error(oError.message || Utility.getText("req_d_e_delete_failed"));
							} finally {
								BusyIndicator.hide();
								this.oDeleteDialog.close();
								this.oDeleteDialog.getBeginButton().setEnabled(true);
							}
						}
					}),
					endButton: new Button({
						text: "Cancel",
						press: () => this.oDeleteDialog.close()
					})
				});
				this.getView().addDependent(this.oDeleteDialog);
			}

			this.oDeleteDialog.open();
		},

		/**
		 * Handles the "Submit Request" action.
		 *
		 * Guards (return early on failure): no unsaved header edits, at least one
		 * item in `/req_item_rows`, and both `reqid` + employee ID resolvable.
		 *
		 * If checks pass, opens a confirm dialog ("Declaration" for corporate
		 * credit card requests, "Submit Request" otherwise). On Confirm:
		 *   - Blocks if claim type is `ELAUN_TUKAR` and ineligible.
		 *   - Calls the `startWorkflow` OData action (eligibility, budget, and
		 *     approver checks in one backend call).
		 *   - On failure, shows an error based on `oResponse.Area`; on success,
		 *     reloads the request via `_loadRequest`.
		 *   - `finally` always hides the busy indicator and closes the dialog.
		 *
		 * Cancel just closes the dialog.
		 *
		 * @returns {Promise<void>} resolves once the dialog opens; submit logic runs later in Confirm's handler
		 */
		async onSubmitRequest() {
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_submit"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			const oReqData = this._oReqModel.getData();
			const aReqItemRows = this._oReqModel.getProperty("/req_item_rows") || [];

			if (!aReqItemRows.length) {
				this._showMustAddClaimDialog();
				return;
			}

			const sReqId = String(oReqData.req_header.reqid || "").trim();
			const sEmpId = this._oSessionModel.getProperty("/userId");

			if (!sReqId || !sEmpId) {
				MessageBox.error(Utility.getText("req_tm_w_emp_id_req_id_not_found"));
				return;
			}

			const sSubmitMsg = this._oReqModel.getProperty("/req_header/claimtype") === this._oConstant.ClaimType.CORPO_CRED_CARD ? Utility.getText("req_d_w_ccc_submit") : Utility.getText("req_d_w_submit");

			this.oSubmitDialog = new Dialog({
				title: this._oReqModel.getProperty("/req_header/claimtype") === this._oConstant.ClaimType.CORPO_CRED_CARD ? "Declaration" : "Submit Request",
				type: DialogType.Message,
				content: [new Text({ text: sSubmitMsg })],
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: Utility.getText("req_btn_confirm"),
					press: async () => {
						try {
							BusyIndicator.show(0);

							if (oReqData.req_header.claimtype === Constants.ClaimType.ELAUN_TUKAR &&
								await EligibilityCheck.checkClaimTypeEligibility(this._oDataModel, this._oConstant.ClaimType.ELAUN_TUKAR, false) === Constants.ElaunTukarStatus.NOT_ALLOWED) {
								MessageBox.error(Utility.getText("req_d_e_not_eligible_for_elaun_tukar"));
								return;
							}

									const sCurrentReqId = String(this._oReqModel.getProperty("/req_header/reqid") || "").trim();
									const sCurrentStatus = String(this._oReqModel.getProperty("/req_header/reqstatusid") || "").trim();

							const oSubmitAction = this._oWorkflowModel.bindContext("/startWorkflow(...)");
							oSubmitAction.setParameter("id", sCurrentReqId);
							oSubmitAction.setParameter("currentStatus", sCurrentStatus);

							await oSubmitAction.execute();
							const oResponse = await oSubmitAction.getBoundContext().requestObject();

							if (!oResponse.Success) {
								switch (oResponse.Area) {
									case this._oConstant.WorkflowArea.ELIGIBILITY_CHECKING:
										await EligibilityCheck.eligibilityHandling(this, oResponse.Message, this._oConstant.SubmissionTypePrefix.CLAIM);
										break;

									case this._oConstant.WorkflowArea.BUDGET_CHECKING:
										var aInsufficientItems = oResponse.Message.filter(r => r.STATUS === Constant.BudgetCheckStatus.INSUFFICIENT);
										var aNotFoundItems = oResponse.Message.filter(r => r.STATUS === Constant.BudgetCheckStatus.NOT_FOUND);

										var aMessages = [];
										if (aInsufficientItems.length > 0) {
											aMessages.push(Utility.getText("req_tm_w_inform_cc_owner", aInsufficientItems.map(r => r.CLAIM_TYPE_ITEM_DESC)));
										}
										if (aNotFoundItems.length > 0) {
											aMessages.push(Utility.getText("req_tm_w_budget_not_found", aNotFoundItems.map(r => r.CLAIM_TYPE_ITEM_DESC)));
										}

										if (aMessages.length > 0) {
											MessageBox.error(aMessages.join("\n"));
										}
										break;

									default:
										MessageBox.error(oResponse.Message);
										break;
								}
								return;
							}
							// reload request data
							await this._loadRequest(sCurrentReqId);
							} catch (oError) {
								MessageBox.error(oError.message || Utility.getText("req_d_e_submit_failed"));
							} finally {
								BusyIndicator.hide();
								this.oSubmitDialog.close();
							}
						}
					}),
					endButton: new Button({
						text: "Cancel",
						press: () => this.oSubmitDialog.close()
					})
				});

			this.getView().addDependent(this.oSubmitDialog);
			

			this.oSubmitDialog.open();
		},

		_showMustAddClaimDialog() {
			if (!this._oAddClaimDialog) {
				this._oAddClaimDialog = new Dialog({
					title: Utility.getText("req_d_w_missing_item"),
					type: DialogType.Message,
					state: ValueState.Warning,
					content: [
						new Label({
							text: Utility.getText("req_tm_w_submit"),
						})
					],
					beginButton: new Button({
						text: "OK",
						press: () => {
							this._oAddClaimDialog.close();
						}
					})
				});
				this.getView().addDependent(this._oAddClaimDialog);
			}
			this._oAddClaimDialog.open();
		},

		async onBackView() {
			var oCreate = this.byId('request_create_item_fragment');
			const sReqId = this._oReqModel.getProperty("/req_header/reqid");
			if (oCreate) {
				this._showItemList(sReqId);
				this._oReqModel.setProperty('/req_item', {});
		
				if (this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD && sReqId) {
					await this._loadCorpoCardsForItem(sReqId);
					this._computeCorpoCardTotals();
				}
			} else {
				PARequestSharedFunction._ensureRequestModelDefaults(this._oReqModel);
				await this._removeByLocalId("approval_log");
				var oHistory = History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();
				if (sPreviousHash) {
					window.history.go(-1);
				} else {
					this._oRouter.navTo("RequestFormStatus");
				}
			}
		},

		async onCancelItem() {
			const oData = this._oReqModel.getData();
			const sReqId = String(oData.req_header.reqid || "").trim();
			this._oReqModel.setProperty('/req_item', {});
			this._oReqModel.setProperty('/view', "view");
		
			await PARequestSharedFunction._getItemList(this, sReqId);
			this._showItemList(sReqId);
			this._resetReqItemInputs();
		
			// _getItemList() resets /corpo_cards back to the bare card identity
			// list (no amount fields) - re-merge the aggregate totals so the
			// Corporate Credit Card Summary doesn't appear blank after cancel.
			// _getItemList() must be awaited above, or this merge runs in a
			// race and gets silently overwritten once _getItemList resolves.
			if (this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD) {
				await this._loadCorpoCardsForItem(sReqId);
				this._computeCorpoCardTotals();
			}
		},

		onSaveHeaderPress: async function () {
			Common.init(this.getOwnerComponent(), this.getView());
			await Common.saveHeader(Constants.SubmissionTypePrefix.REQUESTHEADER);
		},

		/**
		 * Function for Edit button press
		 * 1. Swaps button state
		 * 2. Display fragment based on toggle
		 * 3. Enable or disable header fields to be editable
		 */
		onEditHeaderPress: async function () {
			Common.init(this.getOwnerComponent(), this.getView());
			await Common.editHeaderChange(Constants.SubmissionTypePrefix.REQUESTHEADER, !this.getView().getModel("editButtonModel").getProperty("/state"));
		},

		/* =========================================================
		* Header & Item List Area
		* ======================================================= */

		async onDocLinkPress(oEvent) {
			// calling function from Attachment.js
			let sDocument = oEvent.getSource().getText();
			let sDocumentSFId = sDocument.split(" - ")[0];
			Attachment.onViewDocument(this, sDocumentSFId);
		},

		async onAddItem(oEvent) {
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_create"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			this._oReqModel.setProperty("/view", this._oConstant.PARMode.CREATE);
			await this._showItemCreate(false);
			this._loadSelections();

			const oReqData = this._oReqModel.getData();
			const aIndividual = ['IND', 'Individual'];
			const sHeaderGrpType = oReqData.req_header.grptype;

			oReqData.req_item = {
				est_amount: 0,
				kilometer: 0,
				rate_per_kilometer: 0,
				cash_advance: false,
				entitled_breakfast: 0,
				entitled_lunch: 0,
				entitled_dinner: 0,
				daily_allowance: 0,
				travel_day: 0,
				travel_hour: 0
			};

			// if group type is Individual
			if (aIndividual.includes(sHeaderGrpType)) {
				this.byId("ipb_upload_participant").setEnabled(false);
				this.byId("ipb_delete_participant").setEnabled(false);
				this.byId("idp_delete_row_participant").setVisible(false);
				oReqData.participant = [{
					PARTICIPANTS_ID: this._oSessionModel.getProperty("/userId"),
					PARTICIPANT_NAME: this._oSessionModel.getProperty("/userName"),
					PARTICIPANT_COST_CENTER: this._oSessionModel.getProperty("/costCenters"),
					ALLOCATED_AMOUNT: "",
					_EDIT_MODE: "Display"
				}];
			}else if(this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD){
				await this._setParticipantsForCC();
				
				const aResetCards = (oReqData.corpo_cards || []).map((oCard) => ({
					...oCard,
					current_balance: 0,
					service_tax: 0,
					cashback: 0,
					merchant_refunds_total: 0,
					merchant_refunds: [],
					merchant_refunds_array: "[]"
				}));
				oReqData.corpo_cards = aResetCards;
			} else {
				oReqData.participant = [{ PARTICIPANTS_ID: "", PARTICIPANT_NAME: "", PARTICIPANT_COST_CENTER: "", ALLOCATED_AMOUNT: "" }];
			}
			this._oReqModel.setData(oReqData);
		},

		onOpenItemView(oEvent) {
			return this._openItemFromList(oEvent, /* bEdit = */ false);
		},

		onOpenItemEdit(oEvent) {
			// check if header currently in edit mode, if yes show warning to save first
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_edit"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			return this._openItemFromList(oEvent, /* bEdit = */ true);
		},

		async _openItemFromList(oEvent, bEdit) {
			const oTable = this.byId("req_item_table");

			let oCtx = null;
			const oRow = oEvent?.getParameter?.("row");
			const iRowIdx = oEvent?.getParameter?.("rowIndex");

			if (oRow) {
				oCtx = oRow.getBindingContext("request");
			} else if (Number.isInteger(iRowIdx)) {
				oCtx = oTable.getContextByIndex(iRowIdx);
			} else {
				const aSel = oTable.getSelectedIndices();
				if (aSel?.length) {
					oCtx = oTable.getContextByIndex(aSel[0]);
				}
			}

			if (!oCtx) {
				MessageBox.warning(Utility.getText("req_tm_w_select"));
				return;
			}

			const oReqItem = oCtx.getObject();
			const sReqId = String(oReqItem.REQUEST_ID || oReq.getProperty("/req_header/reqid") || "").trim();
			const sReqSubId = String(oReqItem.REQUEST_SUB_ID || "").trim();

			this._oReqModel.setProperty("/req_item", {
				req_subid				: sReqSubId,
				claim_type				: oReqItem.CLAIM_TYPE_ID || "",
				claim_type_item_id		: oReqItem.CLAIM_TYPE_ITEM_ID || "",
				no_of_days				: oReqItem.NO_OF_DAYS ?? 0,
				purpose					: oReqItem.PURPOSE || "",
				est_amount				: oReqItem.EST_AMOUNT ?? 0,
				dependent				: oReqItem.DEPENDENT || "",
				remark					: oReqItem.REMARK || "",
				course					: oReqItem.COURSE_TITLE || "",
				sport_rep				: oReqItem.KWSP_SPORTS_REPRESENTATION || "",
				club_membership			: oReqItem.DECLARE_CLUB_MEMBERSHIP || false,
				doc1_filename			: oReqItem.ATTACHMENT1 || "",
				cat_purpose				: oReqItem.MOBILE_CATEGORY_PURPOSE_ID || "",
				doc2_filename			: oReqItem.ATTACHMENT2 || "",
				start_date				: oReqItem.START_DATE || "",
				end_date				: oReqItem.END_DATE || "",
				start_time				: oReqItem.START_TIME || "",
				end_time				: oReqItem.END_TIME || "",
				vehicle_ownership		: oReqItem.VEHICLE_OWNERSHIP_ID || "",
				room_type				: oReqItem.ROOM_TYPE || "",
				country					: oReqItem.COUNTRY || "",
				location				: oReqItem.LOCATION || "",
				area					: oReqItem.AREA || "",
				no_of_family_member		: oReqItem.FAMILY_COUNT || 0,
				type_of_vehicle			: oReqItem.VEHICLE_TYPE || "",
				fare_type				: oReqItem.FARE_TYPE_ID || "",
				vehicle_class			: oReqItem.VEHICLE_CLASS || "",
				kilometer				: oReqItem.KILOMETER || 0,
				rate_per_kilometer		: oReqItem.RATE_PER_KM || "",
				toll_amt				: parseFloat(oReqItem.TOLL) || 0,
				flight_class			: oReqItem.FLIGHT_CLASS || "",
				location_type			: oReqItem.LOCATION_TYPE || "",
				from_state				: oReqItem.FROM_STATE_ID || "",
				from_location			: oReqItem.FROM_LOCATION || "",
				from_location_office	: oReqItem.FROM_LOCATION_OFFICE || "",
				to_state				: oReqItem.TO_STATE_ID || "",
				to_location				: oReqItem.TO_LOCATION || "",
				to_location_office		: oReqItem.TO_LOCATION_OFFICE || "",
				mode_of_transfer		: oReqItem.MODE_OF_TRANSFER || "",
				tarikh_pindah			: oReqItem.TRANSFER_DATE || "",
				sss						: oReqItem.REGION || "",
				marriage_cat			: oReqItem.MARRIAGE_CATEGORY || "",
				cube_eligible			: parseFloat(oReqItem.METER_CUBE_ENTITLED) || 0,
				departure_time			: oReqItem.DEPARTURE_TIME || "",
				arrival_time			: oReqItem.ARRIVAL_TIME || "",
				est_no_participant		: oReqItem.EST_NO_PARTICIPANT ?? 0,
				cash_advance			: oReqItem.CASH_ADVANCE || false,
				trip_start_date			: oReqItem.TRIP_START_DATE || null,
				trip_end_date			: oReqItem.TRIP_END_DATE || null,
				trip_start_time			: oReqItem.TRIP_START_TIME || null,
				trip_end_time			: oReqItem.TRIP_END_TIME || null,
				travel_day				: oReqItem.TRAVEL_DURATION_DAY || 0,
				travel_hour				: oReqItem.TRAVEL_DURATION_HOUR || 0,
				entitled_breakfast		: oReqItem.ENTITLED_BREAKFAST || 0,
				entitled_lunch			: oReqItem.ENTITLED_LUNCH || 0,
				entitled_dinner			: oReqItem.ENTITLED_DINNER || 0,
				daily_allowance			: oReqItem.DAILY_ALLOWANCE || 0,
				currency_code		    : oReqItem.CURRENCY_CODE || null,
				currency_rate			: oReqItem.CURRENCY_RATE || 0,
				type_of_professional_body		: oReqItem.TYPE_OF_PROFESSIONAL_BODY || null,
				no_of_traveler			: oReqItem.TOTAL_TRAVELLER || null,
				lodging_cat				: oReqItem.LODGING_CATEGORY || null,
				// extra hidden field value
				cost_center: oReqItem.COST_CENTER || "",
				gl_account: oReqItem.GL_ACCOUNT || "",
				material_code: oReqItem.MATERIAL_CODE || "",
				dependent_relationship: oReqItem.DEPENDENT_RELATIONSHIP || "",
				meter_cube_actual: oReqItem.METER_CUBE_ACTUAL || 0,
				round_trip 				: oReqItem.ROUND_TRIP || false,
				internal_order			: oReqItem.INTERNAL_ORDER || null,
				internal_order			: oReqItem.INTERNAL_ORDER || null,
				policy_year				: oReqItem.POLICY_YEAR || null,
				dependent_national_id	: oReqItem.DEPENDENT_NATIONAL_ID || null,
				insurance_medical_provider_id: oReqItem.INSURANCE_MEDICAL_PROVIDER_ID || null,
				insurance_medical_provider_name: oReqItem.INSURANCE_MEDICAL_PROVIDER_NAME || null,
				doc3_filename			: oReqItem.ATTACHMENT3 || "",
				doc4_filename			: oReqItem.ATTACHMENT4 || "",
			});

			if (this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD) {
				await this._loadCorpoCardsForEditItem(sReqId, sReqSubId);
			}

			const sState = this._oReqModel.getProperty("/view");
			if (sState != this._oConstant.PARMode.APPROVER) {
				this._oReqModel.setProperty("/view", bEdit ? this._oConstant.PARMode.EDIT : this._oConstant.PARMode.VIEW);
				this._getClaimTypeItemSelection();
			} else {
				this._oReqModel.setProperty("/view", this._oConstant.PARMode.VIEWAPPR);
			}
			this._showItemCreate(bEdit);
			this._loadParticipantsForItem(sReqId, sReqSubId);
			this.initializeClaimTypeItemFields(false);
		},

		async _loadParticipantsForItem(sReqId, sReqSubId) {

			const setEmpty = () => {
				this._oReqModel.setProperty("/participant", [
					{ PARTICIPANTS_ID: "", PARTICIPANT_NAME: "", PARTICIPANT_COST_CENTER: "", ALLOCATED_AMOUNT: "" }
				]);
			};

			if (!sReqId || !sReqSubId) {
				setEmpty();
				return;
			}

			try {

				const oListBinding = this._oViewModel.bindList(
					"/ZEMP_REQUEST_PART_VIEW",
					null,
					[new Sorter("PARTICIPANTS_ID", false)],
					[
						new Filter({ path: "REQUEST_ID", operator: FilterOperator.EQ, value1: sReqId }),
						new Filter({ path: "REQUEST_SUB_ID", operator: FilterOperator.EQ, value1: sReqSubId })
					],
					{
						$$ownRequest: true,
						$$groupId: "$auto",
						$count: false,
						$select: "PARTICIPANTS_ID,NAME,CC,ALLOCATED_AMOUNT"
					}
				);

				const aCtx = await oListBinding.requestContexts(0, Infinity);
				const aParticipants = aCtx.map((ctx) => ctx.getObject());

				var sMode = this._oReqModel.getProperty("/view");

				const aMapped = aParticipants.map((p) => ({
					PARTICIPANTS_ID: p.PARTICIPANTS_ID ?? "",
					PARTICIPANT_NAME: p.NAME ?? "",
					PARTICIPANT_COST_CENTER: p.CC ?? "",
					ALLOCATED_AMOUNT: p.ALLOCATED_AMOUNT ?? "",
					_EDIT_MODE: sMode == this._oConstant.PARMode.CREATE ? "Editable" : "Display"
				}));

				if (this._oReqModel.getProperty('/req_header/grptype') == this._oConstant.GroupType.GROUP &&
					(sMode != this._oConstant.PARMode.VIEW && sMode != this._oConstant.PARMode.APPROVER)) {
					aMapped.push({ PARTICIPANTS_ID: "", PARTICIPANT_NAME: "", PARTICIPANT_COST_CENTER: "", ALLOCATED_AMOUNT: "" });
				}

				this._oReqModel.setProperty(
					"/participant",
					aMapped.length
						? aMapped
						: [{ PARTICIPANTS_ID: "", PARTICIPANT_NAME: "", PARTICIPANT_COST_CENTER: "", ALLOCATED_AMOUNT: "" }]
				);
			} catch (e) {
				console.error("Load participants failed:", e);
				setEmpty();
			}
		},

		onDeleteAttachment: function (sDeleteTarget) {
			this._openDeleteAttachmentDialog(sDeleteTarget);
		},

		_openDeleteAttachmentDialog: function (sDeleteTarget) {
			if (!this._oDeleteAttachmentDialog) {
				Fragment.load({
					name: "claima.fragment.deleteattachment",
					id: "deleteAttachmentDialog",
					controller: this
				}).then(function (oDialog) {
					this._oDeleteAttachmentDialog = oDialog;
					this.getView().addDependent(oDialog);
					oDialog.data("deleteTarget", sDeleteTarget);
					oDialog.open();
				}.bind(this));
			} else {
				this._oDeleteAttachmentDialog.data("deleteTarget", sDeleteTarget);
				this._oDeleteAttachmentDialog.open();
			}
		},

		onConfirmDeleteAttachment: async function () {
			var sDeleteTarget = this._oDeleteAttachmentDialog.data("deleteTarget");

			Attachment.init(this.getOwnerComponent(), this.getView());
			Attachment.confirmDeleteAttachment(this._oReqModel, this._oConstant.SubmissionTypePrefix.REQUEST, sDeleteTarget);
			this._oDeleteAttachmentDialog.close();
		},

		onCancelDeleteAttachment: function () {
			this._oDeleteAttachmentDialog.close();
		},

		/* =========================================================
		* Item List: Delete Row(s)
		* ======================================================= */

		async onRowDeleteReqItem(oEvent) {
			const oTable = this._resolveControl("req_item_table_d", "request") || this._resolveControl("req_item_table", "request");
			let aRows = this._oReqModel.getProperty("/req_item_rows") || [];

			const getIndexFromCtx = (oCtx) => {
				if (!oCtx) return null;
				const i = parseInt(oCtx.getPath().split("/").pop(), 10);
				return Number.isInteger(i) ? i : null;
			};

			let aToDelete = [];
			const aSelected = oTable.getSelectedIndices() || [];

			if (aSelected.length > 0) {
				aToDelete = aSelected
					.map(idx => getIndexFromCtx(oTable.getContextByIndex(idx)))
					.filter(idx => idx !== null);
			} else {
				const oRow = oEvent.getParameter("row");
				const iRowIdx = oEvent.getParameter("rowIndex");

				let oCtx = oRow ? oRow.getBindingContext("request") :
					(Number.isInteger(iRowIdx) ? oTable.getContextByIndex(iRowIdx) : null);

				const iSingleIdx = getIndexFromCtx(oCtx);
				if (iSingleIdx !== null) aToDelete.push(iSingleIdx);
			}

			if (aToDelete.length === 0) {
				MessageBox.warning(Utility.getText("req_d_e_select_item"));
				return;
			}

			// Confirm before proceeding - deletion is permanent and applies
			// whether one or multiple items were selected.
			const bConfirmed = await new Promise((resolve) => {
				MessageBox.confirm(Utility.getText("req_d_w_delete_item_confirm"), {
					onClose: (sAction) => resolve(sAction === MessageBox.Action.OK)
				});
			});
			if (!bConfirmed) {
				return;
			}

			aToDelete = Array.from(new Set(aToDelete)).sort((a, b) => b - a);

			BusyIndicator.show(0);
			const aSuccessIdx = [];
			let sErrorMsg = "";

			try {
				for (const i of aToDelete) {
					if (i < 0 || i >= aRows.length) continue;
					const row = aRows[i] || {};
					const reqId = String(row.REQUEST_ID || "").trim();
					const subId = String(row.REQUEST_SUB_ID || "").trim();

					if (!reqId || !subId) {
						sErrorMsg = Utility.getText("req_tm_w_missing_reqid_reqsubid");
						continue;
					}

					try {
						await this._deleteItemCascade(reqId, subId);
						aSuccessIdx.push(i);
					} catch (e) {
						sErrorMsg = e.message || Utility.getText('req_tm_w_delete_req_item');
					}
				}

				if (aSuccessIdx.length > 0) {
					aSuccessIdx.forEach((i) => aRows.splice(i, 1));

					this._oReqModel.setProperty("/req_item_rows", aRows);
					this._oReqModel.setProperty("/list_count", aRows.length);
					MessageToast.show(Utility.getText('req_tm_s_delete_req_item', [aSuccessIdx.length]));
				}

				if (sErrorMsg) {
					MessageBox.error(sErrorMsg);
				}

				const toNumber = (v) => {
					if (v === null || v === undefined || v === "") return 0;
					const n = typeof v === "number" ? v : parseFloat(String(v).replace(/,/g, ""));
					return Number.isFinite(n) ? n : 0;
				};

				const oTotals = aRows.reduce((acc, row) => {
					const fReqAmt = row?.EST_AMOUNT ?? row?.est_amount ?? row?.EST_AMT ?? 0;

					const fCashAdvAmt = row?.CASH_ADVANCE ? row.EST_AMOUNT : 0;

					return {
						fReqTotal: acc.fReqTotal + toNumber(fReqAmt),
						fCashTotal: acc.fCashTotal + toNumber(fCashAdvAmt)
					};
				}, { fReqTotal: 0, fCashTotal: 0 });

				const oRound2 = (n) => Math.round(n * 100) / 100;

				const oHeader = this._oReqModel.getProperty("/req_header") || {};
				var sClaimTypeId = this._oReqModel.getProperty('/req_header/claimtype');
				var bIsCorpoCC = String(sClaimTypeId) === String(this._oConstant.ClaimType.CORPO_CRED_CARD);
				
				var fReqAmt = oRound2(oTotals.fReqTotal);
				oHeader.reqamt = (bIsCorpoCC && fReqAmt < 0) ? 0 : fReqAmt;
				oHeader.cashadvamt = oRound2(oTotals.fCashTotal);
				
				this._oReqModel.setProperty("/req_header", oHeader);
				oTable.clearSelection();
				
				// Refresh the Corporate Credit Card Summary - deleting an item
				// changes what's in ZREQ_ITEM_CCC_PART, but /corpo_cards and
				// /corpo_totals aren't recalculated by anything above.
				if (bIsCorpoCC && aSuccessIdx.length > 0) {
					const sReqId = String(this._oReqModel.getProperty("/req_header/reqid") || "").trim();
					if (sReqId) {
						await this._loadCorpoCardsForItem(sReqId);
						this._computeCorpoCardTotals();
					}
				}
				
				} finally {
					BusyIndicator.hide();
				}
			},

		async _deleteItemCascade(sReqId, sReqSubId) {
			try {
				const oAction = this._oDataModel.bindContext("/deleteItemCascade(...)");
				oAction.setParameter("sReqId", sReqId);
				oAction.setParameter("sReqSubId", sReqSubId);
				await oAction.execute();
				return true;
		
			} catch (e) {
				console.error("Delete item cascade failed:", e);
				throw e;
			}
		},

		/* =========================================================
		* Participant list: auto-append last empty row + delete
		* ======================================================= */

		appendNewRow(oEvent) {
			if (this._oReqModel.getProperty("/req_header/grptype") !== this._oConstant.GroupType.GROUP) return;

			const src = oEvent.getSource();
			const sVal = (oEvent.getParameter && oEvent.getParameter("value")) ?? (src?.getValue?.() ?? "");
			const sTrim = String(sVal).trim();

			const oCtx = src.getBindingContext("request");
			if (!oCtx) return;

			const path = oCtx.getPath();
			const segs = path.split("/");
			const idx = parseInt(segs[segs.length - 1], 10);
			if (!Number.isInteger(idx)) return;

			let aRows = this._oReqModel.getProperty("/participant");
			if (!Array.isArray(aRows)) {
				aRows = [];
				this._oReqModel.setProperty("/participant", aRows);
			}

			this._oReqModel.setProperty(`/participant/${idx}/PARTICIPANTS_ID`, sTrim);

			this._normalizeTrailingEmptyRow(aRows);

			const isLast = idx === aRows.length - 1;
			if (isLast && sTrim) {
				this._oReqModel.setProperty(`/participant/${aRows.length}`, { PARTICIPANTS_ID: "", ALLOCATED_AMOUNT: "" });
			}
		},

		_normalizeTrailingEmptyRow(aRows) {
			let iLastNonEmpty = -1;
			for (let i = 0; i < aRows.length; i++) {
				const r = aRows[i] || {};
				const isEmpty = !String(r.PARTICIPANTS_ID || "").trim() && !String(r.ALLOCATED_AMOUNT || "").trim();
				if (!isEmpty) iLastNonEmpty = i;
			}
			const desiredLength = Math.max(iLastNonEmpty + 2, 1);
			if (aRows.length > desiredLength) {
				aRows.splice(desiredLength);
				this._oReqModel.setProperty("/participant", aRows.slice());
			} else if (aRows.length === 0) {
				aRows.push({ PARTICIPANTS_ID: "", ALLOCATED_AMOUNT: "" });
				this._oReqModel.setProperty("/participant", aRows);
			}
		},

		async onRowDeleteParticipant(oEvent) {
			const oTable = this.byId("req_participant_table");
			let aRows = this._oReqModel.getProperty("/participant") || [];

			// --- 1. Identify which row(s) to delete ---
			let idxFromAction = null;
			const oRow = oEvent.getParameter && oEvent.getParameter("row");
			const visIdx = oEvent.getParameter && oEvent.getParameter("rowIndex");

			const extractIndexFromCtxPath = (oCtx) => {
				if (!oCtx) return null;
				const seg = oCtx.getPath().split("/").pop();
				const i = parseInt(seg, 10);
				return Number.isInteger(i) ? i : null;
			};

			if (oRow) {
				idxFromAction = extractIndexFromCtxPath(oRow.getBindingContext("request"));
			} else if (Number.isInteger(visIdx)) {
				idxFromAction = extractIndexFromCtxPath(oTable.getContextByIndex(visIdx));
			}

			let aToDelete = [];
			const aSel = oTable.getSelectedIndices() || [];

			if (aSel.length > 0) {
				aToDelete = aSel.map((v) => extractIndexFromCtxPath(oTable.getContextByIndex(v)))
					.filter((x) => x !== null);
			} else if (Number.isInteger(idxFromAction)) {
				aToDelete = [idxFromAction];
			}

			if (aToDelete.length === 0) {
				MessageBox.warning(Utility.getText("req_tm_w_select_participant"));
				return;
			}

			aToDelete = Array.from(new Set(aToDelete));

			let aBackendPayload = [];
			let aIndicesToRemove = [];

			aToDelete.forEach(i => {
				const rowData = aRows[i] || {};
				const sPID = String(rowData.PARTICIPANTS_ID ?? rowData.PARTICIPANT_ID ?? "").trim();
				const sReqId = String(rowData.REQUEST_ID ?? this._oReqModel.getProperty("/req_header/reqid") ?? "").trim();
				const sReqSubId = String(rowData.REQUEST_SUB_ID ?? this._oReqModel.getProperty("/req_item/req_subid") ?? "").trim();

				if (sPID && sReqId && sReqSubId) {
					aBackendPayload.push({
						REQUEST_ID: sReqId,
						REQUEST_SUB_ID: sReqSubId,
						PARTICIPANTS_ID: sPID,
						_localIndex: i
					});
				} else {
					aIndicesToRemove.push(i);
				}
			});

			if (aBackendPayload.length > 0) {
				BusyIndicator.show(0);
				try {
					const aCleanPayload = aBackendPayload.map(item => {
						return {
							REQUEST_ID: item.REQUEST_ID,
							REQUEST_SUB_ID: item.REQUEST_SUB_ID,
							PARTICIPANTS_ID: item.PARTICIPANTS_ID
						};
					});

					const oAction = this._oDataModel.bindContext("/deleteParticipants(...)");
					oAction.setParameter("participants", aCleanPayload);

					await oAction.execute();

					aBackendPayload.forEach(item => aIndicesToRemove.push(item._localIndex));

				} catch (error) {
					MessageBox.error(Utility.getText("req_d_e_delete_participant"));
					BusyIndicator.hide();
					return;
				} finally {
					BusyIndicator.hide();
				}
			}

			if (aIndicesToRemove.length > 0) {
				aIndicesToRemove.sort((a, b) => b - a).forEach((i) => {
					if (i >= 0 && i < aRows.length) aRows.splice(i, 1);
				});

				if (!Array.isArray(aRows) || aRows.length === 0) {
					aRows = [{ PARTICIPANTS_ID: "", PARTICIPANT_NAME: "", PARTICIPANT_COST_CENTER: "", ALLOCATED_AMOUNT: "" }];
				} else if (this._normalizeTrailingEmptyRow) {
					this._normalizeTrailingEmptyRow(aRows);
				}

				this._oReqModel.setProperty("/participant", aRows);
				oTable.clearSelection();

				MessageToast.show(Utility.getText("req_tm_s_delete_participant", [aIndicesToRemove.length]));

				if (typeof RequestUtility !== "undefined" && RequestUtility.populateAllocatedAmount) {
					RequestUtility.populateAllocatedAmount();
				}
			}
		},

		/* =========================================================
		* Save Draft / Save Item / Save+Another
		* ======================================================= */

		onSaveItem() {
			this.onSave();
		},

		async onSaveAddAnother(oEvent) {
			await this.onSave(oEvent, true);

			this._setAllControlsVisible(false);
			const oData = this._oReqModel.getData();
			oData.req_item = {};
			if (oData.req_header.grptype === 'Individual') {
				oData.participant = [{
					PARTICIPANTS_ID: oData.user.emp_id,
					PARTICIPANT_NAME: oData.user.name,
					PARTICIPANT_COST_CENTER: oData.user.cost_center,
					ALLOCATED_AMOUNT: ""
				}];
			} else {
				oData.participant = [{ PARTICIPANTS_ID: "", PARTICIPANT_NAME: "", PARTICIPANT_COST_CENTER: "", ALLOCATED_AMOUNT: "" }];
			}
			oData.view = "create";
			this._oReqModel.setData(oData);
		},

		async onSave(oEvent, bAddAnother = false) {
			const oData = this._oReqModel.getData();
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_text"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			const oReqHeader = oData.req_header;
			const oReqItem = oData.req_item;
			const sReqId = String(oData.req_header.reqid || "").trim();
			const sEmpId = this._oSessionModel.getProperty("/userId");
			const bIsEdit = this._oReqModel.getProperty("/view") === "i_edit";

			if (!sReqId || !sEmpId) return MessageBox.error(Utility.getText("req_tm_w_emp_id_req_id_not_found"));

			this.calculateNumberOfHours();

			CustomValidator.init(this.getOwnerComponent(), this.getView());
			if (!(await CustomValidator.validate(this._oConstant.SubmissionTypePrefix.REQUEST))) {
				return;
			}
			
			var sReqTypeId = this._oReqModel.getProperty('/req_header/reqtypeid');
			var bIsCorpoCC = String(sReqTypeId) === String(this._oConstant.RequestType.CORP_CC);

			if (!bIsCorpoCC) {
				var fEstAmount = this._oReqModel.getProperty('/req_item/est_amount');
				if (parseFloat(fEstAmount) <= parseFloat(0)) {
					MessageBox.error(Utility.getText("req_d_w_error_amount"))
					return;
				}
			}

			// add tripstartdate from header to item level for eligibility checking
			if (Object.values(Constants.FrequencyCheckClaimTypeItem).includes(oReqItem.claim_type_item_id)) {
				oReqItem.trip_start_date = oReqHeader.tripstartdate;
			}

			if(this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD){
				await this._setParticipantsForCC();
			}

			// Eligibility Checking
			try {
				var aPayload = EligibilityCheck.generateEligibilityCheckPayload(this, this._oConstant.SubmissionTypePrefix.REQUEST);
				var oReturnPayload = await EligibleScenarioCheck.onEligibilityCheck(this._oDataModel, aPayload);
				var bCanProceed = await EligibilityCheck.eligibilityHandling(this, oReturnPayload, this._oConstant.SubmissionTypePrefix.REQUEST);
			} catch (error) {
				bCanProceed = false;
				MessageBox.error(error.message || Utility.getText("msg_failed_generic_error"));
			};

			if (!bCanProceed) return;

			// validate mandatory fields
			if (!this.getOwnerComponent().getValidator().validate(this.getView())) {
				MessageBox.error(Utility.getText("req_d_w_mandatory_field"), {
					closeOnBrowserNavigation: false
				});
				return;
			}

			BusyIndicator.show(0);

			try {
				let sAttachment1_SFID, sAttachment2_SFID, sAttachment3_SFID, sAttachment4_SFID ;
				if (oReqItem.doc1) {
					const sAttachment1Binary = await Attachment.getFileAsBinary(oReqItem.doc1);
					sAttachment1_SFID = await Attachment.postAttachment(oReqItem.doc1.name, sAttachment1Binary, sEmpId);
				}
				if (oReqItem.doc2) {
					const sAttachment2Binary = await Attachment.getFileAsBinary(oReqItem.doc2);
					sAttachment2_SFID = await Attachment.postAttachment(oReqItem.doc2.name, sAttachment2Binary, sEmpId);
				}
				if (oReqItem.doc3) {
					const sAttachment3Binary = await Attachment.getFileAsBinary(oReqItem.doc3);
					sAttachment3_SFID = await Attachment.postAttachment(oReqItem.doc3.name, sAttachment3Binary, sEmpId);
				}
				if (oReqItem.doc4) {
					const sAttachment4Binary = await Attachment.getFileAsBinary(oReqItem.doc4);
					sAttachment4_SFID = await Attachment.postAttachment(oReqItem.doc4.name, sAttachment4Binary, sEmpId);
				}

				if (oReqItem.claim_type_item_id === this._oConstant.ClaimTypeItem.MED_ADVANCE) {
					oReqItem.cost_center = this._oConstant.MedicalAdvanceInfo.COST_CENTER;
					oReqItem.gl_account = this._oConstant.MedicalAdvanceInfo.GL_ACCOUNT;
				}
				else if (oReqItem.cash_advance) {
					oReqItem.cost_center = this._oConstant.CashAdvanceInfo.COST_CENTER;
					oReqItem.gl_account = this._oConstant.CashAdvanceInfo.GL_ACCOUNT;
				} else {
					const sDefaultChargingCostCenter =
						await Utility.getDefaultChargingCostCenter(
							this._oDataModel,
							oReqHeader.claimtype,
							oReqItem.claim_type_item_id
						);

					if (sDefaultChargingCostCenter) {
						oReqItem.cost_center = sDefaultChargingCostCenter;
					} else {
						oReqItem.cost_center =
							(oReqHeader.altcostcenter && oReqHeader.altcostcenter !== "-")
								? oReqHeader.altcostcenter
								: oReqHeader.costcenter;
					}
					oReqItem.gl_account = await budgetCheck._getGLAccount(this._oDataModel, oReqHeader.claimtype);
				}
					oReqItem.material_code = await budgetCheck._getMaterialCode(this._oDataModel, oReqHeader.claimtype, oReqItem.claim_type_item_id);
				if (oReqItem.cost_center) {
					oReqItem.cost_center =
						String(oReqItem.cost_center)
							.split(" - ")[0]
							.trim();
				}

				// Get Internal Order from ZBUDGET using Request Header Project Code
				if (!oReqItem.internal_order) {
					const sProjectCode = oReqHeader.projectcode;
					const sInternalOrder = await Utility.getInternalOrderByProjectCode(
						this._oDataModel,
						sProjectCode
					);

					oReqItem.internal_order = sInternalOrder;
				}

				if (oReqItem.departure_time || oReqItem.arrival_time) {
					var dtDeparture_date = new Date(oReqItem.departure_time).toISOString() || null;
					var dtArrival_date = new Date(oReqItem.arrival_time).toISOString() || null;
				}

				let oPayload = {
					EMP_ID: 					  sEmpId,
					REQUEST_ID:                   sReqId,
					CLAIM_TYPE_ID:                oData.req_header.claimtype,
					CLAIM_TYPE_ITEM_ID:           oReqItem.claim_type_item_id,
					PURPOSE:                      oReqItem.purpose || null,
					REMARK:                       oReqItem.remark || null,
					COURSE_TITLE:                 oReqItem.course || null,
					DEPENDENT:                    JSON.stringify(oReqItem.dependent),
					KWSP_SPORTS_REPRESENTATION:   oReqItem.sport_rep || null,
					MOBILE_CATEGORY_PURPOSE_ID:   oReqItem.cat_purpose || null,
					VEHICLE_OWNERSHIP_ID:         oReqItem.vehicle_ownership || null,
					VEHICLE_TYPE:                 oReqItem.type_of_vehicle || null,
					VEHICLE_CLASS_ID:             oReqItem.vehicle_class || null,
					ROOM_TYPE:                    oReqItem.room_type || null,
					FLIGHT_CLASS:                 oReqItem.flight_class || null,
					FARE_TYPE_ID:                 oReqItem.fare_type || null,
					MARRIAGE_CATEGORY:            oReqItem.marriage_cat || null,
					MODE_OF_TRANSFER:             oReqItem.mode_of_transfer || null,
					COUNTRY:                      oReqItem.country || null,
					REGION:                       oReqItem.sss || null,
					AREA:                         oReqItem.area || null,
					LOCATION:                     oReqItem.location || null,
					LOCATION_TYPE:                oReqItem.location_type || null,
					FROM_STATE_ID:                oReqItem.from_state || null,
					FROM_LOCATION:                oReqItem.from_location || null,
					FROM_LOCATION_OFFICE:         oReqItem.from_location_office || null,
					TO_STATE_ID:                  oReqItem.to_state || null,
					TO_LOCATION:                  oReqItem.to_location || null,
					TO_LOCATION_OFFICE:           oReqItem.to_location_office || null,
					COST_CENTER:                  oReqItem.cost_center || null,
					GL_ACCOUNT:                   oReqItem.gl_account || null,
					MATERIAL_CODE:                oReqItem.material_code || null,
					START_DATE:                   oReqItem.start_date || null,
					END_DATE:                     oReqItem.end_date || null,
					TRANSFER_DATE:                oReqItem.tarikh_pindah || null,
					START_TIME:                   oReqItem.start_time || null, 
					END_TIME:                     oReqItem.end_time || null,
					DEPARTURE_TIME:               dtDeparture_date || null,
					ARRIVAL_TIME:                 dtArrival_date || null,
					NO_OF_DAYS:                   parseInt(oReqItem.no_of_days, 10) || 0,
					FAMILY_COUNT:                 parseInt(oReqItem.no_of_family_member, 10) || 0,
					EST_NO_PARTICIPANT:           parseInt(oReqItem.est_no_participant, 10) || 1,
					EST_AMOUNT:                   parseFloat(oReqItem.est_amount || 0),
					KILOMETER:                    parseFloat(oReqItem.kilometer || 0),
					RATE_PER_KM:                  oReqItem.rate_per_kilometer || null,
					TOLL:                         parseFloat(oReqItem.toll_amt || 0),
					METER_CUBE_ENTITLED:          parseFloat(oReqItem.cube_eligible || 0),
					METER_CUBE_ACTUAL:            parseFloat(oReqItem.meter_cube_actual || 0),
					DECLARE_CLUB_MEMBERSHIP:      !!oReqItem.club_membership,
					CASH_ADVANCE:                 !!oReqItem.cash_advance,
					TRAVEL_DURATION_DAY:          parseFloat(oReqItem.travel_day || 0), 
                    TRAVEL_DURATION_HOUR:         parseFloat(oReqItem.travel_hour || 0),
                    TRIP_START_DATE:              oReqItem.trip_start_date || null,
                    TRIP_END_DATE:                oReqItem.trip_end_date || null,
                    TRIP_START_TIME:              oReqItem.trip_start_time || null,
                    TRIP_END_TIME:                oReqItem.trip_end_time || null,
                    DAILY_ALLOWANCE:              parseInt(oReqItem.daily_allowance, 10) || 0,
                    ENTITLED_BREAKFAST:           parseInt(oReqItem.entitled_breakfast, 10) || 0,
                    ENTITLED_LUNCH:               parseInt(oReqItem.entitled_lunch, 10) || 0,
                    ENTITLED_DINNER:              parseInt(oReqItem.entitled_dinner, 10) || 0,
					CURRENCY_CODE:				  oReqItem.currency_code || null,
					CURRENCY_RATE:			      parseFloat(oReqItem.currency_rate || null),
					TYPE_OF_PROFESSIONAL_BODY:    oReqItem.type_of_professional_body || null,
					TOTAL_TRAVELLER: 			  oReqItem.no_of_traveler || null,
					LODGING_CATEGORY: 			  oReqItem.lodging_cat || null,
					ROUND_TRIP:					  !!oReqItem.round_trip,
					INTERNAL_ORDER: 			  oReqItem.internal_order || null,
					POLICY_YEAR: 				  oReqItem.policy_year || null,
					DEPENDENT_NATIONAL_ID:		  oReqItem.dependent_national_id || null,
					INSURANCE_MEDICAL_PROVIDER_ID:oReqItem.insurance_medical_provider_id || null,
					INSURANCE_MEDICAL_PROVIDER_NAME:oReqItem.insurance_medical_provider_name || null
				};

				if (sAttachment1_SFID) oPayload.ATTACHMENT1 = `${sAttachment1_SFID} - ${oReqItem.doc1.name}`;
				if (sAttachment2_SFID) oPayload.ATTACHMENT2 = `${sAttachment2_SFID} - ${oReqItem.doc2.name}`;
				if (sAttachment3_SFID) oPayload.ATTACHMENT3 = `${sAttachment3_SFID} - ${oReqItem.doc3.name}`;
				if (sAttachment4_SFID) oPayload.ATTACHMENT4 = `${sAttachment4_SFID} - ${oReqItem.doc4.name}`;
				
				if (bIsEdit) {
					const sReqSubId = String(oReqItem.req_subid || "").trim();

					if (oReqItem.doc1_delete) {
						var sSFID = oReqItem.doc1_delete?.split(" - ")[0];
						await Attachment.deleteAttachment(sSFID);
						oPayload.ATTACHMENT1 = null;
						oReqItem.doc1_delete = null;
					}

					if (oReqItem.doc2_delete) {
						var sSFID = oReqItem.doc2_delete?.split(" - ")[0];
						await Attachment.deleteAttachment(sSFID);
						oPayload.ATTACHMENT2 = null;
						oReqItem.doc2_delete = null;
					}

					if (oReqItem.doc3_delete) {
						var sSFID = oReqItem.doc3_delete?.split(" - ")[0];
						await Attachment.deleteAttachment(sSFID);
						oPayload.ATTACHMENT3 = null;
						oReqItem.doc3_delete = null;
					}

					if (oReqItem.doc4_delete) {
						var sSFID = oReqItem.doc4_delete?.split(" - ")[0];
						await Attachment.deleteAttachment(sSFID);
						oPayload.ATTACHMENT4 = null;
						oReqItem.doc4_delete = null;
					}

					const oList = this._oDataModel.bindList("/ZREQUEST_ITEM", null, null, [
						new Filter("REQUEST_ID", FilterOperator.EQ, sReqId),
						new Filter("REQUEST_SUB_ID", FilterOperator.EQ, sReqSubId)
					], { $$updateGroupId: "itemSave" });

					const aCtx = await oList.requestContexts(0, 1);
					if (!aCtx[0]) throw new Error("Item not found");

					Object.keys(oPayload).forEach(key => aCtx[0].setProperty(key, oPayload[key]));

					await this._upsertParticipantsForItem(sReqId, sReqSubId, oData.participant);
					if (this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD) {
						const aCorpoCards = this._oReqModel.getProperty("/corpo_cards") || [];
						const sClaimTypeItemId = this._oReqModel.getProperty("/req_item/claim_type_item_id");
						await this._upsertCorpoCardsForItem(sReqId, sReqSubId, aCorpoCards, sClaimTypeItemId);
					}
					await this._oDataModel.submitBatch("itemSave");

					Attachment.postMDFChild(sReqId, sReqSubId, sAttachment1_SFID, sAttachment2_SFID,sAttachment3_SFID, sAttachment4_SFID)

				} else {
					const oItemContext = this._oDataModel.bindList("/ZREQUEST_ITEM", null, null, null, {
						$$updateGroupId: "itemCreate"
					}).create(oPayload, true);

					await this._oDataModel.submitBatch("itemCreate");
					await oItemContext.created();

					const sGeneratedSubId = oItemContext.getProperty("REQUEST_SUB_ID");

					if (!sGeneratedSubId) {
						throw new Error("Failed to retrieve generated Request Sub ID from backend.");
					}

					// upload Child MDF
					Attachment.postMDFChild(sReqId, sGeneratedSubId, sAttachment1_SFID, sAttachment2_SFID, sAttachment3_SFID, sAttachment4_SFID)

					const aParts = oData.participant || [];
					let bHasParticipants = false;

					const oPartList = this._oDataModel.bindList("/ZREQ_ITEM_PART", null, null, null, {
						$$updateGroupId: "partCreate"
					});

					for (const p of aParts) {
						const sPID = String(p.PARTICIPANTS_ID || "").trim();
						if (!sPID) continue;

						bHasParticipants = true;
						oPartList.create({
							REQUEST_ID: sReqId,
							REQUEST_SUB_ID: sGeneratedSubId,
							PARTICIPANTS_ID: sPID,
							ALLOCATED_AMOUNT: parseFloat(p.ALLOCATED_AMOUNT || 0)
						}, true);
					}

					if (this._oReqModel.getProperty("/req_header/claimtype") == this._oConstant.ClaimType.CORPO_CRED_CARD) {
						const aCorpoCards = this._oReqModel.getProperty("/corpo_cards") || [];
						const sClaimTypeItemId = this._oReqModel.getProperty("/req_item/claim_type_item_id");
						await this._upsertCorpoCardsForItem(sReqId, sGeneratedSubId, aCorpoCards, sClaimTypeItemId);
					}

					if (bHasParticipants) {
						await this._oDataModel.submitBatch("partCreate");
					}

					const oHeaderContext = this.getView().getBindingContext();
					if (oHeaderContext) oHeaderContext.refresh();

				}

				MessageToast.show("Success");
				if (!bAddAnother) {
					this._loadRequest(sReqId);
					this._oReqModel.setProperty("/view", this._oConstant.PARMode.VIEW);
				} else {
					// Refresh header (incl. total amount) so it reflects the item
					// that was just saved, without resetting the create-item form.
					await PARequestSharedFunction.getHeader(this, sReqId);
				}

			} catch (e) {
				MessageBox.error(e.message || Utility.getText("req_d_e_save_failed"));
			} finally {
				BusyIndicator.hide();
				this._resetReqItemInputs();
			}
		},

		onImportChange1(oEvent) {
			const oData = this._oReqModel.getProperty("/req_item")
			oData.doc1 = oEvent.getParameters("files").files[0];
			if(oData.doc1_delete) oData.doc1_delete = null;
		},

		onImportChange2(oEvent) {
			const oData = this._oReqModel.getProperty("/req_item")
			oData.doc2 = oEvent.getParameters("files").files[0];
			if(oData.doc2_delete) oData.doc2_delete = null;
		},

		onImportChange3(oEvent) {
			const oData = this._oReqModel.getProperty("/req_item")
			oData.doc3 = oEvent.getParameters("files").files[0];
			if(oData.doc3_delete) oData.doc3_delete = null;
		},

		onImportChange4(oEvent) {
			const oData = this._oReqModel.getProperty("/req_item")
			oData.doc4 = oEvent.getParameters("files").files[0];
			if(oData.doc4_delete) oData.doc4_delete = null;
		},

		async _upsertParticipantsForItem(sReqId, sReqSubId, aParticipants) {
			const sGroup = "upsertParts";
			const aList = Array.isArray(aParticipants) ? aParticipants : [];

			let aExistingCtx = [];
			try {
				const oList = this._oDataModel.bindList(
					"/ZREQ_ITEM_PART",
					null,
					null,
					[
						new Filter("REQUEST_ID", FilterOperator.EQ, sReqId),
						new Filter("REQUEST_SUB_ID", FilterOperator.EQ, sReqSubId)
					],
					{ $$ownRequest: true }
				);
				aExistingCtx = await oList.requestContexts(0, Infinity);
			} catch (err) {
				console.error("Load failed:", err);
			}

			const mExisting = {};
			aExistingCtx.forEach(oCtx => {
				const oData = oCtx.getObject();
				const sKey = `${oData.REQUEST_ID}-${oData.REQUEST_SUB_ID}-${oData.PARTICIPANTS_ID}`;
				mExisting[sKey] = oCtx;
			});

			const oPartList = this._oDataModel.bindList("/ZREQ_ITEM_PART", null, null, null, {
				$$updateGroupId: sGroup
			});

			const aProcessedKeys = [];

			aList.forEach((p) => {
				const sPID = String(p.PARTICIPANTS_ID || p.PARTICIPANT_ID || "").trim();
				if (!sPID) return;

				const sCurrentKey = `${sReqId}-${sReqSubId}-${sPID}`;
				const fAlloc = parseFloat(p.ALLOCATED_AMOUNT || 0);
				aProcessedKeys.push(sCurrentKey);

				if (mExisting[sCurrentKey]) {
					// --- UPDATE CASE ---
					const oExistingCtx = mExisting[sCurrentKey];
					if (oExistingCtx.getProperty("ALLOCATED_AMOUNT") !== fAlloc) {
						oExistingCtx.setProperty("ALLOCATED_AMOUNT", fAlloc, sGroup);
					}
				} else {
					// --- CREATE CASE ---
					oPartList.create({
						REQUEST_ID: sReqId,
						REQUEST_SUB_ID: sReqSubId,
						PARTICIPANTS_ID: sPID,
						ALLOCATED_AMOUNT: fAlloc
					}, true);
				}
			});

			Object.keys(mExisting).forEach(sKey => {
				if (!aProcessedKeys.includes(sKey)) {
					mExisting[sKey].delete(sGroup).catch(() => { /* handle silent */ });
				}
			});

			if (this._oDataModel.hasPendingChanges(sGroup)) {
				await this._oDataModel.submitBatch(sGroup);
			}
		},

		/* =========================================================
		* Participant Value Help 
		* ======================================================= */

		onCashAdvanceChange: function (oEvent) {

			// Get model
			const oRequestModel = this.getView().getModel("request");

			// Only relevant when the switch has just been turned ON
			if (!oRequestModel.getProperty("/req_item/cash_advance")) {
				return;
			}

			// ✅ If trip start date is before today → backdated (no-op if no date entered yet)
			if (Common.isTripStartDateBackdated(oRequestModel)) {

				// Update model value
				oRequestModel.setProperty("/req_item/cash_advance", false);

				// Show message
				MessageBox.error(
					Utility.getText("msg_cash_advance_not_allow")
				);
			}
		},

		onValueHelpRequest(oEvent) {
			this._oInputSource = oEvent.getSource();
			if (!this._pEmployeeDialog) {
				this._pEmployeeDialog = Fragment.load({
					id: this.getView().getId(),
					name: "claima.fragment.req_participant_vh",
					controller: this
				}).then(oDialog => {
					this.getView().addDependent(oDialog);
					return oDialog;
				});
			}
			this._pEmployeeDialog.then(oDialog => oDialog.open());
		},

		onParticipantInputChange(oEvent) {
			const oInput = oEvent.getSource();
			const sValue = oInput.getValue();
			const sPath = oInput.getBindingContext("request").getPath();
			const oSelectedRow = oEvent.getParameter("selectedRow");

			if (!sValue) {
				this._updateParticipantData(sPath, null);
				return;
			}

			if (oSelectedRow) {
				const oEmpData = oSelectedRow.getBindingContext().getObject();
				this._updateParticipantData(sPath, oEmpData);
				this.appendNewRow(oEvent);
				return;
			}

			const oListBinding = this.getView().getModel().bindList("/ZEMP_MASTER");
			const oFilter = new Filter("EEID", FilterOperator.EQ, sValue);

			oInput.setBusy(true);
			oListBinding.filter(oFilter).requestContexts(0, 1).then(aContexts => {
				oInput.setBusy(false);
				if (aContexts.length > 0) {
					const oEmpData = aContexts[0].getObject();
					this._updateParticipantData(sPath, oEmpData);
					this.appendNewRow(oEvent);
				} else {
					this._updateParticipantData(sPath, null);
					MessageBox.error(Utility.getText("req_d_e_emp_not_found"));
				}
			}).catch(() => oInput.setBusy(false));
		},

		onValueHelpConfirm(oEvent) {
			const oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				const sPath = this._oInputSource.getBindingContext("request").getPath();
				const oEmpData = oSelectedItem.getBindingContext().getObject();
				this._updateParticipantData(sPath, oEmpData);
				this.appendNewRow(oEvent);
			}
		},

		_updateParticipantData(sRowPath, oEmpData) {

			if (oEmpData) {
				this._oReqModel.setProperty(sRowPath + "/PARTICIPANTS_ID", oEmpData.EEID || oEmpData.ID);
				this._oReqModel.setProperty(sRowPath + "/PARTICIPANT_NAME", oEmpData.NAME);
				this._oReqModel.setProperty(sRowPath + "/PARTICIPANT_COST_CENTER", oEmpData.CC);
				RequestUtility.populateAllocatedAmount();	// populate allocated amount if applicable

			} else {
				this._oReqModel.setProperty(sRowPath + "/PARTICIPANTS_ID", "");
				this._oReqModel.setProperty(sRowPath + "/PARTICIPANT_NAME", "");
				this._oReqModel.setProperty(sRowPath + "/PARTICIPANT_COST_CENTER", "");
			}
		},

		onValueHelpSearch(oEvent) {
			const sValue = oEvent.getParameter("value");
			const oBinding = oEvent.getSource().getBinding("items");
			const aFilters = sValue ? [
				new Filter({
					filters: [
						new Filter("EEID", "Contains", sValue),
						new Filter("NAME", "Contains", sValue)
					],
					and: false
				})
			] : [];
			oBinding.filter(aFilters);
		},

		/* =========================================================
		* Excel Files Logics 
		* ======================================================= */

		onExport() {
			var oModel = this.getView().getModel("request");
			var aData = oModel.getProperty("/participant") || [];

			var aExportData = (aData.length > 0 && aData[0].PARTICIPANTS_ID) ? aData : [];
			var sFileName = this._getExcelFileName("participant");

			var aCols = this._createColumnConfig();
			var oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: aExportData,
				fileName: sFileName,
				worker: false // Set to false for small datasets or if debugging
			};

			var oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.then(function () {
					MessageToast.show("Export successful");
				})
				.finally(function () {
					oSheet.destroy();
				});
		},

		_createColumnConfig() {
			return [
				{ label: 'PARTICIPANTS_ID', property: 'PARTICIPANTS_ID', type: 'string' },
				{ label: 'PARTICIPANT_NAME', property: 'PARTICIPANT_NAME', type: 'string' },
				{ label: 'PARTICIPANT_COST_CENTER', property: 'PARTICIPANT_COST_CENTER', type: 'string' },
				{ label: 'ALLOCATED_AMOUNT', property: 'ALLOCATED_AMOUNT', type: 'number' }
				// Add more columns as per your /req_item_rows structure
			];
		},

		onUploadParticipants(oEvent) {
			var oFile = oEvent.getParameter("files")[0];
			if (!oFile) return;

			BusyIndicator.show(0);

			var oReader = new FileReader();

			oReader.onload = async (e) => {
				try {
					var oData = new Uint8Array(e.target.result);
					var oWorkbook = XLSX.read(oData, { type: "array" });
					var oWorkSheet = oWorkbook.Sheets[oWorkbook.SheetNames[0]];
					var aJsonData = XLSX.utils.sheet_to_json(oWorkSheet);

					if (!aJsonData || aJsonData.length === 0) {
						MessageBox.error(Utility.getText("req_d_e_excel_file_empty"));
						return;
					}

					const aUploadedIds = [...new Set(
						aJsonData
							.map(row => String(row.PARTICIPANTS_ID || "").trim())
							.filter(id => id !== "")
					)];

					if (aUploadedIds.length === 0) {
						MessageBox.error(Utility.getText("req_d_e_excel_no_valid_participant"));
						return;
					}

					const aInvalidIds = await this._getInvalidParticipantIds(aUploadedIds);

					if (aInvalidIds.length > 0) {
						MessageBox.error(
							Utility.getText("req_d_e_excel_upload_failed") +
							aInvalidIds.join(", ")
						);
						return;
					}

					this._oReqModel.setProperty("/participant", aJsonData);
					MessageToast.show("Participants successfully validated and uploaded.");

				} catch (err) {
					MessageBox.error("Error processing file: " + err.message);
				} finally {
					var fu = this.byId("participant_list_upload");
					if (fu) fu.clear();
					BusyIndicator.hide();
				}
			};

			oReader.readAsArrayBuffer(oFile);
		},

		async _getInvalidParticipantIds(aUploadedIds) {
			const iChunkSize = 100;
			let aFoundIdsInDB = [];

			for (let i = 0; i < aUploadedIds.length; i += iChunkSize) {
				const aChunk = aUploadedIds.slice(i, i + iChunkSize);

				const aFilters = aChunk.map(id => new sap.ui.model.Filter("EEID", sap.ui.model.FilterOperator.EQ, id));
				const oCombinedFilter = new sap.ui.model.Filter({ filters: aFilters, and: false });

				const oListBinding = this._oDataModel.bindList("/ZEMP_MASTER", null, null, [oCombinedFilter], {
					$$groupId: "$auto",
					$select: "EEID"
				});

				const aContexts = await oListBinding.requestContexts(0, aChunk.length);
				const aChunkFound = aContexts.map(ctx => ctx.getProperty("EEID"));

				aFoundIdsInDB = aFoundIdsInDB.concat(aChunkFound);
			}

			const aInvalidIds = aUploadedIds.filter(id => !aFoundIdsInDB.includes(id));

			return aInvalidIds;
		},

		_sanitizeFileName(s) {
			return (s || "")
				.replace(/[\\/:*?"<>|]/g, "_")
				.replace(/\s+/g, " ")
				.trim()
				.substring(0, 80);
		},

		_getTodayString() {
			const d = new Date();
			const y = d.getFullYear();
			const m = String(d.getMonth() + 1).padStart(2, "0");
			const day = String(d.getDate()).padStart(2, "0");
			return `${y}-${m}-${day}`;
		},

		_getExcelFileName(sParticipant) {
			if (sParticipant == 'participant') {
				const oInput = this.getOwnerComponent().getModel("request")?.getData() || {};
				const sReqId = oInput?.req_header?.reqid || "";
				const sReqSubId = oInput?.req_item?.req_subid || "";

				return this._sanitizeFileName(`Pre_Approval_Request_${sReqId}_${sReqSubId}_Participant_Data.xlsx`);
			} else {
				const oInput = this.getOwnerComponent().getModel("request")?.getData() || {};
				const sReqId = oInput?.req_header?.reqid || "";

				return this._sanitizeFileName(`Pre_Approval_Request_${sReqId}_${this._getTodayString()}.xlsx`);
			}
		},

		_toDate(val) {

			if (!val) return null;

			if (typeof val === "string" && /^\d{4}-\d{2}-\d{2}T/i.test(val)) {
				const d = new Date(val);
				if (!isNaN(d.getTime())) {
					return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
				}
				return null;
			}

			if (typeof val === "string" && /^\d{4}-\d{2}-\d{2}$/.test(val)) {
				const [y, m, d] = val.split("-").map(Number);
				return new Date(Date.UTC(y, m - 1, d));
			}

			if (val instanceof Date && !isNaN(val.getTime())) {
				return new Date(Date.UTC(val.getFullYear(), val.getMonth(), val.getDate()));
			}

			if (typeof val === "object" && val.year && val.month && val.day) {
				return new Date(Date.UTC(val.year, val.month - 1, val.day));
			}

			return null;
		},

		async onDownloadExcelReport() {
			const oView = this.getView();
			const XLSX = window.XLSX;
			const that = this;

			function _num(val) {
				if (val === null || val === undefined || val === "") return null;
				const n = Number(val);
				return Number.isFinite(n) ? n : null;
			}

			function _applyColumnMeta(ws, columns, startDataRow) {
				ws["!cols"] = columns.map(c => ({ wch: c.width || 12 }));

				const ref = ws["!ref"];
				if (!ref) return;

				const range = XLSX.utils.decode_range(ref);

				for (let c = 0; c < columns.length; c++) {
					const meta = columns[c];
					if (!meta.type) continue;

					for (let r = startDataRow; r <= range.e.r; r++) {
						const addr = XLSX.utils.encode_cell({ c, r });
						const cell = ws[addr];
						if (!cell) continue;

						if (meta.type === "date") {
							const dt = that._toDate(cell.v);

							if (dt) {
								cell.t = "d";
								cell.v = dt;
								cell.z = "yyyy-mm-dd";
							} else {
								delete ws[addr];
							}
						}

						if (meta.type === "number") {
							const n = _num(cell.v);
							if (n === null) {
								delete ws[addr];
							} else {
								cell.t = "n";
								cell.v = n;
								cell.z = meta.scale === 2 ? "#,##0.00" : "#,##0";
							}
						}
					}
				}
			}

			try {
				oView.setBusy(true);

				const input = this._oReqModel?.getData();
				if (!input) {
					MessageBox.error(Utility.getText("req_d_e_excel_no_request_data"));
					return;
				}

				const header = input.req_header || {};
				const items = input.req_item_rows || [];
				const item_part = await this._getParticipantsList(header.reqid);

				// -------------------------------
				// Build Header Row
				// -------------------------------
				const headerRow = {
					"Request ID": header.reqid,
					"Purpose": header.purpose,
					"Trip Start Date": header.tripstartdate,
					"Trip End Date": header.tripenddate,
					"Event Start Date": header.eventstartdate,
					"Event End Date": header.eventenddate,
					"Location": header.location || "",
					"Individual/Group": header.grptype || "",
					"Type of Transportation": header.transport || "",
					"Request Status": header.reqstatus,
					"Cost Center": header.costcenter,
					"Alternate Cost Center": header.altcostcenter || "-",
					"Cash Advance (MYR)": header.cashadvamt,
					"Pre Approval Amount (MYR)": header.reqamt,
					"Request Type": header.reqtype,
					"Comment": header.comment || "",
					"Claim Type": header.claimtype,
				};

				const headerColumns = [
					{ label: "Request ID", property: "Request ID", type: "string" },
					{ label: "Purpose", property: "Purpose", type: "string" },
					{ label: "Trip Start Date", property: "Trip Start Date", type: "date" },
					{ label: "Trip End Date", property: "Trip End Date", type: "date" },
					{ label: "Event Start Date", property: "Event Start Date", type: "date" },
					{ label: "Event End Date", property: "Event End Date", type: "date" },
					{ label: "Location", property: "Location", type: "string" },
					{ label: "Individual/Group", property: "Individual/Group", type: "string" },
					{ label: "Type of Transportation", property: "Type of Transportation", type: "string" },
					{ label: "Request Status", property: "Request Status", type: "string" },
					{ label: "Cost Center", property: "Cost Center", type: "string" },
					{ label: "Alternate Cost Center", property: "Alternate Cost Center", type: "string" },
					{ label: "Cash Advance (MYR)", property: "Cash Advance (MYR)", type: "number", scale: 2 },
					{ label: "Pre Approval Amount (MYR)", property: "Pre Approval Amount (MYR)", type: "number", scale: 2 },
					{ label: "Request Type", property: "Request Type", type: "string" },
					{ label: "Comment", property: "Comment", type: "string" },
					{ label: "Claim Type", property: "Claim Type", type: "string" }
				];

				const headerLabels = headerColumns.map(c => c.label);
				const headerValues = headerColumns.map(c => headerRow[c.property] ?? "");

				const wsHeader = XLSX.utils.aoa_to_sheet([headerLabels, headerValues]);
				_applyColumnMeta(wsHeader, headerColumns, 1);

				// -------------------------------
				// Items Sheet
				// -------------------------------
				const itemsColumns = [
					{ label: "Employee ID", property: "EMP_ID", type: "string" },
					{ label: "Request ID", property: "REQUEST_ID", type: "string" },
					{ label: "Request Sub ID", property: "REQUEST_SUB_ID", type: "string" },
					{ label: "Claim Type ID", property: "CLAIM_TYPE_ID", type: "string" },
					{ label: "Claim Type Desc", property: "CLAIM_TYPE_DESC", type: "string" },
					{ label: "GL Account", property: "GL_ACCOUNT", type: "string" },
					{ label: "Claim Type Item ID", property: "CLAIM_TYPE_ITEM_ID", type: "string" },
					{ label: "Claim Type Item Desc", property: "CLAIM_TYPE_ITEM_DESC", type: "string" },
					{ label: "Cost Center", property: "COST_CENTER", type: "string" },
					{ label: "Material Code", property: "MATERIAL_CODE", type: "string" },
					{ label: "Number of days", property: "NO_OF_DAYS", type: "number" },
					{ label: "Purpose", property: "PURPOSE", type: "string" },
					{ label: "Est. Amount (MYR)", property: "EST_AMOUNT", type: "string" },
					{ label: "Dependent", property: "DEPENDENT", type: "string" },
					{ label: "Dependent Name", property: "LEGAL_NAME", type: "string" },
					{ label: "Dependent Relationship", property: "RELATIONSHIP", type: "string" },
					{ label: "Remarks/Justification", property: "REMARK", type: "string" },
					{ label: "Course Title", property: "COURSE TITLE", type: "string" },
					{ label: "KWSP Sport Represent", property: "KWSP_SPORTS_REPRESENTATION", type: "string" },
					{ label: "Sport Represent Desc", property: "SPORTS_REPRESENTATION_DESC", type: "string" },
					{ label: "Declare Club Membership", property: "DECLARE_CLUB_MEMBERSHIP", type: "string" },
					{ label: "Category/Purpose (Mobile) ID", property: "MOBILE_CATEGORY_PURPOSE_ID", type: "string" },
					{ label: "Category/Purpose (Mobile) Desc", property: "MOBILE_CATEGORY_PURPOSE_DESC", type: "string" },
					{ label: "Attachment 1", property: "ATTACHMENT 1", type: "string" },
					{ label: "Attachment 2", property: "ATTACHMENT 2", type: "string" },
					{ label: "Attachment 3", property: "ATTACHMENT 3", type: "string" },
					{ label: "Attachment 4", property: "ATTACHMENT 4", type: "string" },
					{ label: "Start Date", property: "START DATE", type: "date" },
					{ label: "End Date", property: "END DATE", type: "date" },
					{ label: "Vehicle Ownership ID", property: "VEHICLE OWNERSHIP_ID", type: "string" },
					{ label: "Vehicle Ownership Desc", property: "VEHICLE OWNERSHIP_DESC", type: "string" },
					{ label: "Room Type", property: "ROOM TYPE", type: "string" },
					{ label: "Room Type Desc", property: "ROOM_TYPE_DESC", type: "string" },
					{ label: "Country", property: "COUNTRY", type: "string" },
					{ label: "Location", property: "LOCATION", type: "string" },
					{ label: "Negara/Wilayah", property: "AREA", type: "string" },
					{ label: "Description", property: "AREA_DESC", type: "string" },
					{ label: "Number of Family Member", property: "FAMILY_COUNT", type: "number" },
					{ label: "Vehicle Type", property: "VEHICLE_TYPE", type: "string" },
					{ label: "vehicle Type Desc", property: "VEHICLE_TYPE_DESC", type: "string" },
					{ label: "Kilometer", property: "KILOMETER", type: "number" },
					{ label: "Rate per KM ID", property: "RATE PER KM (RATE_KM_ID)", type: "string" },
					{ label: "Rate", property: "RATE", type: "number" },
					{ label: "Toll", property: "TOLL", type: "string" },
					{ label: "Flight Class ID", property: "FLIGHT CLASS", type: "string" },
					{ label: "Flight Class Desc", property: "FLIGHT_CLASS_DESC", type: "string" },
					{ label: "Location Type", property: "LOCATION TYPE", type: "string" },
					{ label: "Location Type Desc", property: "LOC_TYPE_DESC", type: "string" },
					{ label: "From State", property: "FROM STATE", type: "string" },
					{ label: "From Location", property: "FROM LOCATION", type: "string" },
					{ label: "From Location (Office)", property: "FROM_LOCATION_OFFICE", type: "string" },
					{ label: "To State", property: "TO STATE", type: "string" },
					{ label: "To Location", property: "TO LOCATION", type: "string" },
					{ label: "To Location (Office)", property: "TO_LOCATION_OFFICE", type: "string" },
					{ label: "Mode of Transfer", property: "MODE OF TRANSFER", type: "string" },
					{ label: "Tarikh Pindah", property: "TARIKH PINDAH", type: "date" },
					{ label: "Region", property: "REGION", type: "string" },
					{ label: "Region Description", property: "REGION_DESC", type: "string" },
					{ label: "Marriage Category ID", property: "MARRIAGE_CATEGORY", type: "string" },
					{ label: "Marriage Category Desc", property: "MARRIAGE_CATEGORY_DESC", type: "string" },
					{ label: "Member Cube (Eligible)", property: "MEMBER CUBE ELIGIBLE", type: "string" },
					{ label: "Member Cube (Actual)", property: "MEMBER CUBE ACTUAL", type: "string" },
					{ label: "Departure Time", property: "DEPARTURE TIME", type: "time" },
					{ label: "Arrival Time", property: "ARRIVAL TIME", type: "time" },
					{ label: "Lodging Category ID", property: "LODGING CATEGORY", type: "string" },
					{ label: "Lodging Category Desc", property: "LODGING_CATEGORY_DESC", type: "string" },
					{ label: "Estimated Participants", property: "ESTIMATED PARTICIPANTS", type: "string" },
					{ label: "Cash Advance (Yes/No)", property: "CASH ADVANCE", type: "string" },
					{ label: "Insurance Medical Provider ID", property: " INSURANCE_MEDICAL_PROVIDER_ID", type: "string" },
					{ label: "Insurance Medical Provider Name", property: "INSURANCE_MEDICAL_PROVIDER_NAME", type: "string" }
				];

				const itemsLabels = itemsColumns.map(c => c.label);

				const itemRows = items.map(it => {
					return itemsColumns.map(c => {
						if (c.type === "date") return that._toDate(it[c.property]);
						if (c.type === "number") return _num(it[c.property]);
						return it[c.property] ?? "";
					});
				});

				const wsItems = XLSX.utils.aoa_to_sheet([itemsLabels, ...itemRows]);
				_applyColumnMeta(wsItems, itemsColumns, 1);

				// -------------------------------
				// Build Item Participants Row
				// -------------------------------

				const itemPartColumns = [
					{ label: "Request ID", property: "REQUEST_ID", type: "string", width: 15 },
					{ label: "Request Sub ID", property: "REQUEST_SUB_ID", type: "string", width: 15 },
					{ label: "Participant ID", property: "PARTICIPANTS_ID", type: "string", width: 13 },
					{ label: "Participant Name", property: "NAME", type: "string", width: 20 },
					{ label: "Cost Center", property: "CC", type: "string", width: 13 },
					{ label: "Allocated Amount (MYR)", property: "ALLOCATED_AMOUNT", type: "string", width: 21 }
				];

				const itemPartLabels = itemPartColumns.map(c => c.label);
				const itemPartValues = item_part.map(it => {
					return itemPartColumns.map(c => {
						if (c.type === "date") return that._toDate(it[c.property]);
						if (c.type === "number") return _num(it[c.property]);
						return it[c.property] ?? "";
					});
				});

				const wsItemParts = XLSX.utils.aoa_to_sheet([itemPartLabels, ...itemPartValues]);
				_applyColumnMeta(wsItemParts, itemPartColumns, 1);

				const wb = XLSX.utils.book_new();
				XLSX.utils.book_append_sheet(wb, wsHeader, "Header");
				XLSX.utils.book_append_sheet(wb, wsItems, "Items");
				XLSX.utils.book_append_sheet(wb, wsItemParts, "Participants");

				XLSX.writeFile(wb, this._getExcelFileName(), {
					bookType: "xlsx",
					cellDates: true,
					compression: true
				});

			} catch (e) {
				console.error("Excel export failed:", e);
				MessageBox.error(Utility.getText("req_d_e_excel_export_failed"));
			} finally {
				oView.setBusy(false);
			}
		},

		async _getParticipantsList(reqid) {
			const oListBinding = this._oViewModel.bindList(
				"/ZEMP_REQUEST_PART_VIEW",
				null,
				[new Sorter("REQUEST_SUB_ID", false)],
				[new Filter({
					path: "REQUEST_ID",
					operator: FilterOperator.EQ,
					value1: reqid
				})],
				{
					$$ownRequest: true,
					$$groupId: "$auto"
				}
			);

			try {
				const aCtx = await oListBinding.requestContexts(0, Infinity);
				const a = aCtx.map((ctx) => ctx.getObject());
				return a;
			} catch (err) {
				console.error("OData V4 bindList failed:", err);
				return [];
			}
		},

		/* =========================================================
		* Create Item Selection Items
		* ======================================================= */

		_loadSelections() {
			this._getClaimTypeItemSelection();
			this._getDependent();
		},

		async _getClaimTypeItemSelection() {
			const oData = this._oReqModel.getData();
			const sClaimTypeId = oData.req_header.claimtype;
			const sGroupType = oData.req_header.grptype;

			if (!sClaimTypeId) {
				this._oReqModel.setProperty("/claim_type_items", []);
				return [];
			}

			BusyIndicator.show(0);

			try {
				const oListBinding = this._oDataModel.bindList(
					"/ZCLAIM_TYPE_ITEM",
					null,
					[
						new Sorter("CLAIM_TYPE_ITEM_ID", false)
					],
					[
						new Filter("STATUS", FilterOperator.EQ, "ACTIVE"),
						new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, sClaimTypeId),
						new Filter("SUBMISSION_TYPE", FilterOperator.EQ, this._oConstant.SubmissionType.AUTO_APPROVE),
						new Filter("SUBMISSION_TYPE", FilterOperator.EQ, this._oConstant.SubmissionType.PRE_APPROVE),
						new Filter("CATEGORY_ID", FilterOperator.NE, "X"),			// filter out claim type item that is not required for PAR
						new Filter("CLAIM_TYPE_ITEM_ID", FilterOperator.NE, this._oConstant.ClaimTypeItem.POTONGAN_ELAUN)	// POTONGAN_ELAUN is not selectable on a pre-approval request
						// new Filter("IND_OR_GROUP", FilterOperator.EQ, sGroupType),
						// new Filter("IND_OR_GROUP", FilterOperator.EQ, "I_G")
					],
					{
						$$ownRequest: true,
						$$groupId: "$auto",
						$select: "CLAIM_TYPE_ID,CLAIM_TYPE_ITEM_ID,CLAIM_TYPE_ITEM_DESC"
					}
				);

				const aCtx = await oListBinding.requestContexts(0, Infinity);
				const a = aCtx.map((ctx) => ctx.getObject());

				this._oReqModel.setProperty("/claim_type_items", a);
				return a;

			} catch (err) {
				console.error("ODataV4 load claim type items failed:", err);
				this._oReqModel.setProperty("/claim_type_items", []);
				return [];
			} finally {
				BusyIndicator.hide();
			}
		},

		_getDependent() {
			const aFilters = RequestUtility.getDependentFilter();
			const oListBinding = this._oDataModel.bindList("/ZEMP_DEPENDENT", null, null, aFilters);

			oListBinding.requestContexts().then((aContexts) => {
				const aData = aContexts.map(oCtx => oCtx.getObject());
				this._oReqModel.setProperty('/ZEMP_DEPENDENT', aData);
			}).catch(err => console.error("RequestType Load Failed", err));
		},

		calculateNumberOfHours() {
			const oItem = this._oReqModel.getProperty("/req_item") || {};

			const sDeparture = oItem.departure_time;
			const sArrival = oItem.arrival_time;

			if (!sDeparture || !sArrival) {
				this._oReqModel.setProperty("/req_item/no_of_hours", 0);
				return;
			}

			const dDeparture = new Date(sDeparture);
			const dArrival = new Date(sArrival);

			if (isNaN(dDeparture.getTime()) || isNaN(dArrival.getTime())) {
				this._oReqModel.setProperty("/req_item/no_of_hours", 0);
				return;
			}

			const iDiffMs = dArrival.getTime() - dDeparture.getTime();

			if (iDiffMs < 0) {
				MessageBox.error(Utility.getText("req_d_e_arrival_time_departure_time"));
				this._oReqModel.setProperty("/req_item/no_of_hours", 0);
				return;
			}

			const fHours = Math.round((iDiffMs / (1000 * 60 * 60)) * 100) / 100;

			// 7. Save it back to the JSON model
			this._oReqModel.setProperty("/req_item/no_of_hours", fHours);
		},

		getFromLocationByState() {
			var oSelect = this.byId("item_from_location_office");

			var oBinding = oSelect.getBinding("items");

			if (!oBinding) {
				return;
			}

			var aFilters = [
				new Filter("STATUS", FilterOperator.EQ, "ACTIVE"),
				new Filter("STATE_ID", FilterOperator.EQ, this._oReqModel.getProperty("/req_item/from_state"))
			];

			oBinding.filter(aFilters);
			this._oReqModel.setProperty("/req_item/from_location_office", null);
			this._oReqModel.setProperty("/req_item/to_state", null);
			this._oReqModel.setProperty("/req_item/to_location_office", null);
		},

		getToLocationByState() {
			var oSelect = this.byId("item_to_location_office");

			var oBinding = oSelect.getBinding("items");

			if (!oBinding) {
				return;
			}

			var aFilters = [
				new Filter("STATUS", FilterOperator.EQ, "ACTIVE"),
				new Filter("STATE_ID", FilterOperator.EQ, this._oReqModel.getProperty("/req_item/to_state"))
			];

			oBinding.filter(aFilters);
		},

		async getRatePerKM() {
			var sVehicleType = this._oReqModel.getProperty("/req_item/type_of_vehicle");
			var dTripStartDate = this._oReqModel.getProperty("/req_header/tripstartdate");

			const oListBinding = this._oDataModel.bindList("/ZRATE_KM", null, null, [
				new Filter("VEHICLE_TYPE_ID", FilterOperator.EQ, sVehicleType),
				new Filter("START_DATE", FilterOperator.LE, dTripStartDate),
				new Filter("END_DATE", FilterOperator.GE, dTripStartDate),
				new Filter("STATUS", FilterOperator.EQ, this._oConstant.ClaimTypeItemStatus.ACTIVE,)
			]);

			try {
				const aContexts = await oListBinding.requestContexts(0, 1);

				if (aContexts.length > 0) {
					const oData = aContexts[0].getObject();
					this._oReqModel.setProperty("/req_item/rate_per_kilometer", oData.RATE);
					this._oReqModel.setProperty("/req_item/rate_per_kilometer_id", oData.RATE_KM_ID);
					RequestUtility.populateAllocatedAmount();
					this._oReqModel.setProperty("/req_item/kilometer", await Utility.determineOfficeMileage(
						this._oReqModel.getProperty("/req_item/from_state"),
						this._oReqModel.getProperty("/req_item/from_location_office"),
						this._oReqModel.getProperty("/req_item/to_state"),
						this._oReqModel.getProperty("/req_item/to_location_office")
					));
					RequestUtility.populateAllocatedAmount();
				}
			} catch (oError) {
				console.error("Error fetching Rate Per KM detail", oError);
			}
		},

		/* =========================================================
		* Field Visibility Functions 
		* ======================================================= */

		initializeClaimTypeItemFields: async function (bReset = true) {
			const sClaimTypeItem = this._oReqModel.getProperty("/req_item/claim_type_item_id");
			const sClaimType = this._oReqModel.getProperty("/req_header/claimtype");

			if (!sClaimTypeItem) {
				console.warn("No claim type item found yet.");
				return;
			}

			if (bReset) {
				this._resetReqItemInputs();

				const oLocationTypeSelect = this.byId("item_location_type");
				if (oLocationTypeSelect) {
					oLocationTypeSelect.setForceSelection(false);
					oLocationTypeSelect.setSelectedKey("");
				}
			}

			BusyIndicator.show(0);

			try {
				const oListBinding = this._oDataModel.bindList("/ZDB_STRUCTURE", null, null, [
					new Filter("SUBMISSION_TYPE", FilterOperator.EQ, this._oConstant.RequestFieldVisibilityConfig.SUBMISSION_TYPE),
					new Filter("COMPONENT_LEVEL", FilterOperator.EQ, this._oConstant.RequestFieldVisibilityConfig.ITEM),
					new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, sClaimType),
					new Filter("CLAIM_TYPE_ITEM_ID", FilterOperator.EQ, sClaimTypeItem)
				]);

				const aCtx = await oListBinding.requestContexts(0, 1);

				if (!aCtx || aCtx.length === 0) {
					console.warn("No configuration rows for claim type item:", sClaimTypeItem);
					this._setAllControlsVisible(false);
					return;
				}

				const oData = aCtx[0].getObject();
				const sFields = oData.FIELD || "";

				const aFieldIds = sFields.replace(/[\[\]\s]/g, "").split(",").filter(id => id.length > 0);

				this._setAllControlsVisible(false);

				if (aFieldIds.length > 0) {
					aFieldIds.forEach(id => {
						const control = this._resolveControl(id, "request");
						if (control && typeof control.setVisible === "function") {
							control.setVisible(true);
						} else {
							console.warn("Control not found or not visible-capable:", id);
						}
					});
					const _oHeader = this._oReqModel.getProperty("/req_header") || {};
					const _oItem = this._oReqModel.getProperty("/req_item") || {};

					// calculate number of days
					var iDiffDays = DateUtility.calculateNumberOfDays(this._oConstant.SubmissionTypePrefix.REQUEST, _oHeader, _oItem);
					this._oReqModel.setProperty("/req_item/no_of_days", iDiffDays);

					// get number of family members including requestor him/herself
					var iNoOfFamilyMember = await Utility.getNumberOfFamilyMembers(sClaimTypeItem);
					this._oReqModel.setProperty("/req_item/no_of_family_member", iNoOfFamilyMember);

					this._onFilterRegion();

					// set filters for state and location (office) fields if values exist
					Utility.init(this.getOwnerComponent(), this.getView());
					Utility.setFiltersExistingStateLocation(this._oConstant.SubmissionTypePrefix.REQUEST);

					// special initialization based on claim type item
					switch (sClaimTypeItem) {
						case Constants.ClaimTypeItem.MED_ADVANCE:
							this._oReqModel.setProperty("/req_item/cash_advance",true);
							this._oReqModel.setProperty("/req_item/policy_year",String(new Date().getFullYear()));
						break;
						// set visible for the number of family member and traveller when choosing travel with Family Now
						case Constants.ClaimTypeItem.LOD_TUKAR:
						case Constants.ClaimTypeItem.MKN_TUKAR:
							if (_oHeader.transferfamilynowlater === Constants.TravelWithFamilyNowOrLater.NOW) {
								Object.values(Constants.PARSpecialFieldVisibilityForElaunTukar).forEach(id => {
									const control = this._resolveControl(id, "request");
									if (control && typeof control.setVisible === "function") {
										control.setVisible(true);
									} else {
										console.warn("Control not found or not visible-capable:", id);
									}
								});
							}

						// populate entitled amount 
						case Constants.ClaimTypeItem.LAUT:
						case Constants.ClaimTypeItem.LODGING_L:
						case Constants.ClaimTypeItem.LOD_TUKAR:
							if (this._oReqModel.getProperty("/view") === Constants.PARMode.CREATE) {
								RequestUtility.populateAllocatedAmount();
							}
							break;

						// remove business class option for FLIGHT_L
						case Constants.ClaimTypeItem.FLIGHT_L:
							this._removeBusinessClass();

						case Constants.ClaimTypeItem.KILOMETER:
							/// RoundTrip edit
							if (this._oReqModel.getProperty("/req_item/round_trip")) {
								this._oReqModel.setProperty("/req_item/roundtrip_km", this._oReqModel.getProperty("/req_item/kilometer") * 2);
							}
							break;
						default:
							break;
					}
				}

			} catch (err) {
				console.error("OData bindList failed:", err);
			} finally {
				BusyIndicator.hide();
			}
		},

		_setAllControlsVisible(bVisible) {
			const aControlIds = [
				"i_no_of_days_1",
				"i_purpose",
				"i_amount",
				"i_dependent",
				"i_remarks",
				"i_course_title",
				"i_sport_rep",
				"i_club_membership",
				"i_attachment_1",
				"i_category_purpose",
				"i_attachment_2",
				"i_no_of_days_2",
				"i_start_date",
				"i_end_date",
				"i_vehicle_ownership",
				"i_room_type",
				"i_country",
				"i_location",
				"i_negara_wilayah",
				"i_no_of_family_member",
				"i_type_of_vehicle",
				"i_fare_type",
				"i_kilometer",
				"i_rate_per_kilometer",
				"i_toll",
				"i_flight_class",
				"i_location_type",
				"i_mode_of_transfer",
				"i_tarikh_pindah",
				"i_no_of_days_3",
				"i_sss",
				"i_cube_eligible",
				"i_departure_time",
				"i_arrival_time",
				"i_trip_start_date",
				"i_trip_end_date",
				"i_trip_start_time",
				"i_trip_end_time",
				"i_travel_day",
				"i_travel_hour",
				"i_breakfast",
				"i_lunch",
				"i_dinner",
				"i_daily_allowance",
				"i_currency_code",
				"i_currency_rate",
				"i_type_of_prof_body",
				"i_no_of_traveler",
				"i_attachment_3",
				"i_attachment_4"
			];

			aControlIds.forEach(id => {
				const c = this._resolveControl(id, "request");
				if (c && typeof c.setVisible === "function") {
					c.setVisible(bVisible);
				}
			});
		},

		_resolveControl: function (sId, sFragmentId) {
			let c = this.getView().byId(sId);
			if (c) return c;

			if (sFragmentId) {
				c = Fragment.byId(this.getView().createId(sFragmentId), sId);
				if (c) return c;

				c = Fragment.byId(sFragmentId, sId);
				if (c) return c;
			}

			return sap.ui.getCore().byId(`${sFragmentId}--${sId}`) || sap.ui.getCore().byId(sId);
		},

		/* =========================================================
		* Approver Functions (Aiman)
		* ======================================================= */

		onApproveRequest: async function () {
			// 1) Ensure Reject model exists (for comment)
			let oReject = this.getView().getModel("Reject");
			if (!oReject) {
				oReject = new JSONModel({ approvalComment: "" });
				this.getView().setModel(oReject, "Reject");
			}
			oReject.setProperty("/approvalComment", "");

			// 2) Ensure Type model exists (for visibility/mode)
			let oType = this.getView().getModel("Type");
			if (!oType) {
				oType = new JSONModel({ mode: "" });
				this.getView().setModel(oType, "Type");
			}
			oType.setProperty("/mode", "APPROVE_REQ");

			const sClaimType = this._oReqModel.getProperty("/req_header/claimtype");
			if (sClaimType === this._oConstant.ClaimType.GALAKAN) {
				try {
					// 2. Specific Variable Name: Prevents conflicts with other dialogs
					if (!this._oDisclaimerGalakanDialog) {

						this._oDisclaimerGalakanDialog = await Fragment.load({
							id: this.getView().getId(),
							name: "claima.fragment.disclaimergalakan",
							controller: this
						});

						this.getView().addDependent(this._oDisclaimerGalakanDialog);
					}
					this._oDisclaimerGalakanDialog.open();

				} catch (oError) {
					console.error("Failed to load Disclaimer Galakan Dialog:", oError);
				}

				return;
			}

			ApproveDialog.open(this);
		},

		// Shared event handler for Confirm buttons
		onDisclaimerDialogConfirm: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();

			oDialog.close();

			if (oDialog === this._oDisclaimerGalakanDialog) {
				ApproveDialog.open(this);
			}
		},

		// Shared event handler for Cancel buttonss
		onDisclaimerDialogCancel: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();
			oDialog.close();
		},

		onRejectRequest: function () {
			// 1) Ensure form model
			let oReject = this.getView().getModel("Reject");
			if (!oReject) {
				oReject = new JSONModel({ rejectReasonKey: "", approvalComment: "" });
				this.getView().setModel(oReject, "Reject");
			} else {
				oReject.setProperty("/rejectReasonKey", "");
				oReject.setProperty("/approvalComment", "");
			}

			// 2) Ensure UI state model
			let oType = this.getView().getModel("Type");
			if (!oType) {
				oType = new JSONModel({ mode: "" });
				this.getView().setModel(oType, "Type");
			}
			oType.setProperty("/mode", "REJECT_REQ");

			RejectDialog.open(this);
		},

		onSendBackRequest: function () {
			// Ensure form model
			let oReject = this.getView().getModel("Reject");
			if (!oReject) {
				oReject = new JSONModel({ sendBackReasonKey: "", approvalComment: "" });
				this.getView().setModel(oReject, "Reject");
			}
			oReject.setProperty("/sendBackReasonKey", "");
			oReject.setProperty("/approvalComment", "");

			// Ensure UI state model
			let oType = this.getView().getModel("Type");
			if (!oType) {
				oType = new JSONModel({ mode: "" });
				this.getView().setModel(oType, "Type");
			}
			oType.setProperty("/mode", "SENDBACK_REQ");

			SendBackDialog.open(this);
		},

		onClickCancel_app: function () {
			if (this._approveDialog) { this._approveDialog.close(); }
			if (this._sendBackDialog) { this._sendBackDialog.close(); }
			if (this._rejectDialog) { this._rejectDialog.close(); }
		},

		onClickCreate_app: async function () {
			// Minimal validation for reject flow (reason + comment)
			const oReject = this.getView().getModel("Reject");
			const sMode = oReject?.getProperty("/mode"); // "REJECT" here
			const sComment = oReject?.getProperty("/approvalComment")?.trim();
			const sUserId = this._oSessionModel.getProperty("/userId");
			const oRequestModel = this.getView().getModel("request");
			const sReqId = oRequestModel?.getProperty("/req_header/reqid")?.trim();

			const oModelMain = this._oDataModel;
			const oModelView = this._oViewModel;

			if (sMode === this._oConstant.PARMode.APPROVE) {

				try {
					BusyIndicator.show(0);

					// 1. Approve + get payloads from util
					const oPayload = {
						Id				: sReqId,
						UserId			: sUserId,
						ApproverAction	: Constants.ClaimStatus.APPROVED,
						Comments		: sComment,
						RejectionReason : ""
					}
					console.log("Payload for approval:", oPayload);
					await workflowApproval.onProcessApproval(this._oWorkflowModel, oPayload)

					// 2. Close dialog
					this._approveDialog && this._approveDialog.close();

					window.location.reload(true);

				} catch (e) {
					MessageBox.error(e.message);
				} finally {
					BusyIndicator.hide();
				}
			}
		},

		/**
		 * Submit handler for Push Back (STAT03) - PRE-APPROVAL REQUEST
		 * Called by SendBackDialog endButton (see dialog's robust handler binding).
		 */
		onSendBack_app: async function () {
			const oReject = this.getView().getModel("Reject");

			// Read inputs
			const sReason = oReject?.getProperty("/sendBackReasonKey");
			const sComment = oReject?.getProperty("/approvalComment")?.trim();

			// Client-side validation (dialog also disables button, but keep server-safe checks)
			if (!sReason) { MessageBox.error(Utility.getText("req_d_e_approval_push_back_reason")); return; }
			if (!sComment) { MessageBox.error(Utility.getText("req_d_e_approval_comment_empty")); return; }

			try {
				BusyIndicator.show(0);

				// Models
				const oModelMain = this._oDataModel;               // OData main
				const oModelView = this._oViewModel;// OData views

				// Who & what
				const sUserId = this._oSessionModel.getProperty("/userId");
				const oRequestModel = this.getOwnerComponent().getModel("request");
				const sReqId = oRequestModel?.getProperty("/req_header/reqid")?.trim();

				if (!sUserId || !sReqId) {
					throw new Error(Utility.getText("req_tm_w_emp_id_req_id_not_found"));
				}



				// 1) Update approval rows + header, build dataset & email payloads
				const oPayload = {
						Id				: sReqId,
						UserId			: sUserId,
						ApproverAction	: Constants.ClaimStatus.SEND_BACK,
						Comments		: sComment,
						RejectionReason : sReason
					}
					await workflowApproval.onProcessApproval(this._oWorkflowModel, oPayload)

				// 3) Close dialog
				if (this._sendBackDialog) {
					this._sendBackDialog.close();
				}

				window.location.reload(true);

			} catch (e) {
				MessageBox.error(e.message || Utility.getText("req_d_e_push_back_failed"));
			} finally {
				BusyIndicator.hide();
			}
		},

		onReject_app: async function () {
			const oReject = this.getView().getModel("Reject");
			const sReason = oReject?.getProperty("/rejectReasonKey");
			const sComment = oReject?.getProperty("/approvalComment")?.trim();

			if (!sReason) { MessageBox.error(Utility.getText("req_d_e_approval_reject_reason")); return; }
			if (!sComment) { MessageBox.error(Utility.getText("req_d_e_approval_comment")); return; }

			try {
				BusyIndicator.show(0);

				const oModelMain = this._oDataModel;
				const oModelView = this._oViewModel;

				const reqModel = this.getView().getModel("request");
				const sReqId = reqModel?.getProperty("/req_header/reqid")?.trim();

				const oPayload = {
						Id				: sReqId,
						UserId			: this._oSessionModel.getProperty("/userId"),
						ApproverAction	: Constants.ClaimStatus.REJECTED,
						Comments		: sComment,
						RejectionReason : sReason
					}
				await workflowApproval.onProcessApproval(this._oWorkflowModel, oPayload)

				this._rejectDialog && this._rejectDialog.close();

				window.location.reload(true);

			} catch (e) {
				MessageBox.error(e.message || Utility.getText("req_d_e_reject_failed"));
			} finally {
				BusyIndicator.hide();
			}
		},

		onExit: function () {
			try {
				RejectDialog.destroy(this);
			} catch (e) { }
			try {
				SendBackDialog.destroy(this);
			} catch (e) { }
		},

		/* =========================================================
		* xml onchange event trigger
		* ======================================================= */

		/**
		 * method to populate allocated amount if applicable
		 * @public
		 */
		onInputAllocatedAmount: async function (oEvent) {
			if (oEvent.getParameters().id.split("--").pop() === Constants.RequestFormFields.NO_OF_TRAVELERS) {
				this._onChangeTravelers(oEvent);
			}
			RequestUtility.populateAllocatedAmount();
		},

		onInputCCAmount: async function (oEvent){
			const oCorpoFields = this._oReqModel.getProperty("/corpo_cards") || [];
			const sField = oEvent.getSource().data("field");
			const iColSum = PARequestSharedFunction.sumColumn(oCorpoFields, sField);

			this._oReqModel.setProperty('/req_item/est_amount', iColSum);
		},

		/**
		 * method to filter the to state selection
		 * @public
		 */
		onFilterToState: function () {
			const oReqItem = this._oReqModel.getProperty("/req_item");

			var sFromState = oReqItem.from_state;
			var sFromOffice = oReqItem.from_location_office;

			const oSelect = this.byId("item_to_state");
			const oBinding = oSelect.getBinding("items");
			const aFilters = oSelect ? [
				new Filter(Constants.EntitiesFields.STATUS, FilterOperator.EQ, Constants.ClaimTypeItemStatus.ACTIVE),
				new Filter(Constants.EntitiesFields.FROM_STATE_ID, FilterOperator.EQ, sFromState),
				new Filter(Constants.EntitiesFields.FROM_LOCATION_ID, FilterOperator.EQ, sFromOffice)
			] : [];
			oBinding.filter(aFilters);
			this._oReqModel.setProperty("/req_item/to_state", null);
			this._oReqModel.setProperty("/req_item/to_location_office", null);
		},

		/**
		 * method to filter the to location (office) selection
		 * @public
		 */
		onFilterToOffice: function () {
			const oReqItem = this._oReqModel.getProperty("/req_item");

			var sFromState = oReqItem.from_state;
			var sFromOffice = oReqItem.from_location_office;
			var sToState = oReqItem.to_state;

			const oSelect = this.byId("item_to_location_office");
			const oBinding = oSelect.getBinding("items");
			const aFilters = oSelect ? [
				new Filter(Constants.EntitiesFields.STATUS, FilterOperator.EQ, Constants.ClaimTypeItemStatus.ACTIVE),
				new Filter(Constants.EntitiesFields.FROM_STATE_ID, FilterOperator.EQ, sFromState),
				new Filter(Constants.EntitiesFields.FROM_LOCATION_ID, FilterOperator.EQ, sFromOffice),
				new Filter(Constants.EntitiesFields.TO_STATE_ID, FilterOperator.EQ, sToState)
			] : [];
			oBinding.filter(aFilters);
			this._oReqModel.setProperty("/req_item/to_location_office", null);
		},

		/**
		 * check mileage of the office location selected when select 'to location (office)'
		 * @public
		 */
		onSelectToOffice: async function () {
			this._oReqModel.setProperty("/req_item/kilometer", await Utility.determineOfficeMileage(
				this._oReqModel.getProperty("/req_item/from_state"),
				this._oReqModel.getProperty("/req_item/from_location_office"),
				this._oReqModel.getProperty("/req_item/to_state"),
				this._oReqModel.getProperty("/req_item/to_location_office")
			));
			RequestUtility.populateAllocatedAmount();
		},

		/**
		 * Dynamic Filter for Semenanjung/Sabah/Sarawak Dropdown selection 
		 * Check if the claim type item end with L or O to determine the filter for local or oversea
		 * @private
		 */
		_onFilterRegion: function () {
			const oSelect = this.byId("item_select_sss");

			if (!oSelect || !oSelect.getBinding("items")) {
				return;
			}

			const oBinding = oSelect.getBinding("items");

			const sClaimType = this._oReqModel.getProperty("/req_header/claimtype") || "";
			const sClaimTypeItem = this._oReqModel.getProperty("/req_item/claim_type_item_id") || "";

			let aFilters = [];

			if (sClaimTypeItem.endsWith("_L") || sClaimType === Constants.ClaimType.ELAUN_TUKAR) {
				aFilters.push(new Filter(Constants.EntitiesFields.REGION_ID, FilterOperator.NE, Constants.Region.OVERSEA));

			} else if (sClaimTypeItem.endsWith("_O")) {
				aFilters.push(new Filter(Constants.EntitiesFields.REGION_ID, FilterOperator.EQ, Constants.Region.OVERSEA));
			}

			oBinding.filter(aFilters);
		},

		/**
		 * Reset the Request Item Input when changing to new claim type item
		 * @private
		 */
		_resetReqItemInputs: function () {
			const oReqItem = this._oReqModel.getProperty("/req_item");

			const aExcludedFields = [
				Constants.ExcludeField.CLAIM_TYPE_ID,
				Constants.ExcludeField.CLAIM_TYPE_ITEM_ID,
				Constants.ExcludeField.REQUEST_SUB_ID
			];

			Object.keys(oReqItem).forEach((sKey) => {
				if (aExcludedFields.includes(sKey)) {
					return;
				}

				const vCurrentValue = oReqItem[sKey];

				if (sKey === "est_amount" || typeof vCurrentValue === "number") {
					this._oReqModel.setProperty(`/req_item/${sKey}`, 0);
				} else if (typeof vCurrentValue === "boolean") {
					this._oReqModel.setProperty(`/req_item/${sKey}`, false);
				} else {
					this._oReqModel.setProperty(`/req_item/${sKey}`, null);
				}
			});

			let aParticipants = this._oReqModel.getProperty("/participant") || [];
			aParticipants.forEach((row, index) => {
				this._oReqModel.setProperty(`/participant/${index}/ALLOCATED_AMOUNT`, "");
			});

			// set attachment 1 field to be required (mandatory)
			var bIsCorpoCCReset = String(this._oReqModel.getProperty("/req_header/claimtype")) === String(this._oConstant.ClaimType.CORPO_CRED_CARD);
			this.byId("i_attachment_1_file").setRequired(!bIsCorpoCCReset);

		},

		/**
		 * change event to calculate No of days
		 * @public
		 */
		onSelectDate: function () {
			const _oHeader = this._oReqModel.getProperty("/req_header") || {};
			const _oItem = this._oReqModel.getProperty("/req_item") || {};
			var iDiffDays = DateUtility.calculateNumberOfDays(this._oConstant.SubmissionTypePrefix.REQUEST, _oHeader, _oItem);
			this._oReqModel.setProperty("/req_item/no_of_days", iDiffDays);

			// run populate allocated amount if applicable
			RequestUtility.populateAllocatedAmount();
		},

		/**
		 * remove flight business class option
		 * @private
		 */
		_removeBusinessClass: function () {
			const oSelect = this.byId("item_flight_class");
			const oBinding = oSelect.getBinding("items");
			const aFilters = oSelect ? [
				new Filter(Constants.EntitiesFields.FLIGHT_CLASS_ID, FilterOperator.NE, Constants.FlightClass.BUSINESS)
			] : [];
			oBinding.filter(aFilters);
		},

		_onChangeTravelers: function (oEvent) {
			var oInput = oEvent.getSource();
			var iTravelers = parseInt(oInput.getValue(), 10);

			var iMaxFamilyMembers = parseInt(this._oReqModel.getProperty("/req_item/no_of_family_member"), 10);

			oInput.setValueState("None");

			if (isNaN(iTravelers)) {
				oInput.setValueState("Error");
				oInput.setValueStateText(Utility.getText("req_vs_e_invalid_number", []));
				return;
			}

			if (iTravelers > iMaxFamilyMembers) {
				oInput.setValueState("Error");
				oInput.setValueStateText("Number of travelers cannot exceed the number of family members (" + iMaxFamilyMembers + ").");
				
			} else if (iTravelers < 1) {
				oInput.setValueState("Error");
				oInput.setValueStateText("Number of travelers must be at least 1.");
			}
		},
		onSelectRoundTrip: async function (oEvent) {
			this.onInputAllocatedAmount(oEvent);
		},

		 /**
        * Event handler triggered when the user finishes selecting dependents 
        * and closes the MultiComboBox dropdown.
        */
        onDependentSelectionChange: async function (oEvent) {
        
			const oMultiComboBox = oEvent.getSource();
			const aSelectedItems = oMultiComboBox.getSelectedItems() || [];
			const aSelectedKeys = aSelectedItems.map(oItem => oItem.getKey()) || [];

			await RequestUtility._getEntitledMeterCube(aSelectedKeys);
        },

		onCellClick: function (oEvent) {
			const sClickedColumnId = oEvent.getParameter("columnId");
			const sMerchantColumnId = this.byId("merchantRefundColumn").getId();

			const oContext = oEvent.getParameter("rowBindingContext");
			
			if (!oContext) {
				return;
			}

			const oRow = oContext.getObject();

			// Don't open if the first column is empty
			if (!oRow.CARD_NO) {
				return;
			}

			const sViewMode = this.getView().getModel("request").getProperty("/view");
			if (sViewMode === "list") {
				return;
			}

			if (sClickedColumnId === sMerchantColumnId) {
				this._openMerchantRefundDialog(
					oEvent.getParameter("rowBindingContext")
				);
			}
		},

		_openMerchantRefundDialog: async function (oContext) {
			if (!this._oMerchantRefundDialog) {
				this._oMerchantRefundDialog = await sap.ui.core.Fragment.load({
					id: this.getView().getId(),
					name: "claima.fragment.merchantrefund",
					controller: this
				});

				this.getView().addDependent(this._oMerchantRefundDialog);
			}

			this._oMerchantRefundSourceContext = oContext;

			const oRequest = oContext.getObject();

			// Check THIS row's own data, not the shared _oReqModel
			let aRefunds = oRequest.merchant_refunds;

			if (!aRefunds || aRefunds.length === 0) {
				aRefunds = [{
					no: 1,
					card_number: oRequest.CARD_NO,
					cardholder_name: oRequest.CARDHOLDER_NAME,
					merchant_refund_amount: "",
					claim_type: "",
					claim_item: "",
					cost_center: ""
				}];
			} else {
				// Clone so dialog edits don't mutate the row until Save
				aRefunds = JSON.parse(JSON.stringify(aRefunds));
			}
			const oRefundModel = new sap.ui.model.json.JSONModel({
				merchant_refunds: aRefunds,
				view: this._oReqModel.getProperty("/view") // pass current view state into dialog model
			});

			this._oMerchantRefundDialog.setModel(oRefundModel, "request");

			this._oMerchantRefundDialog.open();
		},

		onAddMerchantRefundRow: function () {
			const oModel = this._oMerchantRefundDialog.getModel("request");
			const aRefunds = oModel.getProperty("/merchant_refunds");

			aRefunds.push({
				no: aRefunds.length + 1,
				card_number: aRefunds[0].card_number,
				cardholder_name: aRefunds[0].cardholder_name,
				merchant_refund_amount: "",
				claim_type: "",
				claim_item: "",
				cost_center: ""
			});

			oModel.setProperty("/merchant_refunds", aRefunds);
		},

		onDeleteMerchantRefundRow: function (oEvent) {
			const oModel = this._oMerchantRefundDialog.getModel("request");
			const aRefunds = oModel.getProperty("/merchant_refunds");

			const oItem = oEvent.getSource().getParent();
			const sPath = oItem.getBindingContext("request").getPath(); // "/merchant_refunds/2"
			const iIndex = parseInt(sPath.split("/").pop(), 10);

			aRefunds.splice(iIndex, 1);
			aRefunds.forEach((oRow, i) => { oRow.no = i + 1; });

			oModel.setProperty("/merchant_refunds", aRefunds);
		},

		onMerchantRefundSave: function () {
			const oDialogModel = this._oMerchantRefundDialog.getModel("request");
			const aRefunds = oDialogModel.getProperty("/merchant_refunds");

			// Block save if any row is missing a required field
			const bHasIncompleteRow = aRefunds.some((oRefund) => {
				return !oRefund.merchant_refund_amount ||
					!oRefund.claim_type ||
					!oRefund.claim_item ||
					!oRefund.cost_center;
			});

			if (bHasIncompleteRow) {
				MessageBox.error(Utility.getText("req_d_w_mandatory_field"));
				return;
			}

			// Write back to the SPECIFIC row's context, not a shared global path
			this._oMerchantRefundSourceContext.setProperty("merchant_refunds", aRefunds);

			// Group totals by card_number, in case rows span multiple cards
			const oTotalsByCard = aRefunds.reduce((oAcc, oRefund) => {
				const sCardNo = oRefund.card_number;
				const fAmount = parseFloat(oRefund.merchant_refund_amount) || 0;

				oAcc[sCardNo] = (oAcc[sCardNo] || 0) + fAmount;
				return oAcc;
			}, {});
			
			const aMerchantRefundArr = JSON.stringify(aRefunds);

			// Push each total into the matching cardholder record
			Object.keys(oTotalsByCard).forEach((sCardNo) => {
				this._addMerchantRefundTotalToCardholder(sCardNo, oTotalsByCard[sCardNo].toFixed(2), aMerchantRefundArr);
			});	

			const oCorpoFields = this._oReqModel.getProperty("/corpo_cards") || [];
			const iColSum = PARequestSharedFunction.sumColumn(oCorpoFields, "merchant_refunds_total");
			this._oReqModel.setProperty('/req_item/est_amount', iColSum);

			this._oMerchantRefundDialog.close();
		},

		_addMerchantRefundTotalToCardholder: function (sCardNo, fTotal, aMerchantRefundArr) {
			const aCardholders = this._oReqModel.getProperty("/corpo_cards");

			const iIndex = aCardholders.findIndex((oCard) => oCard.CARD_NO === sCardNo);

			if (iIndex > -1) {
				aCardholders[iIndex].merchant_refunds_total = fTotal;
				aCardholders[iIndex].merchant_refunds_array = aMerchantRefundArr;
			} else {
				console.warn(`No cardholder found for CARD_NO: ${sCardNo}`);
			}

			this._oReqModel.setProperty("/corpo_cards", aCardholders);
		},
		loadMerchantRefundDisplay: function () {
			const aRefundStrings = this._oReqModel.getProperty("/merchant_refund_strings") || [];

			const aTableData = aRefundStrings.map((sText, iIndex) => {
				return { id: iIndex, text: sText };
			});

			let oDisplayModel = this.getView().getModel("refundDisplay");
			if (!oDisplayModel) {
				oDisplayModel = new sap.ui.model.json.JSONModel();
				this.getView().setModel(oDisplayModel, "refundDisplay");
			}
			oDisplayModel.setProperty("/rows", aTableData);
		},
		onMerchantRefundCancel: function () {
			this._oMerchantRefundDialog.close();
		},

		onSelect_CCC_ClaimType: function (oEvent) {
			var sClaimType = oEvent.getParameter("selectedItem").getKey();

			var oClaimTypeSelect = oEvent.getSource();
			var oRow = oClaimTypeSelect.getParent(); // ColumnListItem

			// Find the Claim Item Select in this row
			var oClaimItemSelect = oRow.getCells().find(function (oCell) {
				return oCell.isA("sap.m.Select") &&
					oCell.getId().includes("req_claimTypeItem");
			});

			if (!oClaimItemSelect) {
				return;
			}

			var oBinding = oClaimItemSelect.getBinding("items");

			if (!oBinding) {
				return;
			}

			oBinding.filter([
				new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, sClaimType)
			]);

			// Clear previously selected claim item
			oClaimItemSelect.setSelectedKey("");
		},
		_getMerchantRefundTotal: function (aRefunds) {
			return aRefunds.reduce((fSum, oRefund) => {
				const fAmount = parseFloat(oRefund.merchant_refund_amount) || 0;
				return fSum + fAmount;
			}, 0);
		},

		async _setParticipantsForCC() {
			const aCorpoDetails = this._oReqModel.getProperty("/corpo_cards");
			const aCardholderIds = aCorpoDetails.map((oCard) => oCard.CARDHOLDER_ID).filter((sId) => !!sId);
		
			if (aCardholderIds.length === 0) {
				return;
			}
		
			const oListBinding = this._oDataModel.bindList("/ZEMP_MASTER");
		
			const aFilters = aCardholderIds.map((sId) => new Filter("EEID", FilterOperator.EQ, sId));
			const oCombinedFilter = new Filter({
				filters: aFilters,
				and: false
			});
		
			try {
				const aContexts = await oListBinding.filter(oCombinedFilter).requestContexts();
				const aEmpDataList = aContexts.map((oContext) => oContext.getObject());
		
				if (aEmpDataList.length > 0) {
					const aParticipants = aEmpDataList.map((oEmpData) => {
						return {
							PARTICIPANTS_ID: oEmpData.EEID || "",
							PARTICIPANT_NAME: oEmpData.NAME || "",
							PARTICIPANT_COST_CENTER: oEmpData.CC || "",
							ALLOCATED_AMOUNT: ""
						};
					});
		
					this._oReqModel.setProperty("/participant", aParticipants);
				} else {
					MessageBox.error(Utility.getText("req_d_e_emp_not_found"));
				}
			} catch (oError) {
				console.error("Failed to fetch employee data:", oError);
			}
		},

		async _upsertCorpoCardsForItem(sReqId, sReqSubId, aCorpoCards, sClaimTypeItemId) {
			const sGroup = "upsertCorpoCards";
			const aList = Array.isArray(aCorpoCards) ? aCorpoCards : [];

			const bIsStatementDue = String(sClaimTypeItemId) === String(this._oConstant.ClaimTypeItem.STATMENT_DUE);
			const bIsServiceTax = String(sClaimTypeItemId) === String(this._oConstant.ClaimTypeItem.SERV_TAX);
			const bIsCashback = String(sClaimTypeItemId) === String(this._oConstant.ClaimTypeItem.CASH_BACK);
			const bIsMerchantRefund = String(sClaimTypeItemId) === String(this._oConstant.ClaimTypeItem.MERCH_RETURN);

			// Statement Due needs each cardholder's own cost center from ZEMP_MASTER -
			// batch-fetch once up front instead of one query per card.
			let mCostCenterByCardholder = {};
			if (bIsStatementDue) {
				const aCardholderIds = [...new Set(aList.map(oCard => oCard.CARDHOLDER_ID).filter(sId => !!sId))];
				if (aCardholderIds.length > 0) {
					try {
						const oEmpList = this._oDataModel.bindList(
							"/ZEMP_MASTER",
							null,
							null,
							new Filter({
								filters: aCardholderIds.map((sId) => new Filter("EEID", FilterOperator.EQ, sId)),
								and: false
							}),
							{ $$ownRequest: true, $select: "EEID,CC" }
						);
						const aEmpCtx = await oEmpList.requestContexts(0, Infinity);
						aEmpCtx.forEach((ctx) => {
							const oEmp = ctx.getObject();
							mCostCenterByCardholder[oEmp.EEID] = oEmp.CC;
						});
					} catch (e) {
						console.error("Failed to load cardholder cost centers:", e);
					}
				}
			}

			// Merchant Refund's GL_CODE/MATERIAL_CODE come from real lookups, not
			// the raw claim_type/claim_item codes - GL_CODE from ZCLAIM_TYPE.GL_ACCOUNT
			// (keyed by CLAIM_TYPE_ID), MATERIAL_CODE from ZCLAIM_TYPE_ITEM.MATERIAL_CODE
			// (keyed by CLAIM_TYPE_ID + CLAIM_TYPE_ITEM_ID). Batch-fetch every distinct
			// combination across all cards' refund entries up front.
			let mGlAccountByClaimType = {};
			let mMaterialCodeByClaimTypeItem = {};
			if (bIsMerchantRefund) {
				const aAllRefunds = aList.flatMap(oCard => Array.isArray(oCard.merchant_refunds) ? oCard.merchant_refunds : []);
				const aClaimTypeIds = [...new Set(aAllRefunds.map(r => r.claim_type).filter(Boolean))];
				const aClaimTypeItemPairs = [...new Map(
					aAllRefunds
						.filter(r => r.claim_type && r.claim_item)
						.map(r => [`${r.claim_type}::${r.claim_item}`, { claim_type: r.claim_type, claim_item: r.claim_item }])
				).values()];

				if (aClaimTypeIds.length > 0) {
					try {
						const oTypeList = this._oDataModel.bindList(
							"/ZCLAIM_TYPE",
							null,
							null,
							new Filter({
								filters: aClaimTypeIds.map(sId => new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, sId)),
								and: false
							}),
							{ $$ownRequest: true, $select: "CLAIM_TYPE_ID,GL_ACCOUNT" }
						);
						const aTypeCtx = await oTypeList.requestContexts(0, Infinity);
						aTypeCtx.forEach(ctx => {
							const oT = ctx.getObject();
							mGlAccountByClaimType[oT.CLAIM_TYPE_ID] = oT.GL_ACCOUNT;
						});
					} catch (e) {
						console.error("Failed to load GL accounts for merchant refund claim types:", e);
					}
				}

				if (aClaimTypeItemPairs.length > 0) {
					try {
						const oItemList = this._oDataModel.bindList(
							"/ZCLAIM_TYPE_ITEM",
							null,
							null,
							new Filter({
								filters: aClaimTypeItemPairs.map(oPair => new Filter({
									filters: [
										new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, oPair.claim_type),
										new Filter("CLAIM_TYPE_ITEM_ID", FilterOperator.EQ, oPair.claim_item)
									],
									and: true
								})),
								and: false
							}),
							{ $$ownRequest: true, $select: "CLAIM_TYPE_ID,CLAIM_TYPE_ITEM_ID,MATERIAL_CODE" }
						);
						const aItemCtx = await oItemList.requestContexts(0, Infinity);
						aItemCtx.forEach(ctx => {
							const oI = ctx.getObject();
							mMaterialCodeByClaimTypeItem[`${oI.CLAIM_TYPE_ID}::${oI.CLAIM_TYPE_ITEM_ID}`] = oI.MATERIAL_CODE;
						});
					} catch (e) {
						console.error("Failed to load material codes for merchant refund claim items:", e);
					}
				}
			}

			let aExistingCtx = [];
			try {
				const oList = this._oDataModel.bindList(
					"/ZREQ_ITEM_CCC_PART",
					null,
					null,
					[
						new Filter("REQUEST_ID", FilterOperator.EQ, sReqId),
						new Filter("REQUEST_SUB_ID", FilterOperator.EQ, sReqSubId)
					],
					{ $$ownRequest: true }
				);
				aExistingCtx = await oList.requestContexts(0, Infinity);
			} catch (err) {
				console.error("Load failed:", err);
			}

			const mExisting = {};
			aExistingCtx.forEach(oCtx => {
				const oData = oCtx.getObject();
				const sKey = `${oData.REQUEST_ID}-${oData.REQUEST_SUB_ID}-${oData.CARD_NO}`;
				mExisting[sKey] = oCtx;
			});

			const oPartList = this._oDataModel.bindList("/ZREQ_ITEM_CCC_PART", null, null, null, {
				$$updateGroupId: sGroup
			});

			const aProcessedKeys = [];

			aList.forEach((oCard) => {
				const sCardNo = String(oCard.CARD_NO || "").trim();
				if (!sCardNo) return;

				const sCurrentKey = `${sReqId}-${sReqSubId}-${sCardNo}`;
				aProcessedKeys.push(sCurrentKey);

				let sGlCode = null;
				let sMaterialCode = null;
				let sCostCenter = null;
				let sMerchantRefundArr = null;

				if (bIsStatementDue) {
					sGlCode = this._oConstant.StatementDueInfo.GL_CODE;
					sMaterialCode = this._oConstant.StatementDueInfo.MATERIAL_CODE;
					sCostCenter = mCostCenterByCardholder[oCard.CARDHOLDER_ID] || null;
				} else if (bIsCashback) {
					sGlCode = this._oConstant.CashBackInfo.GL_CODE;
					sMaterialCode = this._oConstant.CashBackInfo.MATERIAL_CODE;
					sCostCenter = this._oConstant.CashBackInfo.COST_CENTER;
				} else if (bIsServiceTax) {
					sGlCode = this._oConstant.ServiceTaxInfo.GL_CODE;
					sMaterialCode = this._oConstant.ServiceTaxInfo.MATERIAL_CODE;
					sCostCenter = this._oConstant.ServiceTaxInfo.COST_CENTER;
				} else if (bIsMerchantRefund) {
					const aRefunds = Array.isArray(oCard.merchant_refunds) ? oCard.merchant_refunds : [];
					const aEnrichedRefunds = aRefunds.map((oRefund) => ({
						...oRefund,
						GL_CODE: mGlAccountByClaimType[oRefund.claim_type] || null,
						MATERIAL_CODE: mMaterialCodeByClaimTypeItem[`${oRefund.claim_type}::${oRefund.claim_item}`] || null,
						COST_CENTER: oRefund.cost_center || null
					}));
					sMerchantRefundArr = aEnrichedRefunds.length > 0
						? JSON.stringify(aEnrichedRefunds)
						: (oCard.merchant_refunds_array || null);
				}

				const oPayload = {
					STATEMENT_DUE_AMT: bIsStatementDue ? parseFloat(oCard.current_balance || 0) : 0,
					SERVICE_TAX: bIsServiceTax ? parseFloat(oCard.service_tax || 0) : 0,
					CASHBACK: bIsCashback ? parseFloat(oCard.cashback || 0) : 0,
					MERCHANT_REFUND_AMT: bIsMerchantRefund ? parseFloat(oCard.merchant_refunds_total || 0) : 0,
					MERCHANT_REFUND_ARR: bIsMerchantRefund ? sMerchantRefundArr : null,
					GL_CODE: sGlCode,
					MATERIAL_CODE: sMaterialCode,
					COST_CENTER: sCostCenter
				};

				if (mExisting[sCurrentKey]) {
					const oExistingCtx = mExisting[sCurrentKey];
					Object.keys(oPayload).forEach((sField) => {
						if (oExistingCtx.getProperty(sField) !== oPayload[sField]) {
							oExistingCtx.setProperty(sField, oPayload[sField], sGroup);
						}
					});
				} else {
					oPartList.create({
						REQUEST_ID: sReqId,
						REQUEST_SUB_ID: sReqSubId,
						CARD_NO: sCardNo,
						...oPayload
					}, true);
				}
			});

			Object.keys(mExisting).forEach(sKey => {
				if (!aProcessedKeys.includes(sKey)) {
					mExisting[sKey].delete(sGroup).catch(() => { /* handle silent */ });
				}
			});

			if (this._oDataModel.hasPendingChanges(sGroup)) {
				await this._oDataModel.submitBatch(sGroup);
			}
		},

		_computeCorpoCardTotals: function () {
			const aCorpoCards = this._oReqModel.getProperty("/corpo_cards") || [];

			const toNum = (v) => parseFloat(v) || 0;

			const oTotals = aCorpoCards.reduce((acc, oCard) => {
				acc.current_balance += toNum(oCard.current_balance);
				acc.service_tax += toNum(oCard.service_tax);
				acc.merchant_refunds_total += toNum(oCard.merchant_refunds_total);
				acc.cashback += toNum(oCard.cashback);
				acc.advance_amount += toNum(oCard.advance_amount);
				return acc;
			}, {
				current_balance: 0,
				service_tax: 0,
				merchant_refunds_total: 0,
				cashback: 0,
				advance_amount: 0
			});

			oTotals.payment_due = oTotals.current_balance - oTotals.cashback;
 
			var sClaimTypeId = this._oReqModel.getProperty('/req_header/claimtype');
			var bIsCorpoCC = String(sClaimTypeId) === String(this._oConstant.ClaimType.CORPO_CRED_CARD);

			Object.keys(oTotals).forEach((k) => {
				oTotals[k] = oTotals[k].toFixed(2);
			});

			this._oReqModel.setProperty("/corpo_totals", oTotals);

			if (bIsCorpoCC) {
				this._oReqModel.setProperty("/req_header/reqamt", oTotals.payment_due);
			}
		},

		async _loadCorpoCardsForEditItem(sReqId, sReqSubId) {
			const aBaseCards = this._oReqModel.getProperty("/corpo_cards") || [];
 
			if (!sReqId || !sReqSubId || aBaseCards.length === 0) {
				return;
			}
 
			try {
				const oListBinding = this._oDataModel.bindList(
					"/ZREQ_ITEM_CCC_PART",
					null,
					null,
					[
						new Filter("REQUEST_ID", FilterOperator.EQ, sReqId),
						new Filter("REQUEST_SUB_ID", FilterOperator.EQ, sReqSubId)
					],
					{
						$$ownRequest: true,
						$$groupId: "$auto",
						$select: "CARD_NO,STATEMENT_DUE_AMT,SERVICE_TAX,CASHBACK,MERCHANT_REFUND_AMT,MERCHANT_REFUND_ARR"
					}
				);
 
				const aCtx = await oListBinding.requestContexts(0, Infinity);
				const mPartsByCard = {};
				aCtx.forEach((ctx) => {
					const oPart = ctx.getObject();
					mPartsByCard[oPart.CARD_NO] = oPart;
				});
 
				const aItemCards = aBaseCards.map((oCard) => {
					const oPart = mPartsByCard[oCard.CARD_NO];
					let aRefundArr = [];
					if (oPart?.MERCHANT_REFUND_ARR) {
						try {
							aRefundArr = JSON.parse(oPart.MERCHANT_REFUND_ARR);
						} catch (e) {
							console.warn("Failed to parse MERCHANT_REFUND_ARR for card:", oCard.CARD_NO);
						}
					}
 
					return {
						...oCard,
						current_balance: parseFloat(oPart?.STATEMENT_DUE_AMT) || 0,
						service_tax: parseFloat(oPart?.SERVICE_TAX) || 0,
						cashback: parseFloat(oPart?.CASHBACK) || 0,
						merchant_refunds_total: parseFloat(oPart?.MERCHANT_REFUND_AMT) || 0,
						merchant_refunds: aRefundArr,
						merchant_refunds_array: JSON.stringify(aRefundArr)
					};
				});
 
				this._oReqModel.setProperty("/corpo_cards", aItemCards);
 
			} catch (e) {
				console.error("Load corpo cards for edit item failed:", e);
			}
		},

		onChange_Dependent: async function (oEvent) {

			const sDependentNo =oEvent.getSource().getSelectedKey();
			const oAction =this._oDataModel.bindContext("/getDependentNationalId(...)");

			oAction.setParameter(
				"dependentNo",
				sDependentNo
			);

			await oAction.execute();

			const sNationalId=
				oAction.getBoundContext().getObject().value;

			this._oReqModel.setProperty("/req_item/dependent_national_id",sNationalId);
		}

	});
});