sap.ui.define([
	"sap/ui/core/Fragment",
	"sap/ui/core/Item",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/BusyIndicator",
	"sap/ui/core/routing/History",
	"sap/ui/core/ValueState",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Label",
	"sap/m/ListMode",
	"claima/utils/ActionStateService",
	"claima/utils/Utility",
	"claima/utils/ClaimUtility",
	"claima/utils/Attachment",
	"claima/utils/budgetCheck",
	"claima/utils/ApprovalLog",
	"claima/utils/ApproveDialog",
	"claima/utils/RejectDialog",
	"claima/utils/SendBackDialog",
	"claima/utils/ApproverUtility",
	"claima/utils/workflowApproval",
	"claima/utils/DateUtility",
	"claima/utils/ExcelExport",
	"claima/utils/EligibilityCheck",
	"claima/utils/EligibilityScenarios/EligibleScenarioCheck",
	"claima/utils/CustomValidator",
	"claima/utils/CustomDuplicationCheck",
	"claima/model/models",
	"claima/utils/Constants",
	"claima/utils/Common"
], function (
	Fragment,
	Item,
	Controller,
	BusyIndicator,
	History,
	ValueState,
	JSONModel,
	Filter,
	FilterOperator,
	Sorter,
	DateFormat,
	MessageBox,
	MessageToast,
	Dialog,
	Button,
	Label,
	ListMode,
	ActionStateService,
	Utility,
	ClaimUtility,
	Attachment,
	budgetCheck,
	ApprovalLog,
	ApproveDialog,
	RejectDialog,
	SendBackDialog,
	ApproverUtility,
	workflowApproval,
	DateUtility,
	ExcelExport,
	EligibilityCheck,
	EligibleScenarioCheck,
	CustomValidator,
	CustomDuplicationCheck,
	models,
	Constants,
	Common
) {
	"use strict";

	return Controller.extend("claima.controller.ClaimSubmission", {

		DateUtility: DateUtility,

		onInit: function () {
			this._oRouter = this.getOwnerComponent().getRouter();
			this._oConstant = this.getOwnerComponent().getModel("constant").getData();
			this._oClaimFragments = Object.create(null);
			this._clearExit = false;
			this.currentHash = null;
			this._oModel = this.getOwnerComponent().getModel();
			this._oViewModel = this.getOwnerComponent().getModel("employee_view");
			this._oSessionModel = this.getOwnerComponent().getModel("session");
			this._oWorkflowModel = this.getOwnerComponent().getModel("workflow");
			this._oDeclarationDialog = null;
			this._oDisclaimerGalakanDialog = null;
			this._sDeleteTarget = null;          // "1" or "2"
			this._oDeleteAttachmentDialog = null;
			this._oOwnerDetail = this.getOwnerComponent().getModel("owner_detail");
			this._oApprovalLog = this.getOwnerComponent().getModel("approval_log");
		
			// decalre custom validator
			CustomValidator.init(this.getOwnerComponent(), this.getView());

			// declare claim utility
			ClaimUtility.init(this.getOwnerComponent(), this.getView());

			// declare excel export utility
			ExcelExport.init(this.getOwnerComponent(), this.getView(), window.XLSX);

			//declare utility
			Utility.init(this.getOwnerComponent(), this.getView());

			ActionStateService.init(this.getOwnerComponent());

			// URL Access
			const oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("ClaimSubmission").attachPatternMatched((event) => { this._onMatched(event); }, this);
			oRouter.attachBeforeRouteMatched((event) => { this._beforeRouteMatched(event); }, this);

			this.getOwnerComponent().setModel(new JSONModel({
				fieldControl: {
					[this._oConstant.EntitiesFields.RECEIPT_DATE]: {
						customErrorMessage: "",
						customMinDateError: "",
						customMaxDateError: ""
					},
					[this._oConstant.EntitiesFields.BILL_DATE]: {
						customErrorMessage: "",
						customMinDateError: "",
						customMaxDateError: ""
					},
					[this._oConstant.EntitiesFields.INSURANCE_PURCH_DATE]: {
						customErrorMessage: "",
					},
					[this._oConstant.EntitiesFields.INSURANCE_CERT_START_DATE]: {
						customErrorMessage: "",
						customMaxDateError: ""
					},
					[this._oConstant.EntitiesFields.INSURANCE_CERT_END_DATE]: {
						customErrorMessage: "",
						customMinDateError: "",
					},
					[this._oConstant.EntitiesFields.MOVE_IN_DATE]: {
						customErrorMessage: "",
						customMinDateError: "",
						customMaxDateError: ""
					},
					[this._oConstant.EntitiesFields.TRIP_START_DATE]: {
						customErrorMessage: "",
						customMinDateError: "",
						customMaxDateError: ""
					},
					[this._oConstant.EntitiesFields.TRIP_END_DATE]: {
						customErrorMessage: "",
						customMinDateError: "",
						customMaxDateError: ""
					}
				}
			}), "appModel");

			this.getView().setModel(models.createClaimHeaderEditableModel(), "claimSubmissionHeaderEditableModel");
			this.getView().setModel(models.createEditButtonModel(), "editButtonModel");
		},

		_beforeRouteMatched: async function (oEvent) {
			if (!this.currentHash || this.currentHash.indexOf("ClaimSubmission") === -1) {
				// skip check if not on claim submission page
				return;
			}

			// refresh data
			this.currentHash = null;
			this.getOwnerComponent().getModel("employee")?.refresh();
			this.getOwnerComponent().getModel("employee_view")?.refresh();

			if (!this._clearExit) {
				// return from claim detail input screen
				this.onCancel_ClaimDetails_Input();

				let oSideNav = true;
				this.onBack_ClaimSubmission(oSideNav);
			}
			else {
				this._clearExit = false;
			}
		},

		_onNavBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				// The history contains a previous step
				window.history.go(-1);
			} else {
				// No history, go to home page
				var oRouter = this.getOwnerComponent().getRouter();
				this._clearExit = true;
				oRouter.navTo("Dashboard", {}, true); // 'true' replaces history
			}
		},

		_onMatched: async function (oEvent) {
			const _oRouter = this.getOwnerComponent().getRouter();
			this.currentHash = _oRouter.getHashChanger().getHash();

			let sClaimId = oEvent.getParameter("arguments").claim_id;

			try {
				sClaimId = decodeURIComponent(sClaimId);
			}
			catch (e) {
				// unable to decode URL
				MessageBox.error(Utility.getText("msg_claimsubmission_decode", [sClaimId]))
				this._onNavBack();
				return;
			}
			const bAllowed = await Utility.checkClaimAccess(sClaimId);
			if (!bAllowed) {
				return;
			}

			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			if (!oClaimSubmissionModel) {
				oClaimSubmissionModel = await this._getNewClaimSubmissionModel("claimsubmission_input");
				await this._loadClaimById(String(sClaimId));
				if (Object.keys(oClaimSubmissionModel.getProperty("/claim_header")).length === 0) {
					// unable to load claim details
					MessageBox.error(Utility.getText("msg_claimsubmission_missing", [sClaimId]))
					this._onNavBack();
				}
			}
			else if (oClaimSubmissionModel.getProperty("/claim_header/claim_id") !== sClaimId) {
				await this._loadClaimById(String(sClaimId));
				if (!oClaimSubmissionModel.getProperty("/claim_header")) {
					// unable to load claim details
					MessageBox.error(Utility.getText("msg_claimsubmission_missing", [sClaimId]))
					this._onNavBack();
				}
			}
			// set view-only
			// TODO: Revisit to make sure the claim is reloaded everytime
			Common.init(this.getOwnerComponent(), this.getView());
			if (
				oClaimSubmissionModel.getProperty("/claim_header/status_id") !== this._oConstant.ClaimStatus.DRAFT &&
				oClaimSubmissionModel.getProperty("/claim_header/status_id") !== this._oConstant.ClaimStatus.SEND_BACK
			) {
				oClaimSubmissionModel.setProperty("/view_only", true);
				await Common.setHeaderEditable(Constants.SubmissionTypePrefix.CLAIMHEADER, false);
			}
			else {
				oClaimSubmissionModel.setProperty("/view_only", false);
			}

			this.getView().getModel("editButtonModel").setProperty("/state", false);
			// load form fragments
			//// reset fragments
			const oClaimSubmissionPage = this.byId("page_claimsubmission")
			oClaimSubmissionPage.removeAllContent();

			// destroy ALL fragments
			if (this._oClaimFragments) {
				for (const sFrag of Object.keys(this._oClaimFragments)) {
					try {
						const oFrag = await this._oClaimFragments[sFrag];
						oFrag?.destroy(true);
					} catch { }
				}
			}
			this._oClaimFragments = Object.create(null);
			await this._showInitFormFragment();
			await this._afterLoadFragments();
		},

		// Shared event handler for Confirm buttons
		onDisclaimerDialogConfirm: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();

			oDialog.close();

			if (oDialog === this._oDeclarationDialog) {
				this._updateClaimSubmission(this._pendingAction);

			} else if (oDialog === this._oDisclaimerGalakanDialog) {
				ApproveDialog.open(this);
			}
		},

		// Shared event handler for Cancel buttons
		onDisclaimerDialogCancel: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();
			oDialog.close();
		},

		_showInitFormFragment: async function () {
			var oPage = this.byId("page_claimsubmission");

			const oHeaderSection = await this._getFormFragment("claimsubmission_summary_claimheader", true);
			await this._replaceContentAt(oPage, 1, oHeaderSection);
			const oItemSection = await this._getFormFragment("claimsubmission_summary_claimitem", true);
			await this._replaceContentAt(oPage, 2, oItemSection);
		},

		_getFormFragment: async function (sName, toCreate) {
			const oView = this.getView();
			if (this._oClaimFragments[sName]) {
				return this._oClaimFragments[sName];
			}
			else if (toCreate) {
				this._oClaimFragments[sName] = Fragment.load({
					id: oView.getId(),
					name: "claima.fragment." + sName,
					type: "XML",
					controller: this
				}).then((oFrag) => {
					oView.addDependent(oFrag);
					return oFrag;
				});
				return this._oClaimFragments[sName];
			}
			else {
				return null;
			}
		},

		_afterLoadFragments: async function () {

			// Reinitialize utilities
			ClaimUtility.init(this.getOwnerComponent(), this.getView());
			Utility.init(this.getOwnerComponent(), this.getView());

			const oView = this.getView();
			const oClaimSubmissionModel = oView.getModel("claimsubmission_input");

			if (!oClaimSubmissionModel) return;

			const sStatusId = oClaimSubmissionModel.getProperty("/claim_header/status_id");
			const sClaimId = oClaimSubmissionModel.getProperty("/claim_header/claim_id");
			const sClaimTypeId = oClaimSubmissionModel.getProperty("/claim_header/claim_type_id");
			const sClaimOwnerId = oClaimSubmissionModel.getProperty("/claim_header/emp_id");
			const sCurrentUserId = this._oSessionModel.getProperty("/userId");

			// Enable attachment button
			if (oClaimSubmissionModel.getProperty("/claim_header/attachment_email_approver")) {
				this.byId("button_claimsummary_viewattachment").setEnabled(true);
			}

			const aEditableStatus = [this._oConstant.ClaimStatus.DRAFT, this._oConstant.ClaimStatus.SEND_BACK];
			const bEditable = aEditableStatus.includes(sStatusId) && (sClaimOwnerId === sCurrentUserId);

			// always show owner detail and approval log once it is submitted
			if (sStatusId !== this._oConstant.ClaimStatus.DRAFT) {

				await ApprovalLog.getApproverList(this._oApprovalLog, this._oViewModel, sClaimId, sClaimTypeId);
				await ApprovalLog.getApprovalLogHistory(this._oApprovalLog, this._oModel, sClaimId);

				this._setOwnerDetail(true);
				this._setApprovalLog(true);
			}

			oClaimSubmissionModel.setProperty("/view_only", !bEditable);
			this._setClaimItemTableToolbar(bEditable);

			this._setEnabledToolbarFooter();		// summary section button control
			this._refreshActionState("SUMMARY");	// footer button control

			this._calculateClaimTotal();
			this._calculateCardAdvanceAmount();
		},

		onSelectCountry: async function(oEvent){
			var oInputModel = this.getView().getModel("claimitem_input");
			if(oInputModel.getProperty("/claim_item/claim_type_item_id") == Constants.ClaimTypeItem.LODG_O){
				Utility.init(this.getOwnerComponent(), this.getView());
				var oResult = await Utility.getLodgingOverseaAmountAndCat(Constants.SubmissionTypePrefix.CLAIM);
				
				oInputModel.setProperty("/claim_item/lodging_category", oResult.sCategory);
				oInputModel.setProperty("/claim_item/eligible_amount", oResult.iEligibleAmount);
				oInputModel.setProperty("/claim_item/amount", ClaimUtility.calculateAmountLodging());
			}
			

		},
		_loadClaimById: async function (sClaimId) {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			const oEmployeeViewModel = await this._ensureModelReady("employee_view");
			const sId = String(sClaimId);

			const aFilters = [new Filter("CLAIM_ID", FilterOperator.EQ, sId)];

			// Header binding
			const oHeaderBinding = oEmployeeViewModel.bindList(
				"/ZEMP_CLAIM_HEADER_VIEW", // <-- adjust if different
				null,
				null,
				aFilters,
				{ $$ownRequest: true, $count: true, $select: ["*"] }
			);

			// Items binding - ZEMP_CLAIM_ITEM_VIEW already carries both the raw
			// values and the *_DESC columns on the same row, so one fetch covers
			// both /claim_items values and their /descr sub-objects.
			const oItemBinding = oEmployeeViewModel.bindList(
				"/ZEMP_CLAIM_ITEM_VIEW", // <-- adjust if different
				null,
				[new Sorter("CLAIM_SUB_ID", false)],
				aFilters,
				{ $$ownRequest: true, $count: true, $select: ["*"] }
			);

			try {
				BusyIndicator.show(0);

				const [aHeaderCtx, aItemCtx] = await Promise.all([
					oHeaderBinding.requestContexts(0, 1),
					oItemBinding.requestContexts(0, Infinity)
				]);

				// Header
				const oHeaderRaw = aHeaderCtx[0]?.getObject();
				if (!oHeaderRaw) {
					console.error("Failed to load claim submission!");
					oClaimSubmissionModel.setProperty("/claim_header", {});
					oClaimSubmissionModel.setProperty("/claim_items", []);
					oClaimSubmissionModel.setProperty("/claim_items_count", 0);
					this.getOwnerComponent().getRouter().navTo("ClaimStatus", {}, {}, true);
				}

				const oHeader = await this._applyClaimHeader(oHeaderRaw);

				// Items
				const aRawItems = aItemCtx.map(ctx => ctx.getObject());
				const aItems = ClaimUtility.mapClaimItems(aRawItems);

				this._applyItemTotalsFallback(oHeader, aItems);

				oClaimSubmissionModel.setProperty("/claim_items", aItems);
				oClaimSubmissionModel.setProperty("/claim_items_count", aItems.length);

				// Item descriptions - derived from the same aRawItems fetched above,
				// not a second query. Index-matching is safe here because both
				// aItems and this descr mapping come from the same array/order.
				ClaimUtility.applyClaimItemDescr(oClaimSubmissionModel, aRawItems);

				// Employee master
				await this._loadEmployeeMasterData();

				// check is approver
				const sStatusId = oClaimSubmissionModel.getProperty("/claim_header/status_id");
				const sClaimId = oClaimSubmissionModel.getProperty("/claim_header/claim_id");
				const sClaimTypeId = oClaimSubmissionModel.getProperty("/claim_header/claim_type_id");
				const sCurrentUserId = this._oSessionModel.getProperty("/userId");
				const sClaimOwnerId = oClaimSubmissionModel.getProperty("/claim_header/emp_id");
				const oEmployeeViewModel = this.getOwnerComponent().getModel("employee_view");

				await ApprovalLog.getApproverList(this._oApprovalLog, oEmployeeViewModel, sClaimId, sClaimTypeId);

				const aApprovalList = this._oApprovalLog.getProperty("/approval") || [];
				const bCurrentUserIsApprover = aApprovalList.some((oApproval) =>
					(oApproval.APPROVER_ID === sCurrentUserId || oApproval.SUBSTITUTE_APPROVER_ID === sCurrentUserId) &&
					oApproval.STATUS === this._oConstant.ClaimStatus.PENDING_APPROVAL
				);

				if (bCurrentUserIsApprover && sClaimOwnerId !== sCurrentUserId) {
					oClaimSubmissionModel.setProperty("/is_approver", true);
					oClaimSubmissionModel.setProperty("/view_only", true);
				} else if (sClaimOwnerId !== sCurrentUserId) {
					oClaimSubmissionModel.setProperty("/view_only", true);
				}
				
			} catch (err) {
				console.error("Failed to load claim header/items:", err);
				oClaimSubmissionModel.setProperty("/claim_header", {});
				oClaimSubmissionModel.setProperty("/claim_items", []);
				oClaimSubmissionModel.setProperty("/claim_items_count", 0);
			} finally {
				BusyIndicator.hide();
			}
		},

		/**
		 * Maps the raw header row to the form shape, sets owner detail, replaces
		 * claimsubmission_input with a fresh model instance, applies medical
		 * entitlement lookup (MEDICAL/MEDICAL_ADVANCE only), header description
		 * lookup, the view-only flag, and resets is_approver.
		 *
		 * @param {object} oHeaderRaw - raw ZEMP_CLAIM_HEADER_VIEW row
		 * @returns {Promise<object>} the mapped header
		 */
		_applyClaimHeader: async function (oHeaderRaw) {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			const oHeader = ClaimUtility.mapClaimHeaderToForm(oHeaderRaw);
			Utility.mapOwnerDetail(this._oOwnerDetail, oHeaderRaw, this._oConstant.SubmissionOwnerType.CLAIMANT);

			oClaimSubmissionModel.setProperty("/claim_header", oHeader);

			if (oHeader.claim_type_id === this._oConstant.ClaimType.MEDICAL ||
				oHeader.claim_type_id === this._oConstant.ClaimType.MEDICAL_ADVANCE
			) {
				await Utility.getRemainingMedicalEntitlement(
					oClaimSubmissionModel,
					oHeader.emp_id,
					"/claim_header/medical_remaining"
				);
			}

			await Utility.applyClaimHeaderDataDescr(oClaimSubmissionModel);

			const sStatus = oClaimSubmissionModel.getProperty("/claim_header/status_id");
			const bViewOnly = sStatus !== this._oConstant.ClaimStatus.DRAFT && sStatus !== this._oConstant.ClaimStatus.SEND_BACK;
			oClaimSubmissionModel.setProperty("/view_only", bViewOnly);

			if (oClaimSubmissionModel.getProperty("/is_approver")) {
				oClaimSubmissionModel.setProperty("/is_approver", false);
			}

			return oHeader;
		},

		/**
		 * If the header had no total_claim_amount, derives it from non-CCC-charged
		 * items and writes it back onto the model.
		 */
		_applyItemTotalsFallback: function (oHeader, aItems) {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			if (oHeader.total_claim_amount) {
				return;
			}
			const nTotal = aItems
				.filter((it) => !it.charged_to_ccc)
				.reduce((s, it) => s + (Number(it.amount) || 0), 0);

			oClaimSubmissionModel.setProperty("/claim_header/total_claim_amount", nTotal);
		},

		/**
		 * Loads the current user's ZEMP_MASTER record and its resolved
		 * descriptions onto /emp_master, when found.
		 */
		_loadEmployeeMasterData: async function () {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			const emp_data = await Utility.getEmpIdDetail(
				this._oModel,
				Constants.EntitiesFields.EEID,
				this._oSessionModel.getProperty("/userId")
			);
			if (emp_data) {
				oClaimSubmissionModel.setProperty("/emp_master", emp_data);
				await Utility.applyEmpDataDescr(oClaimSubmissionModel);
			}
		},

		_ensureModelReady: async function (sName) {
			const oModel = await this._waitForModel(sName);
			// V4 meta ready
			if (oModel?.getMetaModel?.()?.requestObject) {
				try {
					await oModel.getMetaModel().requestObject("/$EntityContainer");
				} catch (e) {
					// swallow; some backends may restrict $EntityContainer; any requestObject call will do
					await oModel.getMetaModel().requestObject("/");
				}
				return oModel;
			}
			// V2 meta ready
			if (oModel?.metadataLoaded) {
				await oModel.metadataLoaded();
			}
			return oModel;
		},

		_waitForModel: function (sName) {
			return new Promise((resolve) => {
				const check = () => {
					const m = this.getOwnerComponent().getModel(sName);
					if (m) {
						resolve(m);
					} else {
						setTimeout(check, 40);
					}
				};
				check();
			});
		},

		_setApprovalLog: async function (bCheckPage) {
			var oPage = this.byId("page_claimsubmission");
			if (bCheckPage) {
				// display approval log
				const oApprovalLog = await this._getFormFragment("approval_log", true);
				await this._replaceContentAt(oPage, 3, oApprovalLog);
			}
			else {
				// remove approval log
				var oApprovalLogFragment = await this._getFormFragment("approval_log");
				if (oApprovalLogFragment) {
					oPage.removeContent(oApprovalLogFragment);
				}
			}
		},

		_setOwnerDetail: async function (bCheckPage) {
			var oPage = this.byId("page_claimsubmission");
			if (bCheckPage) {
				// display owner detail
				const oOwnerDetail = await this._getFormFragment("claimant_detail", true);
				await this._replaceContentAt(oPage, 0, oOwnerDetail);
			}
			else {
				// remove approval log
				var oApprovalLogFragment = await this._getFormFragment("claimant_detail");
				if (oApprovalLogFragment) {
					oPage.removeContent(oApprovalLogFragment);
				}
			}
		},

		/**
		 * Inserts a fragment into a Page's content aggregation at the given index
		 * @private
		 * @param {sap.m.Page} oPage - the page whose content aggregation is modified
		 * @param {Number} iIndex - desired insertion index
		 * @param {Object} oControl - fragment to insert
		 */
		_replaceContentAt: async function (oPage, iIndex, oControl) {
			// Ensure the slot exists
			const iSafe = Math.min(iIndex, oPage.getContent().length);
			oPage.insertContent(oControl, iSafe);
		},

		_setClaimItemTableToolbar: function (bViewCheck) {


			// ---------------------------------------------------------
			// Existing logic (now using canEdit)
			// ---------------------------------------------------------
			if (bViewCheck) {
				// SHOW buttons
				this.byId("button_claimsummary_createclaim")?.setVisible(true);
				this.byId("button_claimsummary_edit")?.setVisible(true);
				this.byId("button_claimsummary_duplicate")?.setVisible(true);
				this.byId("button_claimsummary_delete")?.setVisible(true);

				// Multi select mode
				this.byId("table_claimsummary_claimitem")?.setMode(ListMode.MultiSelect);
			} else {
				// HIDE buttons
				this.byId("button_claimsummary_createclaim")?.setVisible(false);
				this.byId("button_claimsummary_edit")?.setVisible(false);
				this.byId("button_claimsummary_duplicate")?.setVisible(false);
				this.byId("button_claimsummary_delete")?.setVisible(false);

				// Single select when not editable
				this.byId("table_claimsummary_claimitem")?.setMode(ListMode.SingleSelectMaster);
			}
		},

		_getNewEmployeeModel: function (modelName) {
			// Employee Model
			var oEmployeeModel = new JSONModel({
				"eeid": null,
				"name": null,
				"grade": null,
				"cc": null,
				"pos": null,
				"dep": null,
				"unit_section": null,
				"b_place": null,
				"marital": null,
				"job_group": null,
				"office_location": null,
				"address_line1": null,
				"address_line2": null,
				"address_line3": null,
				"postcode": null,
				"state": null,
				"country": null,
				"contact_no": null,
				"email": null,
				"direct_supperior": null,
				"role": null,
				"user_type": null,
				"mobile_bill_eligibility": null,
				"mobile_bill_elig_amount": null,
				"employee_type": null,
				"position_name": null,
				"position_start_date": null,
				"position_event_reason": null,
				"confirmation_date": null,
				"effective_date": null,
				"updated_date": null,
				"inserted_date": null,
				"medical_insurance_entitlement": null,
				"marital_category": null,
				"descr": {
					"cc": null,
					"dep": null,
					"unit_section": null,
					"marital": null,
					"job_group": null,
					"office_location": null,
					"state": null,
					"country": null,
					"role": null,
					"user_type": null,
					"employee_type": null
				}
			});
			//// set input
			this.getView().setModel(oEmployeeModel, modelName);
			return this.getView().getModel(modelName);
		},

		_getNewClaimSubmissionModel: function (modelName) {
			// Employee Model
			var oEmployeeModel = this._getNewEmployeeModel("emp_current");

			// Claim Submission Model
			var oClaimSubmissionModel = new JSONModel({
				"emp_master": oEmployeeModel.getData(),
				"claimtype": {
					"type": null,
					"item": null,
					"category": null,
					"cost_center": null,
					"marriage_category": null,
					"project_claim": false,
					"has_ccc": false,
					"card_no":null,
					"requestform": {
						"request_id": null,
						"objective_purpose": null,
						"preapproval_amount": null,
						"trip_start_date": null,
						"trip_end_date": null,
						"event_start_date": null,
						"event_end_date": null,
						"alternate_cost_center": null,
						"project_code": null,
						"project_desc": null,
						"cash_advance": null,
						"mode_of_transfer": null,
						"travel_alone_family": null,
						"travel_family_now_later": null,
						"corporate_cred_card" : false,
						"descr": {
							"alternate_cost_center": null,
							"mode_of_transfer": null,
							"travel_alone_family": null,
							"travel_family_now_later": null
						}
					},
					"requestform_amt": null,
					"req_emailapprove": null,
					"course_code": {
						"course_id": null,
						"course_desc": null,
						"session_number": null,
						"start_date": null,
						"end_date": null,
						"course_session_key": null,
					},
					"descr": {
						"type": null,
						"item": null,
						"category": null,
						"cost_center": null
					}
				},
				"is_new": false,
				"is_approver": false,
				"view_only": false,
				"claim_header": {
					"claim_id": null,
					"emp_id": null,
					"purpose": null,
					"trip_start_date": null,
					"trip_end_date": null,
					"event_start_date": null,
					"event_end_date": null,
					"submission_type": null,
					"comment": null,
					"alternate_cost_center": null,
					"cost_center": null,
					"request_id": null,
					"attachment_email_approver": null,
					"status_id": null,
					"claim_type_id": null,
					"total_claim_amount": null,
					"final_amount_to_receive": null,
					"last_modified_date": null,
					"submitted_date": null,
					"last_approved_date": null,
					"last_approved_time": null,
					"payment_date": null,
					"location": null,
					"spouse_office_address": null,
					"house_completion_date": null,
					"move_in_date": null,
					"housing_loan_scheme": null,
					"lender_name": null,
					"specify_details": null,
					"new_house_address": null,
					"dist_old_house_to_office_km": null,
					"dist_old_house_to_new_house_km": null,
					"approver1": null,
					"approver2": null,
					"approver3": null,
					"approver4": null,
					"approver5": null,
					"last_push_back_date": null,
					"course_code": null,
					"session_number": null,
					"project_code": null,
					"cash_advance_amount": null,
					"preapproved_amount": null,
					"reject_reason_id": null,
					"push_back_reason_id": null,
					"last_push_back_time": null,
					"reject_reason_date": null,
					"reject_reason_time": null,
					"mode_of_transfer": null,
					"travel_alone_family": null,
					"travel_family_now_later": null,
					"corporate_cred_card": false,
					"card_no": null,
					"descr": {
						"submission_type": null,
						"alternate_cost_center": null,
						"cost_center": null,
						"request_id": null,
						"status_id": null,
						"claim_type_id": null,
						"housing_loan_scheme": null,
						"lender_name": null,
						"course_code": null,
						"project_code": null,
						"attachment_email_approver": null,
						"mode_of_transfer": null,
						"travel_alone_family": null,
						"travel_family_now_later": null,
					}
				},
				"claim_items": [],
				"claim_items_count": 0,
				"reportnumber": {
					"reportno": null,
					"current": null
				},
				"attachment": {
					"fileName": null,
					"fileContent": null
				}
			});
			//// set input
			this.getView().setModel(oClaimSubmissionModel, modelName);
			return this.getView().getModel(modelName);
		},

		_getNewClaimItemModel: function (modelName) {
			// Claim Item Model
			var oClaimItemModel = new JSONModel({
				"is_new": false,
				"screen_array": [],
				"claim_item": {
					"claim_id": null,
					"claim_sub_id": null,
					"claim_type_item_id": null,
					"percentage_compensation": null,
					"account_no": null,
					"amount": null,
					"attachment_file_1": null,
					"attachment_file_2": null,
					"bill_no": null,
					"bill_date": null,
					"claim_category": null,
					"country": null,
					"disclaimer": false,
					"start_date": null,
					"end_date": null,
					"start_time": null,
					"end_time": null,
					"flight_class": null,
					"from_location": null,
					"from_location_office": null,
					"km": null,
					"location": null,
					"location_type": null,
					"lodging_category": null,
					"lodging_address": null,
					"marriage_category": null,
					"area": null,
					"no_of_family_member": null,
					"parking": null,
					"phone_no": null,
					"rate_per_km": null,
					"receipt_date": null,
					"receipt_number": null,
					"remark": null,
					"room_type": null,
					"region": null,
					"from_state_id": null,
					"to_state_id": null,
					"to_location": null,
					"to_location_office": null,
					"toll": null,
					"total_exp_amount": null,
					"vehicle_type": null,
					"vehicle_fare": null,
					"trip_start_date": null,
					"trip_end_date": null,
					"event_start_date": null,
					"event_end_date": null,
					"travel_duration_day": null,
					"travel_duration_hour": null,
					"provided_breakfast": null,
					"provided_lunch": null,
					"provided_dinner": null,
					"entitled_breakfast": null,
					"entitled_lunch": null,
					"entitled_dinner": null,
					"anggota_id": null,
					"anggota_name": null,
					"dependent_name": null,
					"dependent": null,
					"type_of_professional_body": null,
					"disclaimer_galakan": false,
					"transfer_date": null,
					"no_of_days": null,
					"family_count": null,
					"funeral_transportation": null,
					"round_trip": null,
					"trip_end_time": null,
					"trip_start_time": null,
					"cost_center": null,
					"gl_account": null,
					"material_code": null,
					"vehicle_ownership_id": null,
					"actual_amount": null,
					"arrival_time": null,
					"claim_type_id": null,
					"course_title": null,
					"currency_amount": null,
					"currency_code": null,
					"currency_rate": null,
					"departure_time": null,
					"emp_id": null,
					"fare_type_id": null,
					"insurance_cert_end_date": null,
					"insurance_cert_start_date": null,
					"insurance_package_id": null,
					"insurance_provider_id": null,
					"insurance_provider_name": null,
					"insurance_purchase_date": null,
					"meter_cube_actual": null,
					"meter_cube_entitled": null,
					"mobile_category_purpose_id": null,
					"need_foreign_currency": null,
					"policy_number": null,
					"purpose": null,
					"request_approval_amount": null,
					"study_levels_id": null,
					"travel_days_id": null,
					"vehicle_class_id": null,
					"daily_allowance": null,
					"exclude_tips": null,
					"tips": null,
					"number_of_travellers": null,
					"internal_order": null,
					"charged_to_ccc": null,
					"policy_start_date": null,
					"policy_end_date": null,
					"dependent_national_id": null,
					"insurance_medical_provider_id": null,
					"insurance_medical_provider_name": null,
					"previous_policy_number": null,
					"current_policy_number": null,
					"next_policy_number": null,
					"attachment_file_3": null,
					"attachment_file_4": null,
					"policy_year": null,
					"descr": {
						"claim_type_item_id": null,
						"claim_category": null,
						"country": null,
						"flight_class": null,
						"from_location_office": null,
						"location_type": null,
						"lodging_category": null,
						"marriage_category": null,
						"area": null,
						"rate_per_km": null,
						"room_type": null,
						"region": null,
						"from_state_id": null,
						"to_state_id": null,
						"to_location_office": null,
						"vehicle_type": null,
						"type_of_professional_body": null,
						"no_of_days": null,
						"funeral_transportation": null,
						"material_code": null,
						"vehicle_ownership_id": null,
						"dependent": null,
						"fare_type_id": null,
						"insurance_package_id": null,
						"insurance_provider_id": null,
						"meter_cube_entitled": null,
						"mobile_category_purpose_id": null,
						"study_levels_id": null,
						"claim_type_id": null,
						"vehicle_class_id": null,
						"attachment_file_1": null,
						"attachment_file_2": null,
						"attachment_file_3": null,
						"attachment_file_4": null,
					},
					"eligible_amount": null,
					"no_of_hours": null
				},
				"attachments": {
					"attachment1": {
						"fileName": null,
						"fileContent": null
					},
					"attachment2": {
						"fileName": null,
						"fileContent": null
					},
					"attachment3": {
						"fileName": null,
						"fileContent": null
					},
					"attachment4": {
						"fileName": null,
						"fileContent": null
					}
				}
			});
			//// set input
			this.getView().setModel(oClaimItemModel, modelName);
			return this.getView().getModel(modelName);
		},

		onView_Claim_Attachment: function (oLevel, iFieldNumber, oEvent) {
			// Write to Success Factors API
			BusyIndicator.show(0);
			if (oLevel == 'parent') {
				// get parent attachment
				var oInputModel = this.getView().getModel("claimsubmission_input");
				Attachment.onViewDocument(this, oInputModel.getProperty("/claim_header/attachment_email_approver"));
			}
			else if (oLevel == 'child') {
				// get child attachment
				oInputModel = this.getView().getModel("claimitem_input");
				var iAttachmentId = this._determineAttachmentId(oInputModel.getProperty("/claim_item/attachment_file_" + iFieldNumber));
				Attachment.onViewDocument(this, iAttachmentId);
			}
			else if (oLevel == 'child_t') {
				// get child attachment from claim table
				var iAttachmentId = this._determineAttachmentId(oEvent.getSource().getText());
				Attachment.onViewDocument(this, iAttachmentId);
			}
			BusyIndicator.hide();
		},

		_determineAttachmentId: function (sAttachment) {
			if (sAttachment.indexOf(' ') > 0) {
				return sAttachment.substring(0, sAttachment.indexOf(' '));
			}
			else {
				// for attachments with no filename in db
				return sAttachment;
			}
		},

		onCreateClaim_ClaimSummary: async function (indexNumber) {
			// check if header currently in edit mode, if yes show warning to save first
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_create"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			// Destroy previous detail fragment to avoid stale bindings
			if (this._oClaimFragments["claimsubmission_claimdetails_input"]) {
				const oFrag = await this._oClaimFragments["claimsubmission_claimdetails_input"];
				oFrag.destroy(true);
				delete this._oClaimFragments["claimsubmission_claimdetails_input"];
			}

			BusyIndicator.show(0);
			// show claim details screen
			var oPage = this.byId("page_claimsubmission");
			var oClaimItemFragment = await this._getFormFragment("claimsubmission_summary_claimitem");
			if (oClaimItemFragment) {
				oPage.removeContent(oClaimItemFragment);
			}

			if (await this._getFormFragment("approval_log")) {
				this._setApprovalLog(false);
			}
			const oCreate = await this._getFormFragment("claimsubmission_claimdetails_input", true);
			await this._replaceContentAt(oPage, 2, oCreate);
			// set new claim submission model;
			if (Number.isInteger(indexNumber)) {
				this._onInit_ClaimDetails_Input(indexNumber);
			}
			else {
				this._onInit_ClaimDetails_Input();

				// Reset Ceramah rollback values
				this._sPreviousEndTime = null;
				this._iPreviousAmount = 0;

				// initialize new item values
				var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
				var oInputModel = this.getView().getModel("claimitem_input");

				oInputModel.setProperty("/is_new", true);
				oInputModel.setProperty("/claim_item/is_new", true);
				//// get claim type from claim header
				oInputModel.setProperty("/claim_item/claim_type_id", oClaimSubmissionModel.getProperty("/claim_header/claim_type_id"));

				//get internal order by project code
				var sProjectCode = oClaimSubmissionModel.getProperty("/claim_header/project_code");
				var sInternalOrder = await Utility.getInternalOrderByProjectCode(this.getOwnerComponent().getModel(),sProjectCode);
				oInputModel.setProperty("/claim_item/internal_order", sInternalOrder);

				//// get GL account
				const oModel = this.getOwnerComponent().getModel();

				var glAccount;

				if (sProjectCode) {
					glAccount = await Utility.getGLAccountByProjectCode(
						oModel,
						sProjectCode
					);
				} else {
					glAccount = await this._getGLAccount(
						oModel,
						oInputModel.getProperty("/claim_item/claim_type_id")
					);
				}

				oInputModel.setProperty("/claim_item/gl_account", glAccount);
				//// get cost center
				var itemCc = oClaimSubmissionModel.getProperty("/claim_header/alternate_cost_center") || oClaimSubmissionModel.getProperty("/claim_header/cost_center") || null;
				oInputModel.setProperty("/claim_item/cost_center", itemCc);
				//// get descriptions
				oInputModel.setProperty("/claim_item/descr/claim_type_id", oClaimSubmissionModel.getProperty("/claim_header/descr/claim_type_id"));
			}
			BusyIndicator.hide(0);
		},

		onAction_ClaimSummary: function (oAction) {
			// count items in table
			var table = this.getView().byId("table_claimsummary_claimitem");
			if (table) {
				// dont proceed if no items selected
				if (table.getSelectedItems().length == 0) {
					MessageBox.error(Utility.getText("msg_claimsummary_noitem"));
					return;
				}

				// get action
				switch (oAction) {
					//// Edit
					case 'Edit':
						// only allow one item selection
						if (table.getSelectedItems().length > 1) {
							MessageBox.error(Utility.getText("msg_claimsummary_singleitem"));
							return;
						}
						else {
							this.onEdit_ClaimSummary(table.getSelectedItem());
						}
						break;
					//// Duplicate
					case 'Duplicate':
						// only allow one item selection
						if (table.getSelectedItems().length > 1) {
							MessageBox.error(Utility.getText("msg_claimsummary_singleitem"));
							return;
						}
						else {
							// confirm dialog
							this._newDialog(
								Utility.getText("dialog_claimsummary_duplicate"),
								Utility.getText("label_claimsummary_duplicate"),
								async function () {
									await this.onDuplicate_ClaimSummary(table.getSelectedItem());
									table.removeSelections(true);
								}.bind(this)
							);
						}
						break;
					//// Delete
					case 'Delete':
						// confirm dialog
						this._newDialog(
							Utility.getText("dialog_claimsummary_delete"),
							Utility.getText("label_claimsummary_delete"),
							async function () {
								await this.onDelete_ClaimSummary(table.getSelectedItems());
								table.removeSelections(true);
							}.bind(this)
						);
						break;
					default:
						MessageBox.error(Utility.getText("msg_claimsummary_noaction"));
						break;
				}
			}
			else {
				MessageBox.error(Utility.getText("msg_claimsummary_notable"));
			}
		},

		//Check duplication
		onSelectionChange_ClaimSummary: function () {
			var oTable = this.byId("table_claimsummary_claimitem");
			var aSelected = oTable.getSelectedItems();

			// Enable Duplicate only when exactly 1 item selected
			this.byId("button_claimsummary_duplicate").setEnabled(aSelected.length === 1);

			// Enable Edit only when exactly 1 item selected
			this.byId("button_claimsummary_edit").setEnabled(aSelected.length === 1);

		},

		onEdit_ClaimSummary: function (oItem) {
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_edit"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			var itemSubId;
			var oInputModel = this.getView().getModel("claimsubmission_input");
			// get value from selected item
			itemSubId = oItem.getCells()[0].getText();
			let iItemIndex = oInputModel.getProperty("/claim_items").findIndex((claim_item) => claim_item.claim_sub_id === itemSubId);
			if (iItemIndex !== -1) {
				this.onCreateClaim_ClaimSummary(iItemIndex);
			}
		},

		onItemPress_ClaimSubmission: function (oEvent) {
			var oInputModel = this.getView().getModel("claimsubmission_input");
			if (!oInputModel.getProperty("/view_only")) {
				return;
			}

			var table = this.getView().byId("table_claimsummary_claimitem");
			var item = table.getSelectedItem();

			// get value from selected items
			var itemSubId;
			itemSubId = item.getCells()[0].getText();
			let iItemIndex = oInputModel.getProperty("/claim_items").findIndex((claim_item) => claim_item.claim_sub_id === itemSubId);
			if (iItemIndex !== -1) {
				this.onCreateClaim_ClaimSummary(iItemIndex);
			}
		},

		onDuplicate_ClaimSummary: async function (oItem) {
			var itemSubId;
			var oInputModel = this.getView().getModel("claimsubmission_input");
			var tempItems = {
				claim_items: oInputModel.getProperty("/claim_items"),
				total_claim_amount: oInputModel.getProperty("/claim_header/total_claim_amount")
			};
			// get value from selected item
			itemSubId = oItem.getCells()[0].getText();
			let iItemIndex = oInputModel.getProperty("/claim_items").findIndex((claim_item) => claim_item.claim_sub_id === itemSubId);
			if (iItemIndex !== -1) {
				var oObject = oInputModel.getProperty("/claim_items/" + iItemIndex);
				//Checker for MATAWANG
				if (oObject.claim_type_item_id === this._oConstant.ClaimTypeItem.MATAWANG) {
					MessageToast.show(Utility.getText("msg_matawang_duplicated"));
					BusyIndicator.hide();
					return;
				}
				oInputModel.setProperty("/claim_items", oInputModel.getProperty("/claim_items").concat(structuredClone(oObject)));
				var addrIndex = "/claim_items/" + (oInputModel.getProperty("/claim_items").length - 1);
				oInputModel.setProperty(
					addrIndex + "/claim_sub_id",
					(oInputModel.getProperty("/claim_items/" + (oInputModel.getProperty("/claim_items").length - 1) + "/claim_id") ?? "") + ('' + '00' + (oInputModel.getProperty("/claim_items").length)).slice(-3)
				);
				oInputModel.setProperty("/claim_items_count", oInputModel.getProperty("/claim_items").length);

				// calculate new total
				const nTotal = oInputModel.getProperty("/claim_items")
					.filter((it) => !it.charged_to_ccc)
					.reduce((s, it) => s + (Number(it.amount) || 0), 0);
				oInputModel.setProperty("/claim_header/total_claim_amount", nTotal);
			}
			oInputModel.setProperty(addrIndex + "/is_new", true);
			// refresh table
			this.byId("table_claimsummary_claimitem").getBinding("items").refresh();
			BusyIndicator.hide();
		},

		
		onDelete_ClaimSummary: async function (aItems) {
			var itemSubId;
			var oInputModel = this.getView().getModel("claimsubmission_input");
			var oInputClaimModel = this.getView().getModel("claimitem_input");
			var tempItems = {
				claim_items: oInputModel.getProperty("/claim_items"),
				total_claim_amount: oInputModel.getProperty("/claim_header/total_claim_amount")
			};
			// get value from selected items
			jQuery.each(aItems,
				function (id, value) {
					itemSubId = value.getCells()[0].getText();
					let iItemIndex = oInputModel.getProperty("/claim_items").findIndex((claim_item) => claim_item.claim_sub_id === itemSubId);
					if (iItemIndex !== -1) {
						if (oInputModel.getProperty("/claim_items").length > 1) {
							oInputModel.getProperty("/claim_items").splice(iItemIndex, 1);
							oInputModel.setProperty("/claim_items_count", oInputModel.getProperty("/claim_items").length);
						}
						else {
							oInputModel.setProperty("/claim_items", []);
						}
					}
				}
			);
			// update claim sub item number
			oInputModel.getProperty("/claim_items").forEach(function (claim_item, i) {
				oInputModel.setProperty(
					"/claim_items/" + i + "/claim_sub_id",
					(oInputModel.getProperty("/claim_items/" + i + "/claim_id") ?? "") + ('' + '00' + (i + 1)).slice(-3)
				);
			});
		
			///Check to recalculate Mata Wang if it is required
			await this._recalculateMatawangIfNeeded(oInputModel, oInputClaimModel, this._updateClaimItems.bind(this));
			// update to database
			var updateSuccess = await this._updateClaimItems();
			if (!updateSuccess) {
				// recover previous claim item list
				oInputModel.setProperty("/claim_items", tempItems.claim_items);
				oInputModel.setProperty("/claim_items_count", tempItems.claim_items.length);
				oInputModel.setProperty("/claim_header/total_claim_amount", tempItems.total_claim_amount);
			}	
			// recalculate total_claim_amount / final_amount_to_receive
			await this._calculateClaimTotal();
			this._calculateCardAdvanceAmount();
		
			// refresh table
			this.byId("table_claimsummary_claimitem").getBinding("items").refresh();
		},

		onAction_ClaimSubmission_Toolbar: async function (oAction) {
			// get action
			switch (oAction) {
				//// Save Draft
				case this._oConstant.Claim_Action.DRAFT:
					const oEditButtonModelDraft = this.getView().getModel("editButtonModel");
					if (oEditButtonModelDraft && oEditButtonModelDraft.getProperty("/state") === true) {
						return MessageBox.error(Utility.getText("msg_error_unsaved_header_text"), {
							title: Utility.getText("msg_error_unsaved_header_title")
						});
					}
					// confirm dialog
					this._newDialog(
						Utility.getText("dialog_claimsubmission_savedraft"),
						Utility.getText("label_claimsubmission_savedraft"),
						function () {
							this._updateClaimSubmission(oAction);
						}.bind(this)
					);
					break;
				//// Delete Report
				case this._oConstant.Claim_Action.DELETE:
					// confirm dialog
					this._newDialog(
						Utility.getText("dialog_claimsubmission_deletereport"),
						Utility.getText("label_claimsubmission_deletereport"),
						function () {
							this._updateClaimSubmission(oAction);
						}.bind(this)
					);
					break;
				//// Submit Report
				case this._oConstant.Claim_Action.SUBMIT:
					const oEditButtonModel = this.getView().getModel("editButtonModel");
					if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
						return MessageBox.error(Utility.getText("msg_error_unsaved_header_submit"), {
							title: Utility.getText("msg_error_unsaved_header_title")
						});
					}
					this._pendingAction = oAction;

					var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
					if (oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") === this._oConstant.ClaimType.ELAUN_TUKAR &&
						await EligibilityCheck.checkClaimTypeEligibility(this._oModel, this._oConstant.ClaimType.ELAUN_TUKAR, true) === this._oConstant.ElaunTukarStatus.NOT_ALLOWED) {
						MessageBox.error(Utility.getText("req_d_e_not_eligible_for_elaun_tukar"));
						return;
					}

					if (!this._oDeclarationDialog) {
						Fragment.load({
							name: "claima.fragment.declarationdialog",
							id: "declarationDialogFrag",
							controller: this
						}).then(function (oDeclareDialog) {

							this._oDeclarationDialog = oDeclareDialog;
							this.getView().addDependent(oDeclareDialog);

							var oText = Fragment.byId("declarationDialogFrag", "declarationText");
							oText.setText(Utility.getText("msg_claimsubmission_declaration"));

							oDeclareDialog.open();

						}.bind(this));

					} else {

						var oText = Fragment.byId("declarationDialogFrag", "declarationText");
						oText.setText(Utility.getText("msg_claimsubmission_declaration"));

						this._oDeclarationDialog.open();
					}
					break;
				//// Back
				case this._oConstant.Claim_Action.BACK:
					var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
					this.onBack_ClaimSubmission();
					break;
				//// Reject
				case this._oConstant.Claim_Action.REJECT: {

					// Ensure form model
					let oReject = this.getView().getModel("Reject");
					if (!oReject) {
						oReject = new JSONModel({ rejectReasonKey: "", approvalComment: "" });
						this.getView().setModel(oReject, "Reject");
					} else {
						oReject.setProperty("/rejectReasonKey", "");
						oReject.setProperty("/approvalComment", "");
					}

					// Ensure UI state model (Claim)
					let oType = this.getView().getModel("Type");
					if (!oType) {
						oType = new JSONModel({ mode: "" });
						this.getView().setModel(oType, "Type");
					}
					oType.setProperty("/mode", "REJECT_CLAIM");

					try {
						RejectDialog.open(this);
					} catch (e) {
						MessageBox.error(
							Utility.getText("msg_claim_rejectdialog_fail", [(e?.message || e)])
						);
					}
					break;
				}

				//// Push Back
				case this._oConstant.Claim_Action.PUSHBACK:

					{
						// 1) Ensure Reject model (form data: reason + comment)
						let oReject = this.getView().getModel("Reject");
						if (!oReject) {
							oReject = new JSONModel({
								sendBackReasonKey: "",
								approvalComment: ""
							});
							this.getView().setModel(oReject, "Reject");
						} else {
							// clear previous values each time you open
							oReject.setProperty("/sendBackReasonKey", "");
							oReject.setProperty("/approvalComment", "");
						}

						// 2) Ensure Type model (UI state: dialog mode)
						let oType = this.getView().getModel("Type");
						if (!oType) {
							oType = new JSONModel({ mode: "" });
							this.getView().setModel(oType, "Type");
						}
						oType.setProperty("/mode", "SENDBACK_CLAIM");  // <<< IMPORTANT

						// 3) Open SendBackDialog (not ApproveDialog)
						try {
							SendBackDialog.open(this);
						} catch (e) {

							MessageBox.error(
								Utility.getText("msg_claim_pushbackdialog_fail", [(e?.message || e)])
							);
						}
					}
					break;

				//// Approve


				case this._oConstant.Claim_Action.APPROVE: {

					let oReject = this.getView().getModel("Reject");
					if (!oReject) {
						oReject = new JSONModel({ approvalComment: "" });
						this.getView().setModel(oReject, "Reject");
					}
					oReject.setProperty("/approvalComment", "");

					let oType = this.getView().getModel("Type");
					if (!oType) {
						oType = new JSONModel({ mode: "" });
						this.getView().setModel(oType, "Type");
					}
					oType.setProperty("/mode", this._oConstant.ApprovalProcess.CLAIM_APPROVE);

					var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
					if (oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") === this._oConstant.ClaimTypeItem.GALAKAN) {

						if (!this._oDisclaimerGalakanDialog) {

							Fragment.load({
								name: "claima.fragment.disclaimergalakan",
								id: "disclaimergalakanDialogFrag",
								controller: this
							}).then(function (oDisclaimerGalakanDialog) {
								this._oDisclaimerGalakanDialog = oDisclaimerGalakanDialog;

								this.getView().addDependent(this._oDisclaimerGalakanDialog);
							}.bind(this));
						}
						this._oDisclaimerGalakanDialog.open();
						return;
					}
					ApproveDialog.open(this);
				}
					break;


			}
		},

		onSaveHeaderPress: async function () {
			Common.init(this.getOwnerComponent(), this.getView());
			await Common.saveHeader(Constants.SubmissionTypePrefix.CLAIMHEADER);
		},

		/**
		 * Function for Edit button press
		 * 1. Swaps button state
		 * 2. Display fragment based on toggle
		 * 3. Enable or disable header fields to be editable
		 */
		onEditHeaderPress: async function () {
			Common.init(this.getOwnerComponent(), this.getView());
			///For Elaun Pertukaran - Need the Req No of Days based on Mode of Transfer when Edit button is pressed
			
			var oInputModel = this.getView().getModel("claimsubmission_input");

			// Guard against editing when the claim is view-only for this user
			// (e.g. an approver viewing a claim they just sent back — only the
			// claim owner may edit the header while it's in Send Back status).
			if (oInputModel.getProperty("/view_only")) {
				return;
			}

			if (oInputModel.getProperty("/claim_header/claim_type_id") === this._oConstant.ClaimType.ELAUN_TUKAR) {
				var iMaxDays = await Utility.getModeofTransferMaxDays(oInputModel.getProperty("/claim_header/mode_of_transfer_id"));
				if (!!iMaxDays) {
					oInputModel.setProperty("/claim_header/req_no_of_days", iMaxDays);
				}
			}
			await Common.editHeaderChange(Constants.SubmissionTypePrefix.CLAIMHEADER, !this.getView().getModel("editButtonModel").getProperty("/state"));
		},

		onDownloadExcelReport: async function () {
			// get header data
			const oHeader = this.getView().getModel("claimsubmission_input").getProperty("/claim_header");
			const oHeaderRow = {
				"Claim ID": oHeader.claim_id || "",
				"Purpose": oHeader.purpose || "",
				"Trip Start Date": oHeader.trip_start_date,
				"Trip End Date": oHeader.trip_end_date,
				"Event Start Date": oHeader.event_start_date,
				"Event End Date": oHeader.event_end_date,
				"Pre-Approval Request": oHeader.request_id + oHeader.descr.request_id,
				"Location": oHeader.location || "",
				"Comment": oHeader.comment || "",
				"Cost Center": oHeader.cost_center || "",
				"Alternate Cost Center": oHeader.alternate_cost_center || "",
				"Total Claim Amount": oHeader.total_claim_amount,
				"Pre-Approved Amount": oHeader.preapproved_amount,
				"Cash Advance": oHeader.cash_advance_amount,
				"Final Amount To Receive": oHeader.final_amount_to_receive
			};
			const aHeaderColumns = [
				{ label: "Claim ID", property: "Claim ID", width: 18 },
				{ label: "Purpose", property: "Purpose", width: 30 },
				{ label: "Trip Start Date", property: "Trip Start Date", width: 18 },
				{ label: "Trip End Date", property: "Trip End Date", width: 18 },
				{ label: "Event Start Date", property: "Event Start Date", width: 18 },
				{ label: "Event End Date", property: "Event End Date", width: 18 },
				{ label: "Pre-Approval Request", property: "Pre-Approval Request", width: 50 },
				{ label: "Location", property: "Location", width: 20 },
				{ label: "Comment", property: "Comment", width: 30 },
				{ label: "Cost Center", property: "Cost Center", width: 18 },
				{ label: "Alternate Cost Center", property: "Alternate Cost Center", width: 20 },
				{ label: "Total Claim Amount", property: "Total Claim Amount", type: "number", scale: 2, width: 18 },
				{ label: "Pre-Approved Amount", property: "Pre-Approved Amount", type: "number", scale: 2, width: 18 },
				{ label: "Cash Advance", property: "Cash Advance", type: "number", scale: 2, width: 18 },
				{ label: "Final Amount To Receive", property: "Final Amount To Receive", type: "number", scale: 2, width: 18 }
			];

			// get item data
			const aItems = this.getView().getModel("claimsubmission_input").getProperty("/claim_items");
			const aItemsColumnsMain = [
				{ label: Utility.getText("label_claimdetails_input_claim_id"), property: "claim_id", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_claim_sub_id"), property: "claim_sub_id", width: 20 },
				{ label: Utility.getText("label_claimdetails_input_claimtype"), property: "claim_type_id", type: "descr", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_claimitem"), property: "claim_type_item_id", type: "descr", width: 30 },
			];
			const aItemsColumnsAdditional = [
				{ label: Utility.getText("label_claimdetails_input_depedent_or_anggota"), property: "dependent_type", field: "select_claimdetails_input_depedent_or_anggota", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_anggota"), property: "anggota_name", field: "field_claimdetails_input_anggota_name", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_dependent"), property: "dependent_name", field: "select_claimdetails_input_dependent_name", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_dependent_combo"), property: "dependent", field: "combo_claimdetails_input_dependent", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_profbodytype"), property: "type_of_professional_body", field: "select_claimdetails_input_type_of_professional_body", type: "descr", width: 40 },
				{ label: Utility.getText("label_claimdetails_input_policyno"), property: "policy_number", field: "input_claimdetails_input_policy_number", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_funeraltransport"), property: "funeral_transportation", field: "select_claimdetails_input_funeral_transportation", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_amount_actual"), property: "actual_amount", field: "input_claimdetails_input_actual_amount", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_amount_subsidised"), property: "subsidised_amount", field: "input_claimdetails_input_subsidised_amount", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_amount_reqapproved"), property: "request_approval_amount", field: "input_claimdetails_input_request_approval_amount", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_amount"), property: "amount", field: "input_claimdetails_input_amount", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_compensation"), property: "percentage_compensation", field: "input_claimdetails_input_percentage_compensation", type: "number", scale: 2, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_coursetitle"), property: "course_title", field: "input_claimdetails_input_course_title", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_levelstudies"), property: "study_levels_id", field: "select_claimdetails_input_study_levels_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_receiptno"), property: "receipt_number", field: "input_claimdetails_input_receipt_number", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_receiptdate"), property: "receipt_date", field: "datepicker_claimdetails_input_receipt_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_purpose"), property: "purpose", field: "input_claimdetails_input_purpose", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_startdate"), property: "start_date", field: "datepicker_claimdetails_input_startdate", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_starttime"), property: "start_time", field: "timepicker_claimdetails_input_starttime", type: "time", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_enddate"), property: "end_date", field: "datepicker_claimdetails_input_enddate", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_endtime"), property: "end_time", field: "timepicker_claimdetails_input_endtime", type: "time", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_insurance_provider_id"), property: "insurance_provider_id", field: "select_claimdetails_input_insurance_provider_id", type: "descr", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_insurance_provider_name"), property: "insurance_provider_name", field: "input_claimdetails_input_insurance_provider_name", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_insurance_package_id"), property: "insurance_package_id", field: "select_claimdetails_input_insurance_package_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_insurance_purchase_date"), property: "insurance_purchase_date", field: "datepicker_claimdetails_input_insurance_purchase_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_insurance_cert_start_date"), property: "insurance_cert_start_date", field: "datepicker_claimdetails_input_insurance_cert_start_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_insurance_cert_end_date"), property: "insurance_cert_end_date", field: "datepicker_claimdetails_input_insurance_cert_end_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_mode_of_transfer"), property: "mode_of_transfer", field: "select_claiminput_mode_of_transfer", type: "descr", width: 18 },
				{ label: Utility.getText("label_claiminput_travel_alone_family"), property: "travel_alone_family", field: "select_claiminput_travel_alone_family", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_transfer_date"), property: "transfer_date", field: "datepicker_claimdetails_input_transfer_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_numberofdays"), property: "no_of_days", field: "input_claimdetails_input_no_of_days", type: "number", scale: 0, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_typeofvehicle"), property: "vehicle_type", field: "select_claimdetails_input_vehicle_type", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_number_of_travellers"), property: "number_of_travellers", field: "input_claimdetails_input_number_of_travellers", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_vehicleownership"), property: "vehicle_ownership_id", field: "select_claimdetails_input_vehicle_ownership_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_km_rate"), property: "rate_per_km", field: "input_claimdetails_input_rate_per_km", width: 14 },
				{ label: Utility.getText("label_claimdetails_input_faretype"), property: "fare_type_id", field: "select_claimdetails_input_fare_type_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_vehicleclass"), property: "vehicle_class_id", field: "select_claimdetails_input_vehicle_class_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_flightclass"), property: "flight_class", field: "select_claimdetails_input_flight_class", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_toll"), property: "toll", field: "input_claimdetails_input_toll", type: "number", scale: 2, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_parking"), property: "parking", field: "checkbox_claimdetails_input_parking", width: 10 },
				{ label: Utility.getText("label_claimdetails_input_locationtype"), property: "location_type", field: "select_claimdetails_input_location_type", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_state_from"), property: "from_state_id", field: "select_claimdetails_input_from_state_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_location_from"), property: "from_location", field: "input_claimdetails_input_from_location", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_location_from_office"), property: "from_location_office", field: "select_claimdetails_input_from_location", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_state_to"), property: "to_state_id", field: "select_claimdetails_input_to_state_id", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_location_to"), property: "to_location", field: "input_claimdetails_input_to_location", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_location_to_office"), property: "to_location_office", field: "select_claimdetails_input_to_location", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_km"), property: "km", field: "input_claimdetails_input_km", type: "number", scale: 2, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_roomtype"), property: "room_type", field: "select_claimdetails_input_room_type", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_country"), property: "country", field: "select_claimdetails_input_country", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_location"), property: "location", field: "input_claimdetails_input_location", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_needforeigncurrency"), property: "need_foreign_currency", field: "checkbox_claimdetails_input_needforeigncurrency", width: 10 },
				{ label: Utility.getText("label_claimdetails_input_currencycode"), property: "currency_code", field: "select_claimdetails_input_currency_code", width: 10 },
				{ label: Utility.getText("label_claimdetails_input_currencyrate"), property: "currency_rate", field: "input_claimdetails_input_currency_rate", type: "number", scale: 2, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_currencyamt"), property: "currency_amount", field: "input_claimdetails_input_currency_amount", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_trip_startdate"), property: "trip_start_date", field: "datepicker_claimdetails_input_trip_start_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_trip_starttime"), property: "trip_start_time", field: "timepicker_claimdetails_input_trip_starttime", type: "time", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_time_depart"), property: "departure_time", field: "timepicker_claimdetails_input_departure_time", type: "time", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_trip_enddate"), property: "trip_end_date", field: "datepicker_claimdetails_input_trip_end_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_trip_endtime"), property: "trip_end_time", field: "timepicker_claimdetails_input_trip_endtime", type: "time", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_time_arrive"), property: "arrival_time", field: "timepicker_claimdetails_input_arrival_time", type: "time", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_travel_duration_day"), property: "travel_duration_day", field: "input_claimdetails_input_travel_duration_day", type: "number", scale: 1, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_travel_duration_hour"), property: "travel_duration_hour", field: "input_claimdetails_input_travel_duration_hour", type: "number", scale: 1, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_provided_breakfast"), property: "provided_breakfast", field: "input_claimdetails_input_provided_breakfast", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_provided_lunch"), property: "provided_lunch", field: "input_claimdetails_input_provided_lunch", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_provided_dinner"), property: "provided_dinner", field: "input_claimdetails_input_provided_dinner", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_entitled_breakfast"), property: "entitled_breakfast", field: "input_claimdetails_input_entitled_breakfast", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_entitled_lunch"), property: "entitled_lunch", field: "input_claimdetails_input_entitled_lunch", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_entitled_dinner"), property: "entitled_dinner", field: "input_claimdetails_input_entitled_dinner", type: "number", scale: 2, width: 14 },
				{ label: Utility.getText("label_claimdetails_input_lodging_address"), property: "lodging_address", field: "input_claimdetails_input_lodging_address", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_region"), property: "region", field: "select_claimdetails_input_region", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_area"), property: "area", field: "select_claimdetails_input_area", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_lodging_category"), property: "lodging_category", field: "select_claimdetails_input_lodging_category", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_familyno"), property: "no_of_family_member", field: "input_claimdetails_input_no_of_family_member", type: "number", scale: 2, width: 10 },
				{ label: Utility.getText("label_claimdetails_input_cat_purpose"), property: "claim_category", field: "select_claimdetails_input_claim_category", type: "descr", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_billno"), property: "bill_no", field: "input_claimdetails_input_bill_no", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_accountno"), property: "account_no", field: "input_claimdetails_input_account_no", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_billdate"), property: "bill_date", field: "datepicker_claimdetails_input_bill_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_phoneno"), property: "phone_no", field: "input_claimdetails_input_phone_no", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_disclaimer"), property: "disclaimer", field: "checkbox_claimdetails_input_disclaimer", width: 10 },
				{ label: Utility.getText("label_claimdetails_input_remarks"), property: "remark", field: "input_claimdetails_input_remarks", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_attachment_file_1"), property: "attachment_file_1", field: "fileuploader_claimdetails_input_attachment_file_1", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_attachment_file_2"), property: "attachment_file_2", field: "fileuploader_claimdetails_input_attachment_file_2", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_marriagecategory"), property: "marriage_category", field: "select_claimdetails__input_marriagecategory", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_actual_meter_cube"), property: "actual_meter_cube", field: "input_claimdetails_meter_cube_actual", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_entitled_meter_cube"), property: "entitled_meter_cube", field: "input_claimdetails_meter_cube", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_attachment_file_3"), property: "attachment_file_3", field: "fileuploader_claimdetails_input_attachment_file_3", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_attachment_file_4"), property: "attachment_file_4", field: "fileuploader_claimdetails_input_attachment_file_4", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_insurance_policy_start_date"), property: "policy_start_date", field: "datepicker_claimdetails_input_insurance_policy_start_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_insurance_policy_end_date"), property: "policy_end_date", field: "datepicker_claimdetails_input_insurance_policy_end_date", type: "date", width: 18 },
				{ label: Utility.getText("label_claimdetails_input_insurance_medical_provider_id"), property: "insurance_medical_provider_id", field: "select_claimdetails_input_insurance_medical_provider_id", type: "descr", width: 30 },
				{ label: Utility.getText("label_claimdetails_input_insurance_medical_provider_name"), property: "insurance_medical_provider_name", field: "input_claimdetails_input_insurance_medical_provider_name", width: 30 }

			];

			await ExcelExport.onDownloadExcelReport(this._oConstant.SubmissionTypePrefix.CLAIM,
				oHeader,
				oHeaderRow,
				aHeaderColumns,
				aItems,
				aItemsColumnsMain,
				aItemsColumnsAdditional
			);
		},

		onClickCancel_app: function () {
			// Close via the stored instance (ApproveDialog keeps it on controller as __approveDialog)
			if (this._approveDialog) {
				this._approveDialog.close();
			}
			if (this._sendBackDialog) { this._sendBackDialog.close(); }
			if (this._rejectDialog) { this._rejectDialog.close(); }
		},

		//Button config for Approve
		onClickCreate_app: async function () {

			if (this.bIsApproving) {
				return;
			}

			this.bIsApproving = true;

			try {
				const oReject = this.getView().getModel("Reject");
				const sMode = this.getView().getModel("Type")?.getProperty("/mode");
				const sComment = oReject?.getProperty("/approvalComment")?.trim();
				const sUserId = this._oSessionModel.getProperty("/userId");
				const oClaimModel = this.getView().getModel("claimsubmission_input");
				const sClaimId = oClaimModel?.getProperty("/claim_header/claim_id")?.trim();

				if (sMode !== this._oConstant.ApprovalProcess.CLAIM_APPROVE) {
					return;
				}

				try {

					BusyIndicator.show(0);

					const oModel = this.getOwnerComponent().getModel();
					// const oEmployeeViewModel = this.getOwnerComponent().getModel("employee_view");

					const oPayload = {
						Id				: sClaimId,
						UserId			: sUserId,
						ApproverAction	: this._oConstant.ClaimStatus.APPROVED,
						Comments		: sComment,
						RejectionReason : ""
					}
					
					console.log("Payload Send Back: ", oPayload);
					await workflowApproval.onProcessApproval(this._oWorkflowModel, oPayload);

					if (this._oApproveDialog) {
						this._oApproveDialog.close();
					}

					this._oRouter.navTo("MyApproval");

				} catch (oErrorMessage) {
					MessageBox.error(Utility.getText(oErrorMessage.sCode));
					setTimeout(() => {
						this._fnGoToDashboard();
					}, 400);
				} finally {
					BusyIndicator.hide();
				}

			} catch (oErrorApprove) {
				MessageBox.error(Utility.getText("msg_claimapprover_fail"));
				return;

			} finally {
				this.bIsApproving = false;
			}

		},

		//Button config for Reject
		onReject_ClaimSubmission: async function () {

			const oReject = this.getView().getModel("Reject");
			const sReason = oReject?.getProperty("/rejectReasonKey");
			const sComment = oReject?.getProperty("/approvalComment")?.trim();

			if (!sReason) {
				MessageBox.error(Utility.getText("msg_claimapprover_reject"));
				return;
			}

			if (!sComment) {
				MessageBox.error(Utility.getText("msg_claimapprover_comment"));
				return;
			}

			try {
				BusyIndicator.show(0);

				// const oModel = this.getOwnerComponent().getModel();
				// const oEmployeeViewModel = this.getOwnerComponent().getModel("employee_view");
				const sUserId = this._oSessionModel.getProperty("/userId");

				const oClaimModel = this.getView().getModel("claimsubmission_input");
				const sClaimId = oClaimModel?.getProperty("/claim_header/claim_id")?.trim();

				// const sRejectStatus = this._oConstant.ClaimStatus.REJECTED; // REJECT

				const oPayload = {
						Id				: sClaimId,
						UserId			: sUserId,
						ApproverAction	: this._oConstant.ClaimStatus.REJECTED,
						Comments		: sComment,
						RejectionReason : sReason
					}
				console.log("Payload Send Back: ", oPayload); 
				await workflowApproval.onProcessApproval(this._oWorkflowModel, oPayload);

				//MessageToast.show(sMessageKey);
				if (this._oRejectDialog) {
					this._oRejectDialog.close();
				}
				
				this._oRouter.navTo("MyApproval");
				
			} catch (oErrorReject) {
				MessageBox.error(Utility.getText(oErrorReject.sCode));
				setTimeout(() => {
					this._fnGoToDashboard();
				}, 400);
			} finally {
				BusyIndicator.hide();
			}
		},
		//Button config for Push Back
		onSendBack_ClaimSubmission: async function () {

			const oReject = this.getView().getModel("Reject");
			const sReason = oReject?.getProperty("/sendBackReasonKey");
			const sComment = oReject?.getProperty("/approvalComment")?.trim();

			if (!sReason) {
				MessageBox.error(Utility.getText("msg_claimapprover_pushback"));
				return;
			}

			if (!sComment) {
				MessageBox.error(Utility.getText("msg_claimapprover_comment"));
				return;
			}

			try {
				BusyIndicator.show(0);

				const oModel = this.getOwnerComponent().getModel();
				// const oEmployeeViewModel = this.getOwnerComponent().getModel("employee_view");
				const sUserId = this._oSessionModel.getProperty("/userId");

				const oClaimModel = this.getView().getModel("claimsubmission_input");
				const sClaimId = oClaimModel?.getProperty("/claim_header/claim_id")?.trim();

				const sSendBackStatus = this._oConstant.ClaimStatus.SEND_BACK;

				const oPayload = {
						Id				: sClaimId,
						UserId			: sUserId,
						ApproverAction	: this._oConstant.ClaimStatus.SEND_BACK,
						Comments		: sComment,
						RejectionReason : sReason
					}
				console.log("Payload Send Back: ", oPayload);
				await workflowApproval.onProcessApproval(this._oWorkflowModel, oPayload)

				//MessageToast.show(sMessageKey);
				if (this._oSendBackDialog) {
					this._oSendBackDialog.close();
				}
				
				this._oRouter.navTo("MyApproval");
				
			} catch (oErrorSendBack) {
				MessageBox.error(Utility.getText(oErrorSendBack.sCode));
				setTimeout(() => {
					this._fnGoToDashboard();
				}, 400);
			} finally {
				BusyIndicator.hide();
			}
		},


		_fnGoToDashboard: function () {
			const oRouter = this.getOwnerComponent().getRouter();
			this._clearExit = true;    // If you use this flag in your pattern
			oRouter.navTo("Dashboard", {}, true);
		},


		//End Approval



		// Example: wire this to your "Push Back" action
		onOpenSendBack_Claim: function () {
			// Ensure form model
			let oReject = this.getView().getModel("Reject");
			if (!oReject) {
				oReject = new JSONModel({ sendBackReasonKey: "", approvalComment: "" });
				this.getView().setModel(oReject, "Reject");
			}
			oReject.setProperty("/sendBackReasonKey", "");
			oReject.setProperty("/approvalComment", "");

			// Ensure UI state model
			let oType = this.getView().getModel("Type");
			if (!oType) {
				oType = new JSONModel({ mode: "" });
				this.getView().setModel(oType, "Type");
			}
			oType.setProperty("/mode", "SENDBACK_CLAIM");

			SendBackDialog.open(this);
		},


		_setEnabledToolbarFooter: function () {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			if (oClaimSubmissionModel && oClaimSubmissionModel.getProperty("/claim_items_count") && (Number.parseInt(oClaimSubmissionModel.getProperty("/claim_items_count")) > 0)) {
				//// Edit
				if (this.byId("button_claimsummary_edit").getVisible() && !this.byId("button_claimsummary_edit").getEnabled()) {
					this.byId("button_claimsummary_edit").setEnabled(true);
				}
				//// Duplicate
				if (this.byId("button_claimsummary_duplicate").getVisible() && !this.byId("button_claimsummary_duplicate").getEnabled()) {
					this.byId("button_claimsummary_duplicate").setEnabled(true);
				}
				//// Delete
				if (this.byId("button_claimsummary_delete").getVisible() && !this.byId("button_claimsummary_delete").getEnabled()) {
					this.byId("button_claimsummary_delete").setEnabled(true);
				}
				//// Submit Report
				if (this.byId("button_claimsubmission_submitreport").getVisible() && !this.byId("button_claimsubmission_submitreport").getEnabled()) {
					// this.byId("button_claimsubmission_submitreport").setEnabled(true);
				}
			}
			else {
				//// Edit
				if (this.byId("button_claimsummary_edit").getVisible() && this.byId("button_claimsummary_edit").getEnabled()) {
					this.byId("button_claimsummary_edit").setEnabled(false);
				}
				//// Duplicate
				if (this.byId("button_claimsummary_duplicate").getVisible() && this.byId("button_claimsummary_duplicate").getEnabled()) {
					this.byId("button_claimsummary_duplicate").setEnabled(false);
				}
				//// Delete
				if (this.byId("button_claimsummary_delete").getVisible() && this.byId("button_claimsummary_delete").getEnabled()) {
					this.byId("button_claimsummary_delete").setEnabled(false);
				}
				//// Submit Report
				if (this.byId("button_claimsubmission_submitreport").getVisible() && this.byId("button_claimsubmission_submitreport").getEnabled()) {
					// this.byId("button_claimsubmission_submitreport").setEnabled(false);
				}
			}
		},

		_getGLAccount: async function (oModel, claim_type) {

			const oListBinding = oModel.bindList("/ZCLAIM_TYPE", null, null, [
				new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, claim_type)
			]);

			try {
				const aContexts = await oListBinding.requestContexts(0, 1);

				if (aContexts.length > 0) {
					const oData = aContexts[0].getObject();
					return oData.GL_ACCOUNT;
				} else {
					MessageBox.error(Utility.getText("msg_claimdetails_input_glaccount"));
					return "";
				}
			} catch (oError) {
				console.error("Error fetching Claim Type detail", oError);
			}

		},

		onSelect_ClaimDetails_ClaimItem: async function (oEvent) {
			// validate claim item
			var claimItem = oEvent.getParameters().selectedItem;
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			var oInputModel = this.getView().getModel("claimitem_input");
			var oPropertyModel = this.getView().getModel("claimitem_property");

			// reset existing input 
			await this._resetClaimItemInputs(oInputModel);

			if (claimItem) {
				// Reset Location Type
				oInputModel.setProperty("/claim_item/location_type", "");

				// get material code from claim item
				var materialCode = claimItem.data("MATERIAL_CODE");
				oInputModel.setProperty("/claim_item/material_code", materialCode);
			}

			// prevent processing if claim type item is empty
			if (!oInputModel.getProperty("/claim_item/claim_type_item_id")) {
				return;
			}

			// CCC holders creating a CASH_REPAY item: default/lock the CCC switch
			// based on whether a cash advance amount is available
			this._applyCashRepayCCCDefault(oInputModel, oClaimSubmissionModel);

			if (
				oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") === this._oConstant.ClaimType.MEDICAL_ADVANCE &&
				oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.CASH_REPAY &&
				oClaimSubmissionModel.getProperty("/claim_items").length === 0 &&
				!this._bSkipMedicalPolicyDialog
			) {
				this._oPendingClaimItem = claimItem;

				if (!this._oMedicalPolicyDialog) {

					Fragment.load({
						name: "claima.fragment.medicalpolicy",
						id: "medicalPolicyDialogFrag",
						controller: this
					}).then(function (oMedicalPolicyDialog) {

						this._oMedicalPolicyDialog = oMedicalPolicyDialog;

						this.getView().addDependent(this._oMedicalPolicyDialog);

						this._oMedicalPolicyDialog.open();

					}.bind(this));

				} else {

					this._oMedicalPolicyDialog.open();

				}

				return;
			}
			// set app visibility controls
			await this.getFieldVisibility_ClaimTypeItem();

			this._bSkipMedicalPolicyDialog = false;

			// When Location Type is visible but no selection yet, hide State and Location fields by default
			// If show, then State will be Select but Location will be input, which inconsistent from UI
			if (this.byId("select_claimdetails_input_location_type").getVisible()) {
				this.byId("select_claimdetails_input_from_state_id")?.setVisible(false);
				this.byId("select_claimdetails_input_from_location")?.setVisible(false);
				this.byId("input_claimdetails_input_from_location")?.setVisible(false);
				this.byId("select_claimdetails_input_to_state_id")?.setVisible(false);
				this.byId("select_claimdetails_input_to_location")?.setVisible(false);
				this.byId("input_claimdetails_input_to_location")?.setVisible(false);
			}

			// set claim detail selection values
			this._setClaimDetailSelectionMaster();

			//for tambang excluding flight
			this._filterFareType();
			
			//set disclaimer field as false if they are visible for validation
			if (this.byId("checkbox_claimdetails_input_disclaimer").getVisible()) {
				oInputModel.setProperty("/claim_item/disclaimer", false);
			}
			//START TDL #6.1 meter cube for Pengangkutan Laut
			const sKey = oInputModel.getProperty("/claim_item/claim_type_item_id");

			//Set Kilometer (KM) field as required only for DARAT and KILOMETER claim items.
			const bKmRequired = [
				this._oConstant.ClaimTypeItem.DARAT,
				this._oConstant.ClaimTypeItem.KILOMETER,	
				this._oConstant.ClaimTypeItem.KM			// ELAUN_PINDAH Kilometer Claim
			].includes(sKey);
			oPropertyModel.setProperty("/km/is_required", bKmRequired);

			switch (sKey) {
				case this._oConstant.ClaimTypeItem.FLIGHT_WIL:
					oPropertyModel.setProperty("/to_state_id/is_required", true);
					break;

				case this._oConstant.ClaimTypeItem.LAUT:
					//entitled meter cube
					oPropertyModel.setProperty("/meter_cube_entitled/is_editable", false);
					//actual meter cube
					oPropertyModel.setProperty("/meter_cube_actual/is_editable", true);

					oPropertyModel.setProperty("/actual_amount/is_editable", true);

					oPropertyModel.setProperty("/amount/is_editable", false);
					await ClaimUtility.fetchMeterCubeEntitlement(oInputModel);
					await ClaimUtility.fetchPengangkutanLautAmount(oInputModel);
					break;
				case this._oConstant.ClaimTypeItem.DARAT:
					if(oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW_DESC ||
						oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW){
						oPropertyModel.setProperty("/marriage_category/is_visible", true);
					}
					break;
			}
			//END TDL #6.1 meter cube for Pengangkutan Laut

			// calculate number of days
			if (oPropertyModel.getProperty("/no_of_days/is_visible")) {
				oInputModel.setProperty("/claim_item/no_of_days", DateUtility.calculateNumberOfDays(this._oConstant.SubmissionTypePrefix.CLAIM, oClaimSubmissionModel.getProperty("/claim_header"), oInputModel.getProperty("/claim_item")));
				this.onChange_ClaimDetails_NumberOfDays();
			}

			// set percentage (%) compensation based on claim item
			if (oPropertyModel.getProperty("/percentage_compensation/is_visible")) {
				await ClaimUtility.setClaimItemDefaultValues(oClaimSubmissionModel, oInputModel, "percentage_compensation", this._oConstant.EligibilityRule.SUBSIDISED_RATE, 0.0);
			}

			if(oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") == this._oConstant.ClaimType.ELAUN_TUKAR){
				if(oClaimSubmissionModel.getProperty("/claim_header/travel_alone_family") == this._oConstant.TravelAloneOrWithFamily.ALONE_DESC ||
					oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.LATER_DESC	|| 
					oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.ALONE	|| 
					oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.LATER
				){
					oPropertyModel.setProperty("/no_of_family_member/is_visible", false)
				}
			}

			// set number of family members based on claim item
			if (oPropertyModel.getProperty("/no_of_family_member/is_visible")) {
				var iDependent;
				iDependent = await Utility.getNumberOfFamilyMembers(sKey);
				oInputModel.setProperty("/claim_item/no_of_family_member", iDependent);
				if( ((oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW_DESC) || 
					  oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW)
					&& oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") == this._oConstant.ClaimType.ELAUN_TUKAR
					&& (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MKN_TUKAR || oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.LOD_TUKAR)){
					oPropertyModel.setProperty("/number_of_traveller/is_visible", true);
					oPropertyModel.setProperty("/number_of_traveller/is_required", true);
				}
			}

			// if claim type item is lodging, retrieve eligible amount
			if(oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItemLodging.LODG_O){
				oInputModel.setProperty("/claim_item/eligible_amount", 0);
			}else{
				if (Object.values(this._oConstant.ClaimTypeItemLodging).includes(oInputModel.getProperty("/claim_item/claim_type_item_id"))) {
					oInputModel.setProperty("/claim_item/eligible_amount", await ClaimUtility.fetchUserAmountLodging());
				}
			}
			

			// if claim type item is elaun pengangkutan, populate approved amount with eligible value
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.E_PENGAKUT) {
				var dEligibleAmount = await ClaimUtility.fetchUserAmountElaunPengangkutan();
				// populate item values
				if (dEligibleAmount === null) return;
				else oInputModel.setProperty("/claim_item/amount", dEligibleAmount);
			}

			if (this.byId("input_claimdetails_input_provided_breakfast").getVisible()) {
				this._resetPerDiem();
			}
			//Added for matawang
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MATAWANG) {
				await ClaimUtility.calculateMatawangAmount();
			}
		},

		_onInit_ClaimDetails_Input: async function (indexNumber) {

			// HARD RESET – prevents stale binding values
			this.getView().setModel(null, "claimitem_input");
			sap.ui.getCore().applyChanges();

			// set claim item model
			var oInputModel = this._getNewClaimItemModel("claimitem_input");
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");

			// set claim item property model
			var oClaimItemProperties = {
				actual_amount: { is_visible: false },
				amount: { is_visible: false },
				percentage_compensation: { is_visible: false },
				start_date: { is_visible: false },
				end_date: { is_visible: false },
				no_of_days: { is_visible: false },
				vehicle_type: { is_visible: false },
				km: { is_visible: false },
				rate_per_km: { is_visible: false },
				toll: { is_visible: false },
				entitled_breakfast: { is_visible: false },
				no_of_family_member: { is_visible: false },
				insurance_provider_id: { is_visible: false },
				insurance_provider_name: { is_visible: false },
				insurance_package_id: { is_visible: false },
				insurance_purchase_date: { is_visible: false },
				insurance_cert_start_date: { is_visible: false },
				insurance_cert_end_date: { is_visible: false },
				meter_cube_entitled: { is_visible: false },
				meter_cube_actual: { is_visible: false, is_editable: true },
				marriage_category: { is_visible: false },
				to_state_id: { is_required: false },
				bill_no: { is_required: false },
				account_no: { is_required: false },
				number_of_traveller: { is_required: false, is_visible: false },
				combo_dependent: { is_editable: true },
				to_location: { is_visible: false },
				from_location: { is_visible: false },
				marriage_category: { is_visible: false },
				charged_to_ccc: { is_editable: true },
				insurance_medical_provider_id: { is_visible: false },
				insurance_medical_provider_name: { is_visible: false },
				policy_start_date: { is_visible: false },
				policy_end_date: { is_visible: false },
				previous_policy_number: { is_visible: false },
				current_policy_number: { is_visible: false },
				next_policy_number: { is_visible: false }
			};
			var oClaimItemPropertyModel = new JSONModel(oClaimItemProperties);
			//// set input
			this.getView().setModel(oClaimItemPropertyModel, "claimitem_property");

			this._refreshActionState("DETAILS");	// footer button control

			// update selection fields
			if (Number.isInteger(indexNumber)) {
				var oPropertyModel = this.getView().getModel("claimitem_property"); 
				// add claim item values to claim detail screen
				oInputModel.setProperty("/claim_item", structuredClone(oClaimSubmissionModel.getProperty("/claim_items/" + indexNumber)));

				// CCC holders editing a CASH_REPAY item: default/lock the CCC switch
				// based on whether a cash advance amount is available
				this._applyCashRepayCCCDefault(oInputModel, oClaimSubmissionModel);

				//refresh policy info 
				await this._refreshPolicyInfo();
				// set app visibility controls
				await this.getFieldVisibility_ClaimTypeItem();

				//FUT issue #58
				if (this.byId("checkbox_claimdetails_input_disclaimer").getVisible()) {
					oInputModel.setProperty("/claim_item/disclaimer", true)
				}
				//changes here
				if (!!oInputModel.getProperty("/claim_item/anggota_id")) {
					oInputModel.setProperty("/claim_item/dependent_type", this._oConstant.DependentType.ANGGOTA);
				} else if (!!oInputModel.getProperty("/claim_item/dependent_name")) {
					oInputModel.setProperty("/claim_item/dependent_type", this._oConstant.DependentType.DEPENDENT);
				}

				var sDependent = oInputModel.getProperty("/claim_item/dependent");
				if (sDependent) {
					oInputModel.setProperty("/claim_item/dependent", JSON.parse(sDependent));
				}

				if(oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") == this._oConstant.ClaimType.ELAUN_TUKAR){
					if(oClaimSubmissionModel.getProperty("/claim_header/travel_alone_family") == this._oConstant.TravelAloneOrWithFamily.ALONE_DESC ||
						oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.LATER_DESC	|| 
						oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.ALONE	|| 
						oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.LATER
					){
						oPropertyModel.setProperty("/no_of_family_member/is_visible", false)
					}
				}

				if( ((oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW_DESC) || 
					  oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW)
					&& oClaimSubmissionModel.getProperty("/claim_header/claim_type_id") == this._oConstant.ClaimType.ELAUN_TUKAR 
					&& (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MKN_TUKAR || oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.LOD_TUKAR)
						){
					oPropertyModel.setProperty("/number_of_traveller/is_visible", true);
					oPropertyModel.setProperty("/number_of_traveller/is_required", true);
				}

				if(oInputModel.getProperty("/claim_item/claim_type_item_id") == this._oConstant.ClaimTypeItem.DARAT){
					if(oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW_DESC || 
						oClaimSubmissionModel.getProperty("/claim_header/travel_family_now_later") == this._oConstant.TravelWithFamilyNowOrLater.NOW){
						oPropertyModel.setProperty("/marriage_category/is_visible", true);
					}
				}

				if(oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.DARAT){
				Utility.init(this.getOwnerComponent(), this.getView());
				var oResult = await Utility.determineDaratAmount(this._oConstant.SubmissionTypePrefix.CLAIM);
				if (oResult) {
					oInputModel.setProperty("/claim_item/descr/rate_per_km", oResult.fRate);
					if (!oInputModel.getProperty("/claim_item/km")){
						return;
					}
				}
			}

			}
			await this._setClaimDetailSelection(oClaimSubmissionModel);

			// approver view changes
			if (oClaimSubmissionModel.getProperty("/view_only")) {
				if (!this.byId("button_claimdetails_input_return").getVisible()) {
					this.byId("button_claimdetails_input_return").setVisible(true);
					oPropertyModel.setProperty("/combo_dependent/is_editable", false)
				}
				this._getFieldEditable_ClaimTypeItem();
			}

			//For Matawang
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MATAWANG) {
				await ClaimUtility.calculateMatawangAmount();
			}

			// set filters for state and location (office) if existing claim item uses KWSP Office
			if (oInputModel.getProperty("/claim_item/location_type") === this._oConstant.LocationType.KWSP) {
				Utility.init(this.getOwnerComponent(), this.getView());
				Utility.setFiltersExistingStateLocation(this._oConstant.SubmissionTypePrefix.CLAIM);
			}

			//for tambang excluding flight
			this._filterFareType();

			// if claim type item is lodging, retrieve eligible amount
			// if claim type item is lodging, retrieve eligible amount
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItemLodging.LODG_O) {
				oInputModel.setProperty("/claim_item/eligible_amount", 0);
			} else {
				if (Object.values(this._oConstant.ClaimTypeItemLodging).includes(oInputModel.getProperty("/claim_item/claim_type_item_id"))) {
					oInputModel.setProperty("/claim_item/eligible_amount", await ClaimUtility.fetchUserAmountLodging());
				}
			}
			//if round trip set to yes
			if (oInputModel.getProperty("/claim_item/round_trip")) {
				await this.onChange_ClaimDetails_Kilometer();
			}

			//for CCC personal expense
			await this._calculateClaimTotal();
			await this._calculateCardAdvanceAmount();
		},

		_setClaimDetailSelection: async function (oModel) {
			// filter by submission type
			var oFilterSubsmissionType;
			if (oModel.getProperty("/claim_header/submission_type") === this._oConstant.SubmissionType.PRE_APPROVE ||
				oModel.getProperty("/claim_header/submission_type") === this._oConstant.SubmissionType.CASH_REPAYMENT ||
				oModel.getProperty("/claim_header/submission_type") === this._oConstant.SubmissionType.CURR_SUBSIDY
			) {
				// filter items by claim header submission type + cash repayment
				oFilterSubsmissionType = new Filter({
					filters: [
						new Filter('SUBMISSION_TYPE', FilterOperator.EQ, this._oConstant.SubmissionType.PRE_APPROVE),
						new Filter('SUBMISSION_TYPE', FilterOperator.EQ, this._oConstant.SubmissionType.CASH_REPAYMENT),
						new Filter('SUBMISSION_TYPE', FilterOperator.EQ, this._oConstant.SubmissionType.CURR_SUBSIDY),
					],
					and: false
				});
			} else {
				oFilterSubsmissionType = new Filter('SUBMISSION_TYPE', FilterOperator.EQ, oModel.getProperty("/claim_header/submission_type"));
			}

			// 1. Define the base filters - CLAIM_TYPE_ITEM_ID exclusions are
			// handled separately below, in plain JavaScript, rather than as
			// OData filters (the dynamic filter/binding approach proved
			// unreliable for this specific dropdown).
			var aFilters = [
				new Filter('CLAIM_TYPE_ID', FilterOperator.EQ, oModel.getProperty("/claim_header/claim_type_id")),
				oFilterSubsmissionType,
				// ensure status is active
				new Filter("STATUS", FilterOperator.EQ, this._oConstant.ClaimTypeItemStatus.ACTIVE),
				new Filter("START_DATE", FilterOperator.LE, DateUtility.getHanaDate(DateUtility.today())),
				new Filter("END_DATE", FilterOperator.GE, DateUtility.getHanaDate(DateUtility.today()))
			];

			// 2. Determine which CLAIM_TYPE_ITEM_IDs to exclude.
			var aExcludedClaimTypeItemIds = [];

			var sCardNoForFilter = oModel.getProperty("/claim_header/card_no");
			var bIsTravelWithCard = !!sCardNoForFilter && !!this._oConstant.TravelClaimType[oModel.getProperty("/claim_header/claim_type_id")];

			// Using Number() or parseFloat() ensures the check works whether the model stores it as a string "0" or number 0
			var fCashAdvanceAmount = oModel.getProperty("/claim_header/cash_advance_amount");
			if (Number(fCashAdvanceAmount) === 0 && !bIsTravelWithCard) {
				aExcludedClaimTypeItemIds.push(this._oConstant.ClaimTypeItem.CASH_REPAY);
			}

			// POTONGAN_ELAUN and PERSONAL_EXPENSE are only shown to users
			// who have a corporate credit card assigned.
			var sCardNoForFilter = oModel.getProperty("/claim_header/card_no");
			if (!sCardNoForFilter) {
				aExcludedClaimTypeItemIds.push(this._oConstant.ClaimTypeItem.POTONGAN_ELAUN);
				aExcludedClaimTypeItemIds.push(this._oConstant.ClaimTypeItem.PERSONAL_EXP);
			}

			// 3. Fetch every matching row (base filters only), then remove
			// the excluded CLAIM_TYPE_ITEM_IDs in plain JavaScript, and
			// populate the Select control directly.
			var oClaimItemSelect = this.byId("select_claimdetails_input_claimitem");
			var oEmployeeModel = this.getView().getModel("employee");
			var oListBinding = oEmployeeModel.bindList("/ZCLAIM_TYPE_ITEM", null, null, aFilters, {
				$$ownRequest: true,
				$expand: {
					"ZSUBMISSION_TYPE": {
						$select: "SUBMISSION_TYPE_DESC"
					}
				},
				$select: "CLAIM_TYPE_ITEM_ID,CLAIM_TYPE_ITEM_DESC,SUBMISSION_TYPE,MATERIAL_CODE"
			});

			try {
				var aContexts = await oListBinding.requestContexts(0, Infinity);
				var aItems = aContexts
					.map(function (ctx) { return ctx.getObject(); })
					.filter(function (oRow) { return !aExcludedClaimTypeItemIds.includes(oRow.CLAIM_TYPE_ITEM_ID); })
					.sort(function (a, b) {
						if (a.CLAIM_TYPE_ITEM_DESC !== b.CLAIM_TYPE_ITEM_DESC) {
							return a.CLAIM_TYPE_ITEM_DESC < b.CLAIM_TYPE_ITEM_DESC ? -1 : 1;
						}
						return a.CLAIM_TYPE_ITEM_ID < b.CLAIM_TYPE_ITEM_ID ? -1 : 1;
					});

				oClaimItemSelect.unbindAggregation("items");
				oClaimItemSelect.removeAllItems();
				aItems.forEach(function (oRow) {
					var oItem = new Item({
						key: oRow.CLAIM_TYPE_ITEM_ID,
						text: oRow.CLAIM_TYPE_ITEM_DESC
					});
					oItem.data("MATERIAL_CODE", oRow.MATERIAL_CODE);
					oClaimItemSelect.addItem(oItem);
				});
			} catch (e) {
				console.error("Failed to load claim type items:", e);
			}

			// claim detail selection values
			this._setClaimDetailSelectionMaster();
		},

		_setClaimDetailSelectionMaster: function () {
			//// Type of Professional Body
			this._setClaimDetailSelectionField("select_claimdetails_input_type_of_professional_body", "ZPROFESIONAL_BODY");
			//// Funeral Transportation
			this._setClaimDetailSelectionField("select_claimdetails_input_funeral_transportation", "ZTRANSPORT_PASSING");
			//// Level of Studies
			this._setClaimDetailSelectionField("select_claimdetails_input_study_levels_id", "ZSTUDY_LEVELS");
			//// Nama Pembekal Insuran
			this._setClaimDetailSelectionField("select_claimdetails_input_insurance_provider_id", "ZINSURANCE_PROVIDER");
			//// Insurance Package
			this._setClaimDetailSelectionField("select_claimdetails_input_insurance_package_id", "ZINSURANCE_PACKAGE", null, "ZINSURANCE_PACKAGE_DESC");
			//// Type of Vehicle
			this._setClaimDetailSelectionField("select_claimdetails_input_vehicle_type", "ZVEHICLE_TYPE");
			//// Vehicle Ownership ID (Sendiri/Penjabat)
			this._setClaimDetailSelectionField("select_claimdetails_input_vehicle_ownership_id", "ZVEHICLE_OWNERSHIP");
			//// Type of Fare
			this._setClaimDetailSelectionField("select_claimdetails_input_fare_type_id", "ZFARE_TYPE");
			//// Vehicle Class
			this._setClaimDetailSelectionField("select_claimdetails_input_vehicle_class_id", "ZVEHICLE_CLASS");
			//// Flight Class
			this._setClaimDetailSelectionField("select_claimdetails_input_flight_class", "ZFLIGHT_CLASS");
			//// Room Type
			this._setClaimDetailSelectionField("select_claimdetails_input_room_type", "ZROOM_TYPE");
			//// Region (Semenanjung/Sabah/Sarawak)
			this._setClaimDetailSelectionField("select_claimdetails_input_region", "ZREGION");
			//// Area (Negara/Wilayah)
			this._setClaimDetailSelectionField("select_claimdetails_input_area", "ZAREA");
			//// Lodging Category
			this._setClaimDetailSelectionField("select_claimdetails_input_lodging_category", "ZLODGING_CAT", "LODGING_CATEGORY");
			//// Category/Purpose
			this._setClaimDetailSelectionField("select_claimdetails_input_claim_category", "ZCLAIM_CATEGORY");
			//// Category/Purpose (Mobile)
			this._setClaimDetailSelectionField("select_claimdetails_input_mobile_category_purpose_id", "ZMOBILE_CATEGORY_PURPOSE");
			//// Nama Pembekal Insuran
			this._setClaimDetailSelectionField("select_claimdetails_input_insurance_medical_provider_id", "ZINSURANCE_MEDICAL_PROVIDER");

			var oFilter = this._getDependentFilters();

			var oSelect = this.byId("select_claimdetails_input_dependent_name");
			var oSelectMulti = this.byId("combo_claimdetails_input_dependent");
			
			var oBindingMulti = oSelectMulti.getBinding("items");
			var oBinding = oSelect.getBinding("items");

			oBinding.filter(oFilter);
			oBindingMulti.filter(oFilter);

		},

		_getDependentFilters: function () {
			var oInputModel = this.getView().getModel("claimitem_input"); ("claimitem_input");
			const sClaimTypeItem = oInputModel.getProperty("/claim_item/claim_type_item_id");
			const oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			const sClaimantEmpId = oClaimSubmissionModel.getProperty("/claim_header/emp_id");

			var oEmpFilter = new Filter(
				this._oConstant.EntitiesFields.EMP_ID,
				FilterOperator.EQ,
				sClaimantEmpId
			);

			switch (sClaimTypeItem) {
				case this._oConstant.ClaimTypeItem.POST_EDUCATION_ASSISTANCE:
					var oPeduFilter = new Filter(this._oConstant.EntitiesFields.RELATIONSHIP, FilterOperator.EQ, this._oConstant.Relationship.CHILD);

					return new Filter({
						filters: [
							oEmpFilter,
							oPeduFilter
						],
						and: true
					})

				case this._oConstant.ClaimTypeItem.FLIGHT_WIL:
					var d18YearsFromCurrentDate = DateUtility.today().getFullYear() - 18;
					var d19YearsFromCurrentDate = DateUtility.today().getFullYear() - 19;
					var d25YearsFromCurrentDate = DateUtility.today().getFullYear() - 25;

					d18YearsFromCurrentDate = new Date(d18YearsFromCurrentDate, 0, 1).toLocaleDateString("en-CA");
					d19YearsFromCurrentDate = new Date(d19YearsFromCurrentDate, 0, 1).toLocaleDateString("en-CA");
					d25YearsFromCurrentDate = new Date(d25YearsFromCurrentDate, 0, 1).toLocaleDateString("en-CA");

					var oSpouseFilter = new Filter(this._oConstant.EntitiesFields.RELATIONSHIP, FilterOperator.EQ, this._oConstant.Relationship.SPOUSE);

					var oChildBelow18 = new Filter({
						filters: [
							new Filter(this._oConstant.EntitiesFields.RELATIONSHIP, FilterOperator.EQ, this._oConstant.Relationship.CHILD),
							new Filter(this._oConstant.EntitiesFields.DOB, FilterOperator.GT, d18YearsFromCurrentDate)
						],
						and: true
					})

					var oChildStudying = new Filter({
						filters: [
							new Filter(this._oConstant.EntitiesFields.RELATIONSHIP, FilterOperator.EQ, this._oConstant.Relationship.CHILD),
							new Filter(this._oConstant.EntitiesFields.DOB, FilterOperator.BT, d25YearsFromCurrentDate, d19YearsFromCurrentDate),
							new Filter(this._oConstant.EntitiesFields.STUDENT, FilterOperator.EQ, true),
						],
						and: true
					})

					var oDependentRuleFilter = new Filter({
						filters: [
							oSpouseFilter,
							oChildBelow18,
							oChildStudying
						],
						and: false
					})

					return new Filter({
						filters: [
							oEmpFilter,
							oDependentRuleFilter
						],
						and: true
					})

				case this._oConstant.ClaimTypeItem.LAUT: 
					var oDependentRuleFilter = new Filter({
						filters: [
							new Filter(this._oConstant.EntitiesFields.RELATIONSHIP,FilterOperator.EQ,this._oConstant.RelationshipType.SPOUSE),
							new Filter(this._oConstant.EntitiesFields.RELATIONSHIP,FilterOperator.EQ,this._oConstant.RelationshipType.CHILD),
							new Filter(this._oConstant.EntitiesFields.RELATIONSHIP,FilterOperator.EQ,this._oConstant.RelationshipType.ADDITIONAL_SPOUSE)
						],
						and: false
					});

					return new Filter({
						filters: [
							oEmpFilter,
							oDependentRuleFilter
						],
						and: true
					})

				case this._oConstant.ClaimTypeItem.INSURANCE:
				case this._oConstant.ClaimTypeItem.MED_ADVANCE:
					var d25YearsAndBelow = DateUtility.today();
					d25YearsAndBelow.setFullYear(d25YearsAndBelow.getFullYear() - 25);

					var s25YearsAndBelow = d25YearsAndBelow.toLocaleDateString("en-CA");

					// Spouse / Additional Spouse
					var oSpouseFilter = new Filter({
						filters: [
							new Filter({
								filters: [
									new Filter(
										this._oConstant.EntitiesFields.RELATIONSHIP,
										FilterOperator.EQ,
										this._oConstant.Relationship.SPOUSE
									),
									new Filter(
										this._oConstant.EntitiesFields.RELATIONSHIP,
										FilterOperator.EQ,
										this._oConstant.Relationship.ADDITIONAL_SPOUSE
									)
								],
								and: false
							}),
							new Filter(
								this._oConstant.EntitiesFields.MEDICAL_BENEFICIARY,
								FilterOperator.EQ,
								true
							)
						],
						and: true
					});

					// Child - Normal Rule
					var oEligibleChildFilter = new Filter({
						filters: [
							new Filter(
								this._oConstant.EntitiesFields.RELATIONSHIP,
								FilterOperator.EQ,
								this._oConstant.Relationship.CHILD
							),
							new Filter(
								this._oConstant.EntitiesFields.MEDICAL_BENEFICIARY,
								FilterOperator.EQ,
								true
							),
							new Filter(
								this._oConstant.EntitiesFields.STUDENT,
								FilterOperator.EQ,
								true
							),
							new Filter(
								this._oConstant.EntitiesFields.DOB,
								FilterOperator.GE,
								s25YearsAndBelow
							)
						],
						and: true
					});

					// Child - Disabled (bypass Student & DOB checks)
					var oDisabledChildFilter = new Filter({
						filters: [
							new Filter(
								this._oConstant.EntitiesFields.RELATIONSHIP,
								FilterOperator.EQ,
								this._oConstant.Relationship.CHILD
							),
							new Filter(
								this._oConstant.EntitiesFields.MEDICAL_BENEFICIARY,
								FilterOperator.EQ,
								true
							),
							new Filter(
								this._oConstant.EntitiesFields.DISABLED,
								FilterOperator.EQ,
								true
							)
						],
						and: true
					});

					return new Filter({
						filters: [
							oEmpFilter,
							new Filter({
								filters: [
									oSpouseFilter,
									oEligibleChildFilter,
									oDisabledChildFilter
								],
								and: false
							})
						],
						and: true
					})

				default:
					return new Filter({
						filters: [
							oEmpFilter
						]
					})
			}
		},

		/**
		* Set values that will be retrieved for selection dropdown based on claim header
		* method checks for field to be updated and the associated db table
		* if found, values from the db table will be populated to the dropdown
		* @private
		* @param {string} sId - ID of claim item field to be updated
		* @param {string} sTable - database table with values to populate to field
		* @param {string} sField - field of db table to retrieve value (for ID and Desc)
		* @param {string} sFieldDesc - specific name of description field of db table
		*/
		_setClaimDetailSelectionField: function (sId, sTable, sField, sFieldDesc) {

			var oControl = this.byId(sId);
			if (!oControl || !oControl.getVisible()) return;
			var oClaimItemModel = this.getView().getModel("claimitem_input");
			var sClaimTypeItemId = oClaimItemModel.getProperty("/claim_item/claim_type_item_id");

			if (!sField) {
				sField = sTable.slice(1);
			}
			if (!sFieldDesc) {
				sFieldDesc = sField + "_DESC";
			}
			var sItemText = "{employee>" + sFieldDesc + "}";

			var aFilters = [
				new Filter(this._oConstant.EntitiesFields.STATUS, FilterOperator.EQ, this._oConstant.ClaimTypeItemStatus.ACTIVE),
				new Filter(this._oConstant.EntitiesFields.START_DATE, FilterOperator.LE, DateUtility.getHanaDate(DateUtility.today())),
				new Filter(this._oConstant.EntitiesFields.END_DATE, FilterOperator.GE, DateUtility.getHanaDate(DateUtility.today()))
			];
			if (sTable === this._oConstant.ViewName.ZREGION) {
				const isOverseas = Object.values(this._oConstant.ClaimTypeItemOverseas)
					.includes(sClaimTypeItemId);

				aFilters.push(
					new Filter(
						this._oConstant.EntitiesFields.REGION_ID,
						isOverseas ? FilterOperator.EQ : FilterOperator.NE,
						this._oConstant.Region.OVERSEA
					)
				);
			}
			if (sClaimTypeItemId === this._oConstant.ClaimTypeItem.FLIGHT_L) {
				aFilters.push(
					new Filter(
						this._oConstant.EntitiesFields.FLIGHT_CLASS_ID,
						FilterOperator.NE,
						this._oConstant.FlightClass.BUSINESS
					)
				);
			}
			oControl.bindAggregation("items", {
				path: "employee>/" + sTable,
				filters: aFilters,
				sorter: [new Sorter(sField + "_ID")],
				template: new Item({
					key: "{employee>" + sField + "_ID}",
					text: sItemText
				})
			});
		},
		onAction_ClaimDetails_Toolbar: function (oAction) {
			// get action
			switch (oAction) {
				//// Save
				case 'Save':
					// confirm dialog
					this._newDialog(
						Utility.getText("dialog_claimdetails_input_save"),
						Utility.getText("label_claimdetails_input_save"),
						async function () {
							await this.onSave_ClaimDetails_Input();
						}.bind(this)
					);
					break;
				//// Others
				default:
					MessageBox.error(Utility.getText("msg_claimdetails_input_noaction"));
					break;
			}
		},
		onSave_ClaimDetails_Input: async function () {
			// validate input data
			var oInputModel = this.getView().getModel("claimitem_input");
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");

			CustomValidator.init(this.getOwnerComponent(), this.getView());
			var bCanProceed = await CustomValidator.validate(this._oConstant.SubmissionTypePrefix.CLAIMHEADER);
			if (!bCanProceed) {
				return;
			}
			//if departure time and arrival time exist, it will do a calculation for the flight duration
			//this is needed for the eligibility check for the flight class of the employee
			//setting the flight hours into the no_of_hours field in the model to allow the eligibility payload generation code to retrieve the flight hours value
			if (!!oInputModel.getProperty("/claim_item/departure_time") && !!oInputModel.getProperty("/claim_item/arrival_time")) {
				const dDepartureTime = new Date(oInputModel.getProperty("/claim_item/departure_time"));
				const dArrivalTime = new Date(oInputModel.getProperty("/claim_item/arrival_time"));
				const iDiffMs = dArrivalTime.getTime() - dDepartureTime.getTime();
				const fHours = Math.round((iDiffMs / (1000 * 60 * 60)) * 100) / 100;

				oInputModel.setProperty("/claim_item/no_of_hours", fHours);
			}

			// Reuben (FUT Issue 17)
			// When creating claim for post education assistance, actual amount is used instead of amount for input
			// To resolve issue, check first if the element is visible and active before performing the value check
			// Also will check for actual_amount as this is specific to post education asssistance scenario
			// will create a variable to store the IDs of elements for future ease of use

			const oInputAmountField = this.byId("input_claimdetails_input_amount");
			const oInputActualAmountField = this.byId("input_claimdetails_input_actual_amount");

			// Reuben End Issue 17

			// get claim item sub ID
			if (oInputModel.getProperty("/is_new")) {
				oInputModel.setProperty("/claim_item/claim_id", oClaimSubmissionModel.getProperty("/claim_header/claim_id"));
				var claimSubId = oClaimSubmissionModel.getProperty("/claim_items").length + 1;
				var totalClaimSubId = (oInputModel.getProperty("/claim_item/claim_id") ?? "") + ('' + '00' + claimSubId).slice(-3);
				oInputModel.setProperty("/claim_item/claim_sub_id", totalClaimSubId);
			}

			//specific for ELEKTRIK, BIL_AIR and TELEFON_B claim type item
			//during edit, it does not overwrite the receipt date with the new edited date because of the logic below
			//now it will check for these three claim type and on edit, it will overwrite the old receipt date 
			if(oInputModel.getProperty("/claim_item/claim_type_item_id") == this._oConstant.ClaimTypeItem.ELEKTRIK ||
				oInputModel.getProperty("/claim_item/claim_type_item_id") == this._oConstant.ClaimTypeItem.TELEFON_B ||
				oInputModel.getProperty("/claim_item/claim_type_item_id") == this._oConstant.ClaimTypeItem.BIL_AIR
			){
				if (!!oInputModel.getProperty("/claim_item/bill_date")) {
					oInputModel.setProperty("/claim_item/receipt_date", oInputModel.getProperty("/claim_item/bill_date"))
				}
			}

			// Exception: Kilometer claim items (KILOMETER / KM) must NOT be auto-populated.
			// 	The Travel/Receipt Date for these claims is a mandatory field that the
			// 	claimant has to fill in manually, so we skip the fallback chain entirely
			// 	and let the required-field validation below prompt the user instead.
			// */
			const bIsKilometerClaimItem = [
				this._oConstant.ClaimTypeItem.KILOMETER,
				this._oConstant.ClaimTypeItem.KM
			].includes(oInputModel.getProperty("/claim_item/claim_type_item_id"));

			if (!bIsKilometerClaimItem && oInputModel.getProperty("/claim_item/receipt_date") === null) {
				if (oInputModel.getProperty("/claim_item/bill_date") !== null) {
					oInputModel.setProperty("/claim_item/receipt_date", oInputModel.getProperty("/claim_item/bill_date"));
				} else {
					if (oInputModel.getProperty("/claim_item/start_date") !== null) {
						oInputModel.setProperty("/claim_item/receipt_date", oInputModel.getProperty("/claim_item/start_date"));
					} else {
						oInputModel.setProperty("/claim_item/receipt_date", oClaimSubmissionModel.getProperty("/claim_header/trip_start_date"));
					}
				}
			}

			// For Kilometer claim items, once a Travel/Receipt Date has been provided,
			// the Amount (MYR) must not be zero (e.g. rate could not be determined for that date).
			if (bIsKilometerClaimItem &&
				!!oInputModel.getProperty("/claim_item/receipt_date") &&
				parseFloat(oInputModel.getProperty("/claim_item/amount")) === 0) {
				MessageBox.error(Utility.getText("msg_claimdetails_km_amount_zero"), {
					closeOnBrowserNavigation: false
				});
				return;
			}

			// Eligibility Checking
			try {
				var oPayload = EligibilityCheck.generateEligibilityCheckPayload(this, this._oConstant.SubmissionTypePrefix.CLAIM);
				var oReturnPayload = await EligibleScenarioCheck.onEligibilityCheck(this._oModel, oPayload);
				var bCanProceed = await EligibilityCheck.eligibilityHandling(this, oReturnPayload, this._oConstant.SubmissionTypePrefix.CLAIM);
			} catch (error) {
				bCanProceed = false;
				MessageBox.error(error.message || Utility.getText("msg_failed_generic_error"));
			};


			if (!bCanProceed) return;

			// Validate required fields
			if (!this.getOwnerComponent().getValidator().validate(this.byId('idClaimSubmissionDetailInput'))) {
				MessageBox.error(Utility.getText("msg_claiminput_required"), {
					closeOnBrowserNavigation: false
				});
				return;
			}

			// Check for existing MataWang
			if (oInputModel.getProperty("/is_new") &&
				oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MATAWANG &&
				oClaimSubmissionModel.getProperty("/claim_items")
					.some(oItem => oItem.claim_type_item_id === this._oConstant.ClaimTypeItem.MATAWANG)) {
				MessageToast.show(Utility.getText("msg_matawang_duplicated"));
				return;
			}
			// upload Attachment 1
			const bUploadAttachment1 = await this._handleAttachmentUpload(
				oInputModel,
				"/attachments/attachment1",
				"/claim_item/attachment_file_1"
			);
			if (!bUploadAttachment1) return; // stop processing if upload fails for attachment 1

			// upload Attachment 2
			const bUploadAttachment2 = await this._handleAttachmentUpload(
				oInputModel,
				"/attachments/attachment2",
				"/claim_item/attachment_file_2"
			);
			if (!bUploadAttachment2) return; // stop processing if upload fails for attachment 2

			// upload Attachment 3
			const bUploadAttachment3 = await this._handleAttachmentUpload(
				oInputModel,
				"/attachments/attachment3",
				"/claim_item/attachment_file_3"
			);
			if (!bUploadAttachment3) return; // stop processing if upload fails for attachment 3

			// upload Attachment 4
			const bUploadAttachment4 = await this._handleAttachmentUpload(
				oInputModel,
				"/attachments/attachment4",
				"/claim_item/attachment_file_4"
			);
			if (!bUploadAttachment4) return; // stop processing if upload fails for attachment 4


			// Cash Repayment - override charging cost center from config
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.CASH_REPAY) {

				const sDefaultChargingCostCenter =
					await Utility.getDefaultChargingCostCenter(
						this.getOwnerComponent().getModel(),
						oInputModel.getProperty("/claim_item/claim_type_id"),
						oInputModel.getProperty("/claim_item/claim_type_item_id")
					);

				if (sDefaultChargingCostCenter) {
					oInputModel.setProperty(
						"/claim_item/cost_center",
						sDefaultChargingCostCenter
					);
				}
			}
			// get descriptions
			oInputModel.setProperty("/claim_item/descr/claim_type_item_id", this.byId("select_claimdetails_input_claimitem")._getSelectedItemText());
			// update claim item to database
			var saveSuccess = await this._saveClaimItem();

			if (saveSuccess) {
				// add claim item details to claim submission model
				if (oInputModel.getProperty("/is_new")) {
					oClaimSubmissionModel.setProperty("/claim_items", oClaimSubmissionModel.getProperty("/claim_items").concat(oInputModel.getProperty("/claim_item")));
					oClaimSubmissionModel.setProperty("/claim_items_count", oClaimSubmissionModel.getProperty("/claim_items").length);
				}
				else {
					oClaimSubmissionModel.getProperty("/claim_items").find(function (claim_item, i) {
						if (
							oClaimSubmissionModel.getProperty("/claim_items/" + i + "/claim_sub_id") ===
							oInputModel.getProperty("/claim_item/claim_sub_id")
						) {
							oClaimSubmissionModel.setProperty("/claim_items/" + i, oInputModel.getProperty("/claim_item"));
						}
					});
				}
				///Check to recalculate Mata Wang if it is required
				await this._recalculateMatawangIfNeeded(oClaimSubmissionModel, oInputModel, this._saveClaimItem.bind(this));
 				
				this.onCancel_ClaimDetails_Input();
			}
		},
		/**
		 * Handle Attachment Upload
		 * @public
		 * @param {JSONModel} oInputModel - Claim input JSON Model;
		 * @param {String} sAttachmentPath - Attachment Path;
		 * @param {String} sClaimItemPathPrefix - Claim item path prefix;
		 * @returns {Boolean} Upload successful indicator
		 */
		_handleAttachmentUpload: async function (oInputModel, sAttachmentPath, sClaimItemPathPrefix) {
			const sFileName = oInputModel.getProperty(`${sAttachmentPath}/fileName`);
			const sFileBinary = oInputModel.getProperty(`${sAttachmentPath}/fileContent`);

			if (!sFileName || !sFileBinary) {
				// nothing to upload
				return true;
			}

			BusyIndicator.show(0);

			try {
				const sAttachmentNumber = await Attachment.postAttachment(sFileName, sFileBinary, this._oSessionModel.getProperty("/userId"));
				const sAttachmentString = `${sAttachmentNumber} - ${sFileName}`;
				oInputModel.setProperty(`${sClaimItemPathPrefix}`, sAttachmentString);
				oInputModel.setProperty(`${sClaimItemPathPrefix.replace("/claim_item/", "/claim_item/descr/")}`, sFileName);
			} catch (oError) {
				BusyIndicator.hide();
				MessageBox.error(Utility.getText("msg_claiminput_attachment_upload_error"));
				return false;   // stop further processing
			}

			BusyIndicator.hide();
			return true;
		},

		_saveClaimItem: async function () {
			const oEditButtonModel = this.getView().getModel("editButtonModel");
			if (oEditButtonModel && oEditButtonModel.getProperty("/state") === true) {
				return MessageBox.error(Utility.getText("msg_error_unsaved_header_text"), {
					title: Utility.getText("msg_error_unsaved_header_title")
				});
			}
			// get input model
			var oInputModel = this.getView().getModel("claimitem_input");
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");

			var sDependentList = JSON.stringify(oInputModel.getProperty("/claim_item/dependent"));

			try {
				BusyIndicator.show(0);
				var oModel = this.getOwnerComponent().getModel();
				var oListBinding = null;

				// Ensure Internal Order is populated before save
				if (!oInputModel.getProperty("/claim_item/internal_order")) {
					var sProjectCode = oClaimSubmissionModel.getProperty("/claim_header/project_code");
					var sInternalOrder = await Utility.getInternalOrderByProjectCode(oModel,sProjectCode);

					oInputModel.setProperty("/claim_item/internal_order", sInternalOrder);
				}

				// set body for update
				var oBody = new JSONModel({
					CLAIM_ID: oInputModel.getProperty("/claim_item/claim_id"),
					CLAIM_SUB_ID: oInputModel.getProperty("/claim_item/claim_sub_id"),
					CLAIM_TYPE_ITEM_ID: oInputModel.getProperty("/claim_item/claim_type_item_id"),
					PERCENTAGE_COMPENSATION: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/percentage_compensation"))).toFixed(2),
					ACCOUNT_NO: oInputModel.getProperty("/claim_item/account_no"),
					AMOUNT: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/amount"))).toFixed(2),
					ATTACHMENT_FILE_1: oInputModel.getProperty("/claim_item/attachment_file_1"),
					ATTACHMENT_FILE_2: oInputModel.getProperty("/claim_item/attachment_file_2"),
					BILL_NO: oInputModel.getProperty("/claim_item/bill_no"),
					BILL_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/bill_date")),
					CLAIM_CATEGORY: oInputModel.getProperty("/claim_item/claim_category"),
					COUNTRY: oInputModel.getProperty("/claim_item/country"),
					DISCLAIMER: oInputModel.getProperty("/claim_item/disclaimer"),
					START_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/start_date")),
					END_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/end_date")),
					START_TIME: DateUtility.getHanaTime(oInputModel.getProperty("/claim_item/start_time")),
					END_TIME: DateUtility.getHanaTime(oInputModel.getProperty("/claim_item/end_time")),
					FLIGHT_CLASS: oInputModel.getProperty("/claim_item/flight_class"),
					FROM_LOCATION: oInputModel.getProperty("/claim_item/from_location"),
					FROM_LOCATION_OFFICE: oInputModel.getProperty("/claim_item/from_location_office"),
					KM: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/km"))).toFixed(2),
					LOCATION: oInputModel.getProperty("/claim_item/location"),
					LOCATION_TYPE: oInputModel.getProperty("/claim_item/location_type"),
					LODGING_CATEGORY: oInputModel.getProperty("/claim_item/lodging_category"),
					LODGING_ADDRESS: oInputModel.getProperty("/claim_item/lodging_address"),
					MARRIAGE_CATEGORY: oInputModel.getProperty("/claim_item/marriage_category"),
					AREA: oInputModel.getProperty("/claim_item/area"),
					NO_OF_FAMILY_MEMBER: oInputModel.getProperty("/claim_item/no_of_family_member"),
					PARKING: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/parking"))),
					PHONE_NO: oInputModel.getProperty("/claim_item/phone_no"),
					RATE_PER_KM: oInputModel.getProperty("/claim_item/descr/rate_per_km"),
					RECEIPT_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/receipt_date")),
					RECEIPT_NUMBER: oInputModel.getProperty("/claim_item/receipt_number"),
					REMARK: oInputModel.getProperty("/claim_item/remark"),
					ROOM_TYPE: oInputModel.getProperty("/claim_item/room_type"),
					REGION: oInputModel.getProperty("/claim_item/region"),
					FROM_STATE_ID: oInputModel.getProperty("/claim_item/from_state_id"),
					TO_STATE_ID: oInputModel.getProperty("/claim_item/to_state_id"),
					TO_LOCATION: oInputModel.getProperty("/claim_item/to_location"),
					TO_LOCATION_OFFICE: oInputModel.getProperty("/claim_item/to_location_office"),
					TOLL: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/toll"))).toFixed(2),
					TOTAL_EXP_AMOUNT: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/total_exp_amount"))).toFixed(2),
					VEHICLE_TYPE: oInputModel.getProperty("/claim_item/vehicle_type"),
					VEHICLE_FARE: oInputModel.getProperty("/claim_item/vehicle_fare"),
					TRIP_START_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/trip_start_date")),
					TRIP_END_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/trip_end_date")),
					EVENT_START_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/event_start_date")),
					EVENT_END_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/event_end_date")),
					TRAVEL_DURATION_DAY: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/travel_duration_day"))).toFixed(1),
					TRAVEL_DURATION_HOUR: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/travel_duration_hour"))).toFixed(1),
					PROVIDED_BREAKFAST: oInputModel.getProperty("/claim_item/provided_breakfast")?.toString(),
					PROVIDED_LUNCH: oInputModel.getProperty("/claim_item/provided_lunch")?.toString(),
					PROVIDED_DINNER: oInputModel.getProperty("/claim_item/provided_dinner")?.toString(),
					ENTITLED_BREAKFAST: oInputModel.getProperty("/claim_item/entitled_breakfast")?.toString(),
					ENTITLED_LUNCH: oInputModel.getProperty("/claim_item/entitled_lunch")?.toString(),
					ENTITLED_DINNER: oInputModel.getProperty("/claim_item/entitled_dinner")?.toString(),
					ANGGOTA_ID: oInputModel.getProperty("/claim_item/anggota_id"),
					ANGGOTA_NAME: oInputModel.getProperty("/claim_item/anggota_name"),
					DEPENDENT_NAME: oInputModel.getProperty("/claim_item/dependent_name"),
					TYPE_OF_PROFESSIONAL_BODY: oInputModel.getProperty("/claim_item/type_of_professional_body"),
					DISCLAIMER_GALAKAN: oInputModel.getProperty("/claim_item/disclaimer_galakan"),
					TRANSFER_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/transfer_date")),
					NO_OF_DAYS: oInputModel.getProperty("/claim_item/no_of_days"),
					FAMILY_COUNT: oInputModel.getProperty("/claim_item/family_count"),
					FUNERAL_TRANSPORTATION: oInputModel.getProperty("/claim_item/funeral_transportation"),
					ROUND_TRIP: oInputModel.getProperty("/claim_item/round_trip"),
					TRIP_END_TIME: DateUtility.getHanaTime(oInputModel.getProperty("/claim_item/trip_end_time")),
					TRIP_START_TIME: DateUtility.getHanaTime(oInputModel.getProperty("/claim_item/trip_start_time")),
					COST_CENTER: (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PERSONAL_EXP || oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.POTONGAN_ELAUN)
									? null
									: (oInputModel.getProperty("/claim_item/cost_center") || oClaimSubmissionModel.getProperty("/claim_header/alternate_cost_center")),
					GL_ACCOUNT: (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PERSONAL_EXP || oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.POTONGAN_ELAUN)
									? this._oConstant.StatementDueInfo.GL_CODE
									: (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.CASH_REPAY ? this._oConstant.Default.CASH_REPAY_GL : oInputModel.getProperty("/claim_item/gl_account")),
					MATERIAL_CODE: (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PERSONAL_EXP || oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.POTONGAN_ELAUN)
									? null
									: oInputModel.getProperty("/claim_item/material_code"),					
					VEHICLE_OWNERSHIP_ID: oInputModel.getProperty("/claim_item/vehicle_ownership_id"),
					ACTUAL_AMOUNT: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/actual_amount"))).toFixed(2),
					ARRIVAL_TIME: oInputModel.getProperty("/claim_item/arrival_time") ? new Date(oInputModel.getProperty("/claim_item/arrival_time")).toISOString() : null,
					CLAIM_TYPE_ID: oInputModel.getProperty("/claim_item/claim_type_id"),
					COURSE_TITLE: oInputModel.getProperty("/claim_item/course_title"),
					CURRENCY_AMOUNT: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/currency_amount"))).toFixed(2),
					CURRENCY_CODE: oInputModel.getProperty("/claim_item/currency_code"),
					CURRENCY_RATE: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/currency_rate"))).toFixed(4),
					DEPARTURE_TIME: oInputModel.getProperty("/claim_item/departure_time") ? new Date(oInputModel.getProperty("/claim_item/departure_time")).toISOString() : null,
					DEPENDENT: sDependentList,
					EMP_ID: this._oSessionModel.getProperty("/userId"),
					FARE_TYPE_ID: oInputModel.getProperty("/claim_item/fare_type_id"),
					INSURANCE_CERT_END_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/insurance_cert_end_date")),
					INSURANCE_CERT_START_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/insurance_cert_start_date")),
					INSURANCE_PACKAGE_ID: oInputModel.getProperty("/claim_item/insurance_package_id"),
					INSURANCE_PROVIDER_ID: oInputModel.getProperty("/claim_item/insurance_provider_id"),
					INSURANCE_PROVIDER_NAME: oInputModel.getProperty("/claim_item/insurance_provider_name"),
					INSURANCE_PURCHASE_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/insurance_purchase_date")),
					METER_CUBE_ACTUAL: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/meter_cube_actual"))).toFixed(2),
					METER_CUBE_ENTITLED: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/meter_cube_entitled"))).toFixed(2),
					MOBILE_CATEGORY_PURPOSE_ID: oInputModel.getProperty("/claim_item/mobile_category_purpose_id"),
					NEED_FOREIGN_CURRENCY: oInputModel.getProperty("/claim_item/need_foreign_currency"),
					POLICY_NUMBER: oInputModel.getProperty("/claim_item/policy_number"),
					PURPOSE: oInputModel.getProperty("/claim_item/purpose"),
					REQUEST_APPROVAL_AMOUNT: oInputModel.getProperty("/claim_item/request_approval_amount"),
					STUDY_LEVELS_ID: oInputModel.getProperty("/claim_item/study_levels_id"),
					TRAVEL_DAYS_ID: oInputModel.getProperty("/claim_item/travel_days_id"),
					VEHICLE_CLASS_ID: oInputModel.getProperty("/claim_item/vehicle_class_id"),
					DAILY_ALLOWANCE: this._nonNan(parseFloat(oInputModel.getProperty("/claim_item/daily_allowance"))),
					TIPS: this._nonNan(parseInt(oInputModel.getProperty("/claim_item/tips"))),
					EXCLUDE_TIPS: oInputModel.getProperty("/claim_item/exclude_tips"),
					TOTAL_TRAVELLER: oInputModel.getProperty("/claim_item/number_of_travellers"),
					DEPENDENT_TYPE_ID: oInputModel.getProperty("/claim_item/dependent_type"),
					INTERNAL_ORDER: oInputModel.getProperty("/claim_item/internal_order"),
					COURSE_DURATION: oInputModel.getProperty("/claim_item/course_duration"),
					CHARGED_TO_CCC: (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PERSONAL_EXP ||
									oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.POTONGAN_ELAUN)
									? true
									: !!oInputModel.getProperty("/claim_item/charged_to_ccc"),
					COURSE_DURATION: oInputModel.getProperty("/claim_item/course_duration"),
					POLICY_START_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/policy_start_date")),
					POLICY_END_DATE: DateUtility.getHanaDate(oInputModel.getProperty("/claim_item/policy_end_date")),
					DEPENDENT_NATIONAL_ID: oInputModel.getProperty("/claim_item/dependent_national_id"),
					INSURANCE_MEDICAL_PROVIDER_ID: oInputModel.getProperty("/claim_item/insurance_medical_provider_id"),
					INSURANCE_MEDICAL_PROVIDER_NAME: oInputModel.getProperty("/claim_item/insurance_medical_provider_name"),
					ATTACHMENT_FILE_3: oInputModel.getProperty("/claim_item/attachment_file_3"),
					ATTACHMENT_FILE_4: oInputModel.getProperty("/claim_item/attachment_file_4"),
					POLICY_YEAR: oInputModel.getProperty("/claim_item/policy_year")
				});
				// to save the attachment inside SF
				var sAttachment1_SFID = oInputModel.getProperty("/claim_item/attachment_file_1")?.split(" - ")[0];
				var sAttachment2_SFID = oInputModel.getProperty("/claim_item/attachment_file_2")?.split(" - ")[0];
				var sAttachment3_SFID = oInputModel.getProperty("/claim_item/attachment_file_3")?.split(" - ")[0];
				var sAttachment4_SFID = oInputModel.getProperty("/claim_item/attachment_file_4")?.split(" - ")[0];

				if (oInputModel.getProperty("/claim_item/is_new")) {
					// create new item
					oListBinding = oModel.bindList("/ZCLAIM_ITEM");
					var oContext = oListBinding.create(oBody.getData());
					await oContext.created().then(async () => {
						// post MDF for item attachments
						if (oInputModel.getProperty("/claim_item/attachment_file_1") || oInputModel.getProperty("/claim_item/attachment_file_2") || oInputModel.getProperty("/claim_item/attachment_file_3") || oInputModel.getProperty("/claim_item/attachment_file_4" )) {
							await Attachment.postMDFChild(
								oInputModel.getProperty("/claim_item/claim_id"),
								oInputModel.getProperty("/claim_item/claim_sub_id"),
								sAttachment1_SFID,
								sAttachment2_SFID,
								sAttachment3_SFID,
								sAttachment4_SFID,
							)
						}

						MessageToast.show(Utility.getText("msg_claimsubmission_creation_item", [oInputModel.getProperty("/claim_item/claim_sub_id")]));
					});
				}
				else {
					oListBinding = oModel.bindList("/ZCLAIM_ITEM", null, null,
						[
							new Filter({ path: "CLAIM_ID", operator: FilterOperator.EQ, value1: oInputModel.getProperty("/claim_item/claim_id") }),
							new Filter({ path: "CLAIM_SUB_ID", operator: FilterOperator.EQ, value1: oInputModel.getProperty("/claim_item/claim_sub_id") })
						],
						{
							$$ownRequest: true,
							$$groupId: "$auto",
							$$updateGroupId: "$auto"
						}
					);

					var aCtx = await oListBinding.requestContexts(0, 1);
					var oCtx = aCtx[0];

					if (!oCtx) {
						throw new Error("Claim item not found in database");
					}
					else {
						// get existing attachment file values
						var oAttachmentFile1 = oCtx.getProperty("ATTACHMENT_FILE_1");
						var oAttachmentFile2 = oCtx.getProperty("ATTACHMENT_FILE_2");
						var oAttachmentFile3 = oCtx.getProperty("ATTACHMENT_FILE_3");
						var oAttachmentFile4 = oCtx.getProperty("ATTACHMENT_FILE_4");

						for (const [key, value] of Object.entries(oBody.getData())) {
							oCtx.setProperty(key, value);
						}
						// Delete attachment from SF during save when previously marked for deletion
						if (oInputModel.getProperty("/claim_item/attachment_file_1_delete")) {
							const sSFID = oInputModel.getProperty("/claim_item/attachment_file_1_delete")?.split(" - ")[0];
							await Attachment.deleteAttachment(sSFID);
							oCtx.setProperty("ATTACHMENT_FILE_1", null);
						}
						// Delete Attachment 2 from SF during save
						if (oInputModel.getProperty("/claim_item/attachment_file_2_delete")) {
							const sSFID = oInputModel.getProperty("/claim_item/attachment_file_2_delete")?.split(" - ")[0];
							await Attachment.deleteAttachment(sSFID);
							oCtx.setProperty("ATTACHMENT_FILE_2", null);
						}
						// Delete Attachment 3 from SF during save
						if (oInputModel.getProperty("/claim_item/attachment_file_3_delete")) {
							const sSFID = oInputModel.getProperty("/claim_item/attachment_file_3_delete")?.split(" - ")[0];
							await Attachment.deleteAttachment(sSFID);
							oCtx.setProperty("ATTACHMENT_FILE_3", null);
						}
						// Delete Attachment 4 from SF during save
						if (oInputModel.getProperty("/claim_item/attachment_file_4_delete")) {
							const sSFID = oInputModel.getProperty("/claim_item/attachment_file_4_delete")?.split(" - ")[0];
							await Attachment.deleteAttachment(sSFID);
							oCtx.setProperty("ATTACHMENT_FILE_4", null);
						}

						await oModel.submitBatch("$auto");

						// post MDF for item attachments
						if (
							(oInputModel.getProperty("/claim_item/attachment_file_1") && oInputModel.getProperty("/claim_item/attachment_file_1") !== oAttachmentFile1) ||
							(oInputModel.getProperty("/claim_item/attachment_file_2") && oInputModel.getProperty("/claim_item/attachment_file_2") !== oAttachmentFile2) ||
							(oInputModel.getProperty("/claim_item/attachment_file_3") && oInputModel.getProperty("/claim_item/attachment_file_3") !== oAttachmentFile3) ||
							(oInputModel.getProperty("/claim_item/attachment_file_4") && oInputModel.getProperty("/claim_item/attachment_file_4") !== oAttachmentFile4)
						) {
							await Attachment.postMDFChild(
								oInputModel.getProperty("/claim_item/claim_id"),
								oInputModel.getProperty("/claim_item/claim_sub_id"),
								sAttachment1_SFID,
								sAttachment2_SFID,
								sAttachment3_SFID,
								sAttachment4_SFID
							)
						}
						Attachment._mDeleteAttachments = {};
						MessageToast.show(Utility.getText("msg_claimsubmission_save_item", [oInputModel.getProperty("/claim_item/claim_sub_id")]));
					}
				}

				return true;
			} 
			catch (e) {
				MessageBox.error(e.message);
				return false;
			} 
			finally {
				BusyIndicator.hide();
			}
		},

		onChange_ClaimDetails_Input_Attachment: function (oEvent, fieldNumber) {
			// check if file can be uploaded
			var fileName = oEvent.getSource().getValue();
			var domRef = oEvent.getSource().getFocusDomRef();
			var file = domRef.files[0];
			var reader = new FileReader();
			const oInputModel = this.getView().getModel("claimitem_input");

			reader.addEventListener("load", () => {
				if (oInputModel) {
					oInputModel.setProperty("/attachments/attachment" + fieldNumber + "/fileName", fileName);
					oInputModel.setProperty("/attachments/attachment" + fieldNumber + "/fileContent", reader.result.replace("data:" + file.type + ";base64,", ""));
					
				}
			});

			if (oInputModel.getProperty("/claim_item/attachment_file_" + fieldNumber + "_delete")) {
				oInputModel.setProperty("/claim_item/attachment_file_" + fieldNumber + "_delete", null)
			}

			if (file) {
				reader.readAsDataURL(file);
			}
		},

		onUploadComplete_ClaimInput_Attachment: function (oEvent) {
			var iHttpStatusCode = oEvent.getParameters("status");
			var sResponse = oEvent.getParameters("response");
			var sMessage = iHttpStatusCode === 200 ? sResponse + " (Upload Success)" : sResponse + " (Upload Error)";
			MessageToast.show(sMessage);
		},

		onFileSizeExceed_ClaimInput_Attachment: function (oEvent) {
			MessageBox.error(Utility.getText("msg_claiminput_attachment_upload_filesize"));
		},

		onTypeMissmatch_ClaimInput_Attachment: function (oEvent) {
			MessageBox.error(Utility.getText("msg_claiminput_attachment_upload_mismatch"));
		},

		/**
		 * Deletes the selected claim attachment after user confirmation
		 * @public
		 */
		onDelete_Claim_Attachment: function (sDeleteTarget) {
			this._openDeleteAttachmentDialog(sDeleteTarget);
		},
		_openDeleteAttachmentDialog: function (sDeleteTarget) {
			if (!this._oDeleteAttachmentDialog) {
				Fragment.load({
					name: "claima.fragment.deleteattachment",
					id: "deleteAttachmentDialog",
					controller: this
				}).then(function (oDialog) {
					this._oDeleteAttachmentDialog = oDialog;
					this.getView().addDependent(oDialog);
					oDialog.data("deleteTarget", sDeleteTarget);
					oDialog.open();
				}.bind(this));
			} else {
				this._oDeleteAttachmentDialog.data("deleteTarget", sDeleteTarget);
				this._oDeleteAttachmentDialog.open();
			}
		},

		onConfirmDeleteAttachment: async function () {
			var sDeleteTarget = this._oDeleteAttachmentDialog.data("deleteTarget");
			const oClaimModel = this.getView().getModel("claimitem_input");

			Attachment.init(this.getOwnerComponent(), this.getView());
			Attachment.confirmDeleteAttachment(oClaimModel, this._oConstant.SubmissionTypePrefix.CLAIM, sDeleteTarget);
			this._oDeleteAttachmentDialog.close();
		},

		onCancelDeleteAttachment: function () {
			this._oDeleteAttachmentDialog.close();
		},

		onDependentSelectionChange: async function (oEvent) {
			var oInputModel = this.getView().getModel("claimitem_input");
			await ClaimUtility.fetchMeterCubeEntitlement(oInputModel);

			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.LAUT) {
				await ClaimUtility.fetchPengangkutanLautAmount(oInputModel);
			}
		},

		/**
		 * On changing value of 'actual amount' field, change value of 'amount' property to percentage of 'actual_amount' property based on subsidised rate
		 * This applies to claim items that have fields for both 'amount' and 'actual amount'. In this case,
		 * 'amount' is auto-populated while 'actual amount' comes from user input
		 * @public
		 */
		onChange_ClaimDetails_ActualAmount: function () {
			// verify if property exists and 'amount' field is visible
			var oPropertyModel = this.getView().getModel("claimitem_property");
			var oInputModel = this.getView().getModel("claimitem_input");
			if (oPropertyModel.getProperty("/amount/is_visible") && oPropertyModel.getProperty("/percentage_compensation/is_visible")) {
				// set 'amount' property to % of actual amount based on percentage compensation
				if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PEM_PINDAH) {
					ClaimUtility.fetchPemberianPindahAmount();
				} else {
					oInputModel.setProperty("/claim_item/amount", parseFloat(oInputModel.getProperty("/claim_item/actual_amount")) * (parseFloat(oInputModel.getProperty("/claim_item/percentage_compensation")) / 100));
				}
			}

			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.LAUT) {
				ClaimUtility.fetchPengangkutanLautAmount(oInputModel);
			}
		},

		onChange_PengangkutanLautInputs: async function () {
			const oInputModel = this.getView().getModel("claimitem_input");
			await ClaimUtility.fetchPengangkutanLautAmount(oInputModel);
		},

		onChange_ClaimDetails_DateRange: async function (startdate, enddate) {
			// reset claim detail amounts
			this._resetPerDiem();

			var startDateValue = this.byId(startdate).getValue();
			var endDateValue = this.byId(enddate).getValue();
			// check for missing value
			if (!startDateValue || !endDateValue) {
				return;
			}
			// check if end date earlier than start date
			var startDateUnix = new Date(startDateValue).valueOf();
			var endDateUnix = new Date(endDateValue).valueOf();
			if (startDateUnix > endDateUnix) {
				return;
			}
			else {
				// calculate per diem details
				if (this.byId("input_claimdetails_input_entitled_breakfast").getVisible()) {
					await this._calculatePerDiem();
				}
				// Calculate number of days
				var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
				var oInputModel = this.getView().getModel("claimitem_input");
				var oPropertyModel = this.getView().getModel("claimitem_property");
				if (oPropertyModel.getProperty("/no_of_days/is_visible")) {
					oInputModel.setProperty("/claim_item/no_of_days", DateUtility.calculateNumberOfDays(this._oConstant.SubmissionTypePrefix.CLAIM, oClaimSubmissionModel.getProperty("/claim_header"), oInputModel.getProperty("/claim_item")));
					this.onChange_ClaimDetails_NumberOfDays();
				}
			}
		},

		/**
		 * run related methods on setting start/end date
		 * @public
		 */
		onChange_ClaimDetails_StartEndDate: async function () {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			var oInputModel = this.getView().getModel("claimitem_input");
			var oPropertyModel = this.getView().getModel("claimitem_property");
			//oInputModel.refresh(true);

			// Calculate number of days
			if (oPropertyModel.getProperty("/no_of_days/is_visible")) {
				oInputModel.setProperty("/claim_item/no_of_days", DateUtility.calculateNumberOfDays(this._oConstant.SubmissionTypePrefix.CLAIM, oClaimSubmissionModel.getProperty("/claim_header"), oInputModel.getProperty("/claim_item")));
				this.onChange_ClaimDetails_NumberOfDays();
			}

			// calculate per diem details
			if (oPropertyModel.getProperty("/entitled_breakfast/is_visible")) {
				// reset per diem amounts
				this._resetPerDiem();

				await this._calculatePerDiem();
			}
			// Fetch Rate for KM
			await this._calculateRatePerKm(true);
		},

		/**
		 * run related methods on setting receipt date
		 * @public
		 */
		onChange_ClaimDetails_ReceiptDate: async function () {
			// Fetch Rate for KM
			await this._calculateRatePerKm(true);
		},

		/**
		 * On setting insurance cert start/end date, call private method to calculate number of days
		 * @public
		 */
		/*
		onChange_ClaimDetails_InsuranceCertDate: function () {
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			var oInputModel = this.getView().getModel("claimitem_input");
			oInputModel.refresh(true);

			// update number of days
			oInputModel.setProperty("/claim_item/no_of_days", DateUtility.calculateNumberOfDays(this._oConstant.SubmissionTypePrefix.CLAIM, oClaimSubmissionModel.getProperty("/claim_header"), oInputModel.getProperty("/claim_item")));
			this.onChange_ClaimDetails_NumberOfDays();
		},*/

		/**
		 * On changing number of days field, method checks for lodging claim type item to calculate eligible amount
		 * @public
		 */
		onChange_ClaimDetails_NumberOfDays: async function (oEvent) {
			var oInputModel = this.getView().getModel("claimitem_input");
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			// if claim type item is lodging, calculate amount based on eligible amount and number of days (and number of family members if lodging pertukaran)
			if (Object.values(this._oConstant.ClaimTypeItemLodging).includes(oInputModel.getProperty("/claim_item/claim_type_item_id"))) {
				oInputModel.setProperty("/claim_item/amount", ClaimUtility.calculateAmountLodging());
			}
			// calculate amount for ELAUN PINDAH - MKN_LOAN
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MKN_LOAN || 
			oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MKN_TUKAR) {
				this._updateEntitlementAmount(oInputModel,oClaimSubmissionModel);
			}
			
			if(oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.MKN_TUKAR || 
				oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.LOD_TUKAR){
				this._onChangeTravelers(oEvent)
			}
		},

		formatDuration: function(iTotalMinutes) {
			if (!iTotalMinutes || iTotalMinutes <= 0) {
				return "0 hours 0 minutes";
			}

			var hours = Math.floor(iTotalMinutes / 60);
			var minutes = iTotalMinutes % 60;

			return hours + " hours " + minutes + " minutes";
		},

		onChange_ClaimDetails_TimeRange: async function (startdate, starttime, enddate, endtime) {
			var oInputModel = this.getView().getModel("claimitem_input");

			// check for missing value
			var startTimeValue = this.byId(starttime).getDateValue();
			var endTimeValue = this.byId(endtime).getDateValue();
			if (!startTimeValue || !endTimeValue) {
				return;
			}

			// get course duration
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.CERAMAH) {
				var durationMs = endTimeValue - startTimeValue;
				var iCourseDurationMinutes = Math.floor(durationMs / (1000 * 60));

				if (iCourseDurationMinutes <= 0) {
					MessageBox.error(Utility.getText("ceramah_duration_must_be_greater_than_zero"));

					if (this._sPreviousEndTime) {

						// Existing valid value -> revert
						oInputModel.setProperty("/claim_item/end_time",this._sPreviousEndTime);
						oInputModel.setProperty("/claim_item/amount",this._iPreviousAmount);

					} else {

						// New claim -> clear
						oInputModel.setProperty("/claim_item/end_time","");
						this.byId(endtime).setValue("");
						oInputModel.setProperty("/claim_item/amount",0);
					}

					return;
				}

				// VALID duration
				var iAmount = await ClaimUtility.getCeramahEligibleAmount(
					iCourseDurationMinutes
				);

				oInputModel.setProperty("/claim_item/course_duration",iCourseDurationMinutes);
				oInputModel.setProperty("/claim_item/amount",iAmount);

				// Save last valid values
				this._sPreviousEndTime =
					oInputModel.getProperty("/claim_item/end_time");

				this._iPreviousAmount = iAmount;
			}

			// reset claim detail amounts
			this._resetPerDiem();

			// check for missing value
			var startDateValue = this.byId(startdate).getValue();
			var endDateValue = this.byId(enddate).getValue();
			if (!startDateValue || !endDateValue) {
				return;
			}

			// check if end datetime earlier than start datetime
			var startDateUnix = new Date(startDateValue).valueOf();
			startDateUnix = startDateUnix + new Date(startTimeValue).valueOf()
			var endDateUnix = new Date(endDateValue).valueOf();
			endDateUnix = endDateUnix + new Date(endTimeValue).valueOf()
			if (startDateUnix > endDateUnix) {
				return;
			}
			else {
				// calculate per diem details
				if (this.byId("input_claimdetails_input_entitled_breakfast").getVisible()) {
					await this._calculatePerDiem();
				}
			}
		},

		onChange_ClaimDetails_FlightTimeRange: async function () {
			this._resetPerDiem();

			var oInputModel = this.getView().getModel("claimitem_input");
			var vDepartureVal = oInputModel.getProperty("/claim_item/departure_time");
			var vArrivalVal = oInputModel.getProperty("/claim_item/arrival_time");

			if (!vDepartureVal || !vArrivalVal) {
				return;
			}

			var oDepartureDate = new Date(vDepartureVal);
			var oArrivalDate = new Date(vArrivalVal);

			if (isNaN(oDepartureDate.getTime()) || isNaN(oArrivalDate.getTime())) {
				return;
			}

			var iDiffMilliseconds = oArrivalDate.getTime() - oDepartureDate.getTime();

			if (iDiffMilliseconds < 0) {
				return;
			}

			var iDiffHours = iDiffMilliseconds / (1000 * 60 * 60);

			if (this.byId("input_claimdetails_input_entitled_breakfast").getVisible()) {
				// Consider passing iDiffHours into this method if the calculation relies on it
				await this._calculatePerDiem();
			}
		},

		_resetPerDiem: function () {
			// reset claim detail amounts
			if (this.byId("input_claimdetails_input_travel_duration_day").getVisible()) {
				this.byId("input_claimdetails_input_travel_duration_day").setValue("");
			}
			if (this.byId("input_claimdetails_input_travel_duration_hour").getVisible()) {
				this.byId("input_claimdetails_input_travel_duration_hour").setValue("");
			}
			if (this.byId("input_claimdetails_input_entitled_breakfast").getVisible()) {
				this.byId("input_claimdetails_input_entitled_breakfast").setValue("");
			}
			if (this.byId("input_claimdetails_input_entitled_lunch").getVisible()) {
				this.byId("input_claimdetails_input_entitled_lunch").setValue("");
			}
			if (this.byId("input_claimdetails_input_entitled_dinner").getVisible()) {
				this.byId("input_claimdetails_input_entitled_dinner").setValue("");
			}
		},

		/**
		 * On selecting vehicle type from dropdown, call method to determine rate per km based on vehicle type and claim item used
		 * rate per KM values will be populated based on output values returned
		 * @public
		 */
		onSelect_ClaimDetails_VehicleType: async function (oEvent) {
			var oInputModel = this.getView().getModel("claimitem_input");
			if (!oInputModel) return;

			// set description value
			var oSelectedItem = oEvent ? oEvent.getParameters().selectedItem : null;
			if (oSelectedItem) {
				// get vehicle type description
				oInputModel.setProperty("/claim_item/descr/vehicle_type", oSelectedItem.getBindingContext("employee").getObject(this._oConstant.EntitiesFields.VEHICLE_TYPE_DESC));
			}
			else {
				oInputModel.setProperty("/claim_item/descr/vehicle_type", null);
			}
			// calculate rate per km
			await this._calculateRatePerKm(true);
		},
		/**
		 * On changing kilometer field, method checks if rate per km field exists to calculate amount
		 * @public
		 */
		onChange_ClaimDetails_Kilometer: async function () {
			var oPropertyModel = this.getView().getModel("claimitem_property");
			var oInputModel = this.getView().getModel("claimitem_input");

			if (oPropertyModel.getProperty("/rate_per_km/is_visible")) {
				await this._calculateRatePerKm(false);
			}

			//Added for Round Trip
			if (oInputModel.getProperty("/claim_item/round_trip")) {
				var fKm = parseFloat(oInputModel.getProperty("/claim_item/km")) || 0;
				if (fKm > 0) {
					oInputModel.setProperty("/claim_item/rtkm", fKm * 2);
				} else {
					oInputModel.setProperty("/claim_item/rtkm", null);
				}
			}
		},

		/**
		 * On changing toll field, method checks if km and rate per km fields exist to calculate amount
		 * @public
		 */
		onChange_ClaimDetails_Toll: function () {
			var oPropertyModel = this.getView().getModel("claimitem_property");
			// calculate amount if km and rate per km exists 
			if (oPropertyModel.getProperty("/km/is_visible") && oPropertyModel.getProperty("/rate_per_km/is_visible")) {
				this._calculateRatePerKm(false);
			}
		},

		/**
		 * If rate per km (and toll) fields are available, auto-populate amount value
		 * Formulas:
		 * with toll - ((km * rate_per_km) + toll)
		 * without toll - (km * rate_per_km)
		 * @private
		 */
		_calculateRatePerKm: async function (bRecalculateRate) {
			const oInputModel = this.getView().getModel("claimitem_input");
			const oPropertyModel = this.getView().getModel("claimitem_property");

			if (!oInputModel || !oPropertyModel) return;
			if (!oPropertyModel.getProperty("/rate_per_km/is_visible")) return;

			try {
				if (bRecalculateRate) {
					const oRatePerKm = await ClaimUtility.fetchRatePerKm();
					if (!oRatePerKm) return;

					oInputModel.setProperty("/claim_item/rate_per_km", oRatePerKm.id);
					oInputModel.setProperty("/claim_item/descr/rate_per_km", oRatePerKm.value);
				}

				if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.DARAT && !!oInputModel.getProperty("/claim_item/km") && !!oInputModel.getProperty("/claim_item/region")) {
					var oResult = await Utility.determineDaratAmount(this._oConstant.SubmissionTypePrefix.CLAIM);
					oInputModel.setProperty("/claim_item/descr/rate_per_km", oResult.fRate);
				}

				if (
					oPropertyModel.getProperty("/km/is_visible") &&
					oPropertyModel.getProperty("/rate_per_km/is_visible")
				) {
					let fKm = parseFloat(oInputModel.getProperty("/claim_item/km")) || 0;
					const fRate = parseFloat(oInputModel.getProperty("/claim_item/descr/rate_per_km")) || 0;
					const fToll = parseFloat(oInputModel.getProperty("/claim_item/toll")) || 0;

					if (oInputModel.getProperty("/claim_item/round_trip"))
					{
						fKm = fKm * 2;
					}
					let fAmount = fKm * fRate;

					if (oPropertyModel.getProperty("/toll/is_visible") && fToll > 0) {

						fAmount += fToll;
					}

					if(oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.DARAT ){
						if(fAmount < oResult.fAmount){
							MessageBox.alert(Utility.getText("d_i_minimum_amount", [oResult.fAmount]))
							oInputModel.setProperty("/claim_item/amount", oResult.fAmount);
						}else{
							oInputModel.setProperty("/claim_item/amount", fAmount);
						}
					}else{
						oInputModel.setProperty("/claim_item/amount", fAmount);
					}
					
					
				}
			} catch (oError) {
				console.error("Failed to calculate Rate Per KM", oError);
			}
		},
		_onChangeTravelers: function (oEvent) {
			if(!oEvent){return}
			var oInputModel = this.getView().getModel("claimitem_input");
			var oInput = oEvent.getSource();
			var iTravelers = parseInt(oInput.getValue(), 10);

			var iMaxFamilyMembers = parseInt(oInputModel.getProperty("/claim_item/no_of_family_member"), 10);

			oInput.setValueState("None");

			if (isNaN(iTravelers)) {
				oInput.setValueState("Error");
				oInput.setValueStateText("Please enter a valid number.");
				return;
			}

			if (iTravelers > iMaxFamilyMembers) {
				oInput.setValueState("Error");
				oInput.setValueStateText("Number of travelers cannot exceed the number of family members (" + iMaxFamilyMembers + ").");
				
			} else if (iTravelers < 1) {
				oInput.setValueState("Error");
				oInput.setValueStateText("Number of travelers must be at least 1.");
			}
		},
		onSelect_ClaimDetails_Region: async function () {
			var oInputModel = this.getView().getModel("claimitem_input");
			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PEM_PINDAH || 
				oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.PINDAH) {
				ClaimUtility.fetchPemberianPindahAmount();
			} else {
				await this._calculatePerDiem();
			}

			if(oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.DARAT){
				Utility.init(this.getOwnerComponent(), this.getView());
				var oResult = await Utility.determineDaratAmount(this._oConstant.SubmissionTypePrefix.CLAIM);
				if (oResult) {
					oInputModel.setProperty("/claim_item/descr/rate_per_km", oResult.fRate);
					if (!oInputModel.getProperty("/claim_item/km")){
						return;
					}
				}
			}
			await this._calculateRatePerKm(false);
		},

		onSelect_ClaimDetails_MarriageCategory: async function (){
			var oInputModel = this.getView().getModel("claimitem_input");
			if(oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.DARAT){
				if(oInputModel.getProperty("/claim_item/region") == null){
					return;
				}else{
					Utility.init(this.getOwnerComponent(), this.getView());
					var oResult = await Utility.determineDaratAmount(this._oConstant.SubmissionTypePrefix.CLAIM);
					if (oResult) {
						oInputModel.setProperty("/claim_item/descr/rate_per_km", oResult.fRate);
						await this._calculateRatePerKm(false);
						if (!oInputModel.getProperty("/claim_item/km")){
							return;
						}
					}
				}
			}
		},
		_calculatePerDiem: async function () {
			// check date/time values to be used for calculation
			//// Start Date/Start Time/End Date/End Time
			if (this.byId("datepicker_claimdetails_input_startdate").getVisible()) {
				var startDate = "datepicker_claimdetails_input_startdate";
				var startTime = "timepicker_claimdetails_input_starttime";
				var endDate = "datepicker_claimdetails_input_enddate";
				var endTime = "timepicker_claimdetails_input_endtime";

				//set date and time path value
				var sStartDateValue = "/claim_item/start_date";
				var sStartTimeValue = "/claim_item/start_time";
				var sEndDateValue = "/claim_item/end_date";
				var sEndTimeValue = "/claim_item/end_time";
			}
			else if (this.byId("datepicker_claimdetails_input_trip_start_date").getVisible()) {
				startDate = "datepicker_claimdetails_input_trip_start_date";
				startTime = "timepicker_claimdetails_input_trip_starttime";
				endDate = "datepicker_claimdetails_input_trip_end_date";
				endTime = "timepicker_claimdetails_input_trip_endtime";

				sStartDateValue = "/claim_item/trip_start_date";
				sStartTimeValue = "/claim_item/trip_start_time";
				sEndDateValue = "/claim_item/trip_end_date";
				sEndTimeValue = "/claim_item/trip_end_time";
			}
			else {
				return;
			}
			// check if required fields have values
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			var oClaimItemInputModel = this.getView().getModel("claimitem_input");
			if (
				(this.byId(startDate).getVisible() && !oClaimItemInputModel.getProperty(sStartDateValue)) ||
				(this.byId(startTime).getVisible() && !oClaimItemInputModel.getProperty(sStartTimeValue)) ||
				(this.byId(endDate).getVisible() && !oClaimItemInputModel.getProperty(sEndDateValue)) ||
				(this.byId(endTime).getVisible() && !oClaimItemInputModel.getProperty(sEndTimeValue))
			) {
				return;
			}

			// calculate travel duration (days/hours)
			var startDateValue = oClaimItemInputModel.getProperty(sStartDateValue);
			var endDateValue = oClaimItemInputModel.getProperty(sEndDateValue);
			var startTimeValue = this.byId(startTime).getDateValue();
			var endTimeValue = this.byId(endTime).getDateValue();
			var startDateUnix = new Date(startDateValue).valueOf();
			startDateUnix = startDateUnix + new Date(startTimeValue).valueOf();
			var endDateUnix = new Date(endDateValue).valueOf();
			endDateUnix = endDateUnix + new Date(endTimeValue).valueOf();

			if (this.byId("input_claimdetails_input_travel_duration_day").getVisible()) {
				var nTravelDays = Math.floor((endDateUnix - startDateUnix) / 86400000); // round down days
				oClaimItemInputModel.setProperty("/claim_item/travel_duration_day", nTravelDays);

				//set initial value for meal entitlement based on traveldays
				if (this.byId("input_claimdetails_input_entitled_breakfast").getVisible()) {
					oClaimItemInputModel.setProperty("/claim_item/entitled_breakfast", nTravelDays);

					var nEntBfast = nTravelDays - oClaimItemInputModel.getProperty("/claim_item/provided_breakfast");
					if (nEntBfast >= 0) {
						oClaimItemInputModel.setProperty("/claim_item/entitled_breakfast", nEntBfast);
					}
				}
				if (this.byId("input_claimdetails_input_entitled_lunch").getVisible()) {
					oClaimItemInputModel.setProperty("/claim_item/entitled_lunch", nTravelDays);

					var nEntLunch = nTravelDays - oClaimItemInputModel.getProperty("/claim_item/provided_lunch");
					if (!nEntLunch >= 0) {
						oClaimItemInputModel.setProperty("/claim_item/entitled_lunch", nEntLunch);
					}
				}
				if (this.byId("input_claimdetails_input_entitled_dinner").getVisible()) {
					oClaimItemInputModel.setProperty("/claim_item/entitled_dinner", nTravelDays);

					var nEntDinner = nTravelDays - oClaimItemInputModel.getProperty("/claim_item/provided_dinner");
					if (!nEntDinner >= 0) {
						oClaimItemInputModel.setProperty("/claim_item/entitled_dinner", nEntDinner);
					}

				}
			}
			if (this.byId("input_claimdetails_input_travel_duration_hour").getVisible()) {
				var nTravelHours = Math.floor((endDateUnix - startDateUnix) / 3600000); // round down hours
				var remainingHours = nTravelHours % 24;
				remainingHours = Math.max(0, remainingHours);
				oClaimItemInputModel.setProperty("/claim_item/travel_duration_hour", remainingHours);
			}

			this._updateEntitlementAmount(oClaimItemInputModel,oClaimSubmissionModel);
		},

		onChange_ClaimDetails_ProvidedMeals: async function () {
			var oClaimItemInputModel = this.getView().getModel("claimitem_input");
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			//check if there is any input, if yes then recalculate entitled meals 
			//breakfast meal entitlement
			if (oClaimItemInputModel.getProperty("/claim_item/provided_breakfast") != null ||
				oClaimItemInputModel.getProperty("/claim_item/provided_lunch") != null ||
				oClaimItemInputModel.getProperty("/claim_item/provided_dinner") != null
			) {			
				CustomValidator.init(this.getOwnerComponent(), this.getView());
				var bCanProceed = await CustomValidator.validate(this._oConstant.SubmissionTypePrefix.CLAIM);
				if (!bCanProceed) {
					return;
				}
					
				await this._calculatePerDiem();
			}

			this._updateEntitlementAmount(oClaimItemInputModel,oClaimSubmissionModel);
		},

		/**
		* On selecting location type, reset kilometer value if KWSP Office is selected
		* @public
		*/
		onSelect_ClaimDetails_LocationType: async function () {
			var oInputModel = this.getView().getModel("claimitem_input");
			var oPropertyModel = this.getView().getModel("claimitem_property");

			if (oInputModel.getProperty("/claim_item/location_type") === this._oConstant.LocationType.KWSP) {
				oInputModel.setProperty("/claim_item/km", null);
				oPropertyModel.setProperty("/to_location/is_visible", false);
				oPropertyModel.setProperty("/from_location/is_visible", false);
				await this.onChange_ClaimDetails_Kilometer();
			}
			//mine here
			if (oInputModel.getProperty("/claim_item/location_type") === this._oConstant.LocationType.OTHER) {
				oPropertyModel.setProperty("/to_location/is_visible", true);
				oPropertyModel.setProperty("/from_location/is_visible", true);
				await this.onChange_ClaimDetails_Kilometer();
			}
		},

		/**
		* On selecting From State, filter for values in From Location (Office)
		* @public
		*/
		onSelect_ClaimDetails_FromState: function (oEvent) {
			var oSelect = this.byId("select_claimdetails_input_from_location");
			var oBinding = oSelect?.getBinding("items");
			var oInputModel = this.getView().getModel("claimitem_input");
			if (!oBinding || !oInputModel) return;			

			// set description value
			var oSelectedItem = oEvent ? oEvent.getParameters().selectedItem : null;
			if (oSelectedItem) {
				// get claim type description
				oInputModel.setProperty("/claim_item/descr/from_state_id", oSelectedItem.getBindingContext("employee").getObject(this._oConstant.EntitiesFields.STATE_DESC));
			}
			else {
				oInputModel.setProperty("/claim_item/descr/from_state_id", null);
			}

			// set filters
			var sFromState = oInputModel.getProperty("/claim_item/from_state_id");
			var aFilters = [new Filter(this._oConstant.EntitiesFields.STATUS, FilterOperator.EQ, this._oConstant.Status.ACTIVE)];
			if (!!sFromState) { aFilters.push(new Filter(this._oConstant.EntitiesFields.STATE_ID, FilterOperator.EQ, sFromState)); }
			oBinding.filter(aFilters);

			// reset current value of From Location (Office)
			oInputModel.setProperty("/claim_item/from_location_office", null)
			this.onSelect_ClaimDetails_FromLocationOffice();
		},

		/**
		* On selecting From Location (Office), filter for values in 'To State'
		* @public
		*/
		onSelect_ClaimDetails_FromLocationOffice: function (oEvent) {
			var oSelect = this.byId("select_claimdetails_input_to_state_id");
			var oBinding = oSelect?.getBinding("items");
			var oInputModel = this.getView().getModel("claimitem_input");
			var oPropertyModel = this.getView().getModel("claimitem_property");
			if (!oBinding || !oInputModel) return;

			// set description value
			var oSelectedItem = oEvent ? oEvent.getParameters().selectedItem : null;
			if (oSelectedItem) {
				// get claim type description
				oInputModel.setProperty("/claim_item/descr/from_location_office", oSelectedItem.getBindingContext("employee").getObject(this._oConstant.EntitiesFields.LOCATION_DESC));
			}
			else {
				oInputModel.setProperty("/claim_item/descr/from_location_office", null);
			}

			// set filters
			var sFromState = oInputModel.getProperty("/claim_item/from_state_id");
			var sFromOffice = oInputModel.getProperty("/claim_item/from_location_office");
			var aFilters = [new Filter(this._oConstant.EntitiesFields.STATUS, FilterOperator.EQ, this._oConstant.Status.ACTIVE)];
			if (!!sFromState) { aFilters.push(new Filter(this._oConstant.EntitiesFields.FROM_STATE_ID, FilterOperator.EQ, sFromState)); }
			if (!!sFromOffice) { aFilters.push(new Filter(this._oConstant.EntitiesFields.FROM_LOCATION_ID, FilterOperator.EQ, sFromOffice)); }
			oBinding.filter(aFilters);

			// reset current value of To State
			oInputModel.setProperty("/claim_item/to_state_id", null)
			oPropertyModel.setProperty("/to_state_id/is_required", true)
			this.onSelect_ClaimDetails_ToState();
		},

		/**
		* On selecting 'To State', filter for values in To Location (Office)
		* @public
		*/
		onSelect_ClaimDetails_ToState: function (oEvent) {
			var oSelect = this.byId("select_claimdetails_input_to_location");
			var oBinding = oSelect?.getBinding("items");
			var oInputModel = this.getView().getModel("claimitem_input");
			if (!oBinding || !oInputModel) return;

			// set description value
			var oSelectedItem = oEvent ? oEvent.getParameters().selectedItem : null;
			if (oSelectedItem) {
				// get claim type description
				oInputModel.setProperty("/claim_item/descr/to_state_id", oSelectedItem.getBindingContext("employee_view").getObject(this._oConstant.EntitiesFields.TO_STATE_DESC));
			}
			else {
				oInputModel.setProperty("/claim_item/descr/to_state_id", null);
			}

			// set filters
			var sFromState = oInputModel.getProperty("/claim_item/from_state_id");
			var sFromOffice = oInputModel.getProperty("/claim_item/from_location_office");
			var sToState = oInputModel.getProperty("/claim_item/to_state_id");
			var aFilters = [new Filter(this._oConstant.EntitiesFields.STATUS, FilterOperator.EQ, this._oConstant.Status.ACTIVE)];
			if (!!sFromState) { aFilters.push(new Filter(this._oConstant.EntitiesFields.FROM_STATE_ID, FilterOperator.EQ, sFromState)); }
			if (!!sFromOffice) { aFilters.push(new Filter(this._oConstant.EntitiesFields.FROM_LOCATION_ID, FilterOperator.EQ, sFromOffice)); }
			if (!!sToState) { aFilters.push(new Filter(this._oConstant.EntitiesFields.TO_STATE_ID, FilterOperator.EQ, sToState)); }
			oBinding.filter(aFilters);

			// reset current value of To Location (Office)
			oInputModel.setProperty("/claim_item/to_location_office", null)
			this.onSelect_ClaimDetails_ToLocationOffice();
		},

		/**
		* On selecting To Location (Office), call function to determine office distance
		* @public
		*/
		onSelect_ClaimDetails_ToLocationOffice: async function (oEvent) {
			var oInputModel = this.getView().getModel("claimitem_input");
			if (!oInputModel) return;

			// set description value
			var oSelectedItem = oEvent ? oEvent.getParameters().selectedItem : null;
			if (oSelectedItem) {
				// get claim type description
				oInputModel.setProperty("/claim_item/descr/to_location_office", oSelectedItem.getBindingContext("employee_view").getObject(this._oConstant.EntitiesFields.TO_LOCATION_DESC));
			}
			else {
				oInputModel.setProperty("/claim_item/descr/to_location_office", null);
			}

			// get mileage
			oInputModel.setProperty("/claim_item/km", await Utility.determineOfficeMileage(
				oInputModel.getProperty("/claim_item/from_state_id"),
				oInputModel.getProperty("/claim_item/from_location_office"),
				oInputModel.getProperty("/claim_item/to_state_id"),
				oInputModel.getProperty("/claim_item/to_location_office")
			));
			await this.onChange_ClaimDetails_Kilometer();
		},

		/* =========================================================
		 * Mileage dialog (Fragment) — use a dedicated controller - For Google Maps
		 * ========================================================= */

		// <<< CHANGED: use the new lazy loader instead of openHelloDialog()
		onValueHelpRequest: function () {
			this._openMileageFrag(); // <<< CHANGED
		},

		// <<< ADDED: lazy-load the fragment + its own controller
		_openMileageFrag: function () {
			var oView = this.getView();

			if (!this._pMileageFrag) {
				this._pMileageFrag = new Promise((resolve, reject) => {

					// Load the fragment controller class dynamically
					sap.ui.require(["claima/controller/mileagecalculator.controller"], (MileageFragController) => {
						try {
							var oFragController = new MileageFragController();

							// Pass host + fragment id prefix so Fragment.byId works inside the controller
							oFragController.setHost(this, oView.getId());

							// Load the fragment with id prefix
							Fragment.load({
								id: oView.getId(), // critical for byId() to resolve fragment controls
								name: "claima.fragment.mileagecalculator",
								controller: oFragController
							}).then((oDialog) => {
								// models + lifecycle
								oView.addDependent(oDialog);

								// Submit handler: push values back to your form inputs
								oFragController.setSubmitHandler(function (res) {
									// res = { from, to, km }

									// Put into From input
									var oFrom = this.byId("input_claimdetails_input_from_location");
									if (oFrom) {
										oFrom.setValue(res.from);
										var b = oFrom.getBinding("value");
										if (b) {
											var m = b.getModel(), p = b.getPath();
											m.setProperty(p.charAt(0) === "/" ? p : "/" + p, res.from);
										}
									}

									// Put into To input
									var oTo = this.byId("input_claimdetails_input_to_location");
									if (oTo) {
										oTo.setValue(res.to);
										var b2 = oTo.getBinding("value");
										if (b2) {
											var m2 = b2.getModel(), p2 = b2.getPath();
											m2.setProperty(p2.charAt(0) === "/" ? p2 : "/" + p2, res.to);
										}
									}

									// Optional: push km to your model/input if you want
									var oKm = this.byId("input_claimdetails_input_km");
									if (oKm && oKm.getVisible()) { oKm.setValue(res.km); }

								}.bind(this));

								// Cache references
								this._mileageFrag = { controller: oFragController, dialog: oDialog };
								resolve(this._mileageFrag);
							}).catch(reject);

						} catch (e) {
							reject(e);
						}
					}, reject);
				});
			}

			// Open the dialog and prefill
			this._pMileageFrag.then(function (ctx) {
				var sFrom = (this.byId("input_claimdetails_input_from_location") && this.byId("input_claimdetails_input_from_location").getValue()) || "";
				var sTo = (this.byId("input_claimdetails_input_to_location") && this.byId("input_claimdetails_input_to_location").getValue()) || "";
				ctx.controller.prefill({ from: sFrom, to: sTo });
				ctx.controller.open();
			}.bind(this));
		},

		onCancel_ClaimDetails_Input: async function () {
			// show claim details screen
			var oPage = this.byId("page_claimsubmission");
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			var oClaimItemFragment = await this._getFormFragment("claimsubmission_claimdetails_input", true);
			if (oClaimItemFragment) {
				// disable item visibility
				this._setAllControlsVisible(false);
 
				// approver view changes
				if (oClaimSubmissionModel.getProperty("/view_only")) {
					if (this.byId("button_claimdetails_input_return").getVisible()) {
						this.byId("button_claimdetails_input_return").setVisible(false);
					}
					this._setAllControlsEditable(true);
				}
 
				// clear fileuploader fields
				for (let i = 1; i <= 2; i++) { // 2 attachment fields per claim item
					this.byId("fileuploader_claimdetails_input_attachment" + i)?.clear();
				}
 
				oPage.removeContent(oClaimItemFragment);
 
				await this._showInitFormFragment();
				await this._afterLoadFragments();
				// Reload when item cancellation
				await this._loadClaimById(oClaimSubmissionModel.getProperty("/claim_header/claim_id"));
				this._calculateCardAdvanceAmount();

				this._refreshActionState("SUMMARY");	// footer button control
			}
		},

		/**
		 * Handles the claim header actions triggered from the Claim Submission
		 * toolbar: Delete, Save Draft, and Submit Report.
		 *
		 * - **Delete** (`Claim_Action.DELETE`): calls the `cancelRecord` OData action
		 *   directly with the claim's ID and returns
		 * - **Save Draft / Submit Report**: first runs client-side checks, in order,
		 *   returning early on the first failure:
		 *     1. Items list not empty
		 *     2. Header field validation via `CustomValidator`
		 *     3. Total claim amount validity (NaN / sign, adjusted for travel claims
		 *        paid by corporate card)
		 *     4. Duplicate item check via `CustomDuplicationCheck`
		 *     5. Final amount to receive not negative (all claims, on Save Draft and Submit)
		 *     6. Corporate card advance amount not negative (on Submit only)
		 *
		 *   If all checks pass:
		 *     - **Save Draft** persists the current items via `_saveDraftItems`.
		 *     - **Submit Report** calls the `startWorkflow` OData action — a single
		 *       backend call that performs eligibility checking, budget locking,
		 *       workflow/approver determination, and entitlement updates. On failure,
		 *       shows an error message tailored to `oResponse.Area`
		 *       (`ELIGIBILITY_CHECKING`, `BUDGET_CHECKING`, or a generic fallback for
		 *       any other area) and returns without showing a success toast.
		 *
		 * On success, shows a toast with the relevant status message. Any thrown
		 * error during the try block surfaces as a `MessageBox.error`.
		 *
		 * @param {string} oAction - one of `this._oConstant.Claim_Action` (`DELETE`, `DRAFT`, `SUBMIT`)
		 * @returns {Promise<void|boolean>} resolves once the action completes and the
		 *          view has reloaded; resolves to `false` if a Delete action fails or
		 *          is declined by the backend
		 */
		_updateClaimSubmission: async function (oAction) {

			var oListBinding;
			var claimSaved;
			var bApproversDetermined = true;

			try {
				BusyIndicator.show();

				// get input model
				var oInputModel = this.getView().getModel("claimsubmission_input");
				var oHeader = oInputModel.getProperty("/claim_header") || [];
				var aItems = oInputModel.getProperty("/claim_items") || [];

				// flow delete action first to avoid any extra steps when cancel claim
				if (oAction === this._oConstant.Claim_Action.DELETE) {
					const oDeleteAction = this._oModel.bindContext("/cancelRecord(...)");
					oDeleteAction.setParameter("sRecordId", oHeader.claim_id)

					try {
						await oDeleteAction.execute();
						const bSuccess = await oDeleteAction.getBoundContext().requestObject();	

						if (!bSuccess) {								
							return false;
						}
					} catch (oError) {
						MessageBox.error(oError.message);
						return false;
					} finally {
						BusyIndicator.hide();
					}

					oMsg = Utility.getText("msg_claimsubmission_deleted");
				} else {

					// start with all logic steps that is not related to DELETE action
					if (aItems.length === 0) {
						MessageToast.show(Utility.getText("msg_claimdetails_no_items"));
						BusyIndicator.hide();
						return;
					}
					
					// Custom Validation Checking
					CustomValidator.init(this.getOwnerComponent(), this.getView());
					var bCanProceed = await CustomValidator.validate(this._oConstant.SubmissionTypePrefix.CLAIMHEADER);
					if (!bCanProceed) {
						return;
					}

					// Total Claim Amount Validation checking
					var sClaimTypeId = oInputModel.getProperty("/claim_header/claim_type_id");
					var sCardNo = oInputModel.getProperty("/claim_header/card_no");

					var bIsTravelClaimType = !!this._oConstant.TravelClaimType[sClaimTypeId];
					var bHasCard = !!sCardNo;
					var bTravelWithCard = bHasCard && bIsTravelClaimType;

					var nTotalClaimAmount = oInputModel.getProperty("/claim_header/total_claim_amount");
					if (aItems.length > 0 && (
						isNaN(nTotalClaimAmount) ||
						(bTravelWithCard ? nTotalClaimAmount < 0 : nTotalClaimAmount <= 0)
					)) {
						MessageBox.error(Utility.getText("msg_claimsubmission_invalid_amount"));
						BusyIndicator.hide();
						return;
					}

					// Duplication check 
					await CustomDuplicationCheck.CheckAllItems(this);
					// Cash Advance Repayment Validation checking
					if (Number(oInputModel.getProperty("/claim_header/final_amount_to_receive")) < 0) {
						MessageBox.error(Utility.getText(bTravelWithCard
							? "msg_error_cash_advance_repayment_and_potongan_elaun_prompt"
							: "msg_error_cash_advance_repayment_prompt"));
						BusyIndicator.hide();
						return;
					}

					// Corporate Credit Card Advance Validation checking
					if (oAction === this._oConstant.Claim_Action.SUBMIT &&
						Number(oInputModel.getProperty("/claim_header/card_advance_amount")) < 0) {
						MessageBox.error(Utility.getText("msg_error_negative_card_advance"));
						BusyIndicator.hide();
						return;
					}

					switch (oAction) {
						case this._oConstant.Claim_Action.DRAFT:
							var oMsg = Utility.getText("msg_claimsubmission_changed");
							await this._saveDraftItems();
							break;

						// Submit Report Button
						case this._oConstant.Claim_Action.SUBMIT:
							const oSubmitAction = this._oWorkflowModel.bindContext("/startWorkflow(...)");
							oSubmitAction.setParameter("id", oHeader.claim_id);
							oSubmitAction.setParameter("currentStatus", oHeader.status_id);

							try {
								await oSubmitAction.execute();
								const oResponse = await oSubmitAction.getBoundContext().requestObject();

								if (!oResponse.Success) {
									switch (oResponse.Area) {
										// Handling for eligibility checking error
										case this._oConstant.WorkflowArea.ELIGIBILITY_CHECKING:
											await EligibilityCheck.eligibilityHandling(this, oResponse.Message, this._oConstant.SubmissionTypePrefix.CLAIM);
											break;

										// Handling for Budget checking/locking error
										case this._oConstant.WorkflowArea.BUDGET_CHECKING:
											var aInsufficientItems = oResponse.Message.filter(r => r.STATUS === this._oConstant.BudgetCheckStatus.INSUFFICIENT);
											var aNotFoundItems = oResponse.Message.filter(r => r.STATUS === this._oConstant.BudgetCheckStatus.NOT_FOUND);

											var aMessages = [];
											if (aInsufficientItems.length > 0) {
												aMessages.push(Utility.getText("req_tm_w_inform_cc_owner", aInsufficientItems.map(r => r.CLAIM_TYPE_ITEM)));
											}
											if (aNotFoundItems.length > 0) {
												aMessages.push(Utility.getText("req_tm_w_budget_not_found", aNotFoundItems.map(r => r.CLAIM_TYPE_ITEM)));
											}

											if (aMessages.length > 0) {
												MessageBox.error(aMessages.join("\n"));
											}
											break;

										default:
											MessageBox.error(oResponse.Message);
											break;
									}
									return;
								} else {
									// workflow successfully determined and returns
									oMsg = Utility.getText("msg_claimsubmission_pending", []);
								}

							} catch (oError) {
								MessageBox.error(oError.message);
							}
							break;
					
						default:
							throw new Error("Invalid action selected: " + oAction);
							break;
					}
				}
				MessageToast.show(oMsg);
			} catch (oError) {
				// Sync with request error message
				MessageBox.error(`Submission failed: ${oError.message}`);
			} finally {
				BusyIndicator.hide();
				await this._loadClaimById(String(oHeader.claim_id));
				this._afterLoadFragments()
			}
		},

		_updateClaimItems: async function () {
			// get input model
			var oInputModel = this.getView().getModel("claimsubmission_input");
			var itemCountDb = 0;
			var delItems = [];
			BusyIndicator.show(0);

			var aItems = oInputModel.getProperty("/claim_items") || [];
			var oItem = oInputModel.getProperty("/claim_items") || [];


			// count existing items from database
			try {
				var oModel = this.getOwnerComponent().getModel();
				var oListBinding;

				oListBinding = oModel.bindList("/ZCLAIM_ITEM", null,
					[new Sorter("CLAIM_SUB_ID", false)],
					[new Filter({ path: "CLAIM_ID", operator: FilterOperator.EQ, value1: oInputModel.getProperty("/claim_header/claim_id") })],
					{
						$$ownRequest: true,
						$$groupId: "$auto",
						$$updateGroupId: "$auto"
					}
				);

				var aCtx = await oListBinding.requestContexts();
				itemCountDb = aCtx.length;

				if (itemCountDb > oInputModel.getProperty("/claim_items").length) {
					for (let i = oInputModel.getProperty("/claim_items").length; i < itemCountDb; i++) {
						var oCtx = aCtx[i];
						delItems.push(oCtx);
					}
				}
			} catch (e) {
				console.log(e.message);
				BusyIndicator.hide();
				return false;
			}

			// for each item to be saved
			oInputModel.getProperty("/claim_items").forEach(async (claim_item, i) => {
				try {
					oModel = this.getOwnerComponent().getModel();
					oListBinding = null;

									// set body for update
					var oBody = new JSONModel({
						CLAIM_ID: claim_item.claim_id,
						CLAIM_SUB_ID: claim_item.claim_sub_id,
						CLAIM_TYPE_ITEM_ID: claim_item.claim_type_item_id,
						PERCENTAGE_COMPENSATION: this._nonNan(parseFloat(claim_item.percentage_compensation)).toFixed(2),
						ACCOUNT_NO: claim_item.account_no,
						AMOUNT: this._nonNan(parseFloat(claim_item.amount)).toFixed(2),
						ATTACHMENT_FILE_1: claim_item.attachment_file_1,
						ATTACHMENT_FILE_2: claim_item.attachment_file_2,
						BILL_NO: claim_item.bill_no,
						BILL_DATE: DateUtility.getHanaDate(claim_item.bill_date),
						CLAIM_CATEGORY: claim_item.claim_category,
						COUNTRY: claim_item.country,
						DISCLAIMER: claim_item.disclaimer,
						START_DATE: DateUtility.getHanaDate(claim_item.start_date),
						END_DATE: DateUtility.getHanaDate(claim_item.end_date),
						START_TIME: DateUtility.getHanaTime(claim_item.start_time),
						END_TIME: DateUtility.getHanaTime(claim_item.end_time),
						FLIGHT_CLASS: claim_item.flight_class,
						FROM_LOCATION: claim_item.from_location,
						FROM_LOCATION_OFFICE: claim_item.from_location_office,
						KM: this._nonNan(parseFloat(claim_item.km)).toFixed(2),
						LOCATION: claim_item.location,
						LOCATION_TYPE: claim_item.location_type,
						LODGING_CATEGORY: claim_item.lodging_category,
						LODGING_ADDRESS: claim_item.lodging_address,
						MARRIAGE_CATEGORY: claim_item.marriage_category,
						AREA: claim_item.area,
						NO_OF_FAMILY_MEMBER: claim_item.no_of_family_member,
						PARKING: this._nonNan(parseFloat(claim_item.parking)),
						PHONE_NO: claim_item.phone_no,
						RATE_PER_KM: claim_item.rate_per_km,
						RECEIPT_DATE: DateUtility.getHanaDate(claim_item.receipt_date),
						RECEIPT_NUMBER: claim_item.receipt_number,
						REMARK: claim_item.remark,
						ROOM_TYPE: claim_item.room_type,
						REGION: claim_item.region,
						FROM_STATE_ID: claim_item.from_state_id,
						TO_STATE_ID: claim_item.to_state_id,
						TO_LOCATION: claim_item.to_location,
						TO_LOCATION_OFFICE: claim_item.to_location_office,
						TOLL: this._nonNan(parseFloat(claim_item.toll)).toFixed(2),
						TOTAL_EXP_AMOUNT: this._nonNan(parseFloat(claim_item.total_exp_amount)).toFixed(2),
						VEHICLE_TYPE: claim_item.vehicle_type,
						VEHICLE_FARE: claim_item.vehicle_fare,
						TRIP_START_DATE: DateUtility.getHanaDate(claim_item.trip_start_date),
						TRIP_END_DATE: DateUtility.getHanaDate(claim_item.trip_end_date),
						EVENT_START_DATE: DateUtility.getHanaDate(claim_item.event_start_date),
						EVENT_END_DATE: DateUtility.getHanaDate(claim_item.event_end_date),
						TRAVEL_DURATION_DAY: this._nonNan(parseFloat(claim_item.travel_duration_day)).toFixed(1),
						TRAVEL_DURATION_HOUR: this._nonNan(parseFloat(claim_item.travel_duration_hour)).toFixed(1),
						PROVIDED_BREAKFAST: claim_item.provided_breakfast?.toString(),
						PROVIDED_LUNCH: claim_item.provided_lunch?.toString(),
						PROVIDED_DINNER: claim_item.provided_dinner?.toString(),
						ENTITLED_BREAKFAST: claim_item.entitled_breakfast?.toString(),
						ENTITLED_LUNCH: claim_item.entitled_lunch?.toString(),
						ENTITLED_DINNER: claim_item.entitled_dinner?.toString(),
						DAILY_ALLOWANCE: claim_item.dailyallowance?.toString(),
						ANGGOTA_ID: claim_item.anggota_id,
						ANGGOTA_NAME: claim_item.anggota_name,
						DEPENDENT: claim_item.dependent,
						DEPENDENT_NAME: claim_item.dependent_name,
						TYPE_OF_PROFESSIONAL_BODY: claim_item.type_of_professional_body,
						DISCLAIMER_GALAKAN: claim_item.disclaimer_galakan,
						TRANSFER_DATE: DateUtility.getHanaDate(claim_item.transfer_date),
						NO_OF_DAYS: claim_item.no_of_days,
						FAMILY_COUNT: claim_item.family_count,
						FUNERAL_TRANSPORTATION: claim_item.funeral_transportation,
						ROUND_TRIP: claim_item.round_trip,
						TRIP_END_TIME: DateUtility.getHanaTime(claim_item.trip_end_time),
						TRIP_START_TIME: DateUtility.getHanaTime(claim_item.trip_start_time),
						COST_CENTER: (claim_item.claim_type_item_id === this._oConstant.ClaimTypeItem.PERSONAL_EXP) ? null : claim_item.cost_center,
						GL_ACCOUNT: (claim_item.claim_type_item_id === this._oConstant.ClaimTypeItem.PERSONAL_EXP) ? this._oConstant.StatementDueInfo.GL_CODE : claim_item.gl_account,
						MATERIAL_CODE: (claim_item.claim_type_item_id === this._oConstant.ClaimTypeItem.PERSONAL_EXP) ? null : claim_item.material_code,						
						VEHICLE_OWNERSHIP_ID: claim_item.vehicle_ownership_id,
						ACTUAL_AMOUNT: this._nonNan(parseFloat(claim_item.actual_amount)).toFixed(2),
						ARRIVAL_TIME: claim_item.arrival_time ? new Date(claim_item.arrival_time).toISOString() : null,
						CLAIM_TYPE_ID: claim_item.claim_type_id,
						COURSE_TITLE: claim_item.course_title,
						CURRENCY_AMOUNT: this._nonNan(parseFloat(claim_item.currency_amount)).toFixed(2),
						CURRENCY_CODE: claim_item.currency_code,
						CURRENCY_RATE: this._nonNan(parseFloat(claim_item.currency_rate)).toFixed(2),
						DEPARTURE_TIME: claim_item.departure_time ? new Date(claim_item.departure_time).toISOString() : null,
						EMP_ID: claim_item.emp_id,
						FARE_TYPE_ID: claim_item.fare_type_id,
						INSURANCE_CERT_END_DATE: DateUtility.getHanaDate(claim_item.insurance_cert_end_date),
						INSURANCE_CERT_START_DATE: DateUtility.getHanaDate(claim_item.insurance_cert_start_date),
						INSURANCE_PACKAGE_ID: claim_item.insurance_package_id,
						INSURANCE_PROVIDER_ID: claim_item.insurance_provider_id,
						INSURANCE_PROVIDER_NAME: claim_item.insurance_provider_name,
						INSURANCE_PURCHASE_DATE: DateUtility.getHanaDate(claim_item.insurance_purchase_date),
						METER_CUBE_ACTUAL: this._nonNan(parseFloat(claim_item.meter_cube_actual)).toFixed(2),
						METER_CUBE_ENTITLED: this._nonNan(parseFloat(claim_item.meter_cube_entitled)).toFixed(2),
						MOBILE_CATEGORY_PURPOSE_ID: claim_item.mobile_category_purpose_id,
						NEED_FOREIGN_CURRENCY: claim_item.need_foreign_currency,
						POLICY_NUMBER: claim_item.policy_number,
						PURPOSE: claim_item.purpose,
						REQUEST_APPROVAL_AMOUNT: claim_item.request_approval_amount,
						STUDY_LEVELS_ID: claim_item.study_levels_id,
						TRAVEL_DAYS_ID: claim_item.travel_days_id,
						VEHICLE_CLASS_ID: claim_item.vehicle_class_id,
						DAILY_ALLOWANCE: this._nonNan(parseInt(claim_item.daily_allowance)),
						TIPS: this._nonNan(parseInt(claim_item.tips)),
						EXCLUDE_TIPS: claim_item.exclude_tips,
						TOTAL_TRAVELLER: claim_item.number_of_travellers,
						ATTACHMENT_FILE_3: claim_item.attachment_file_3,
						ATTACHMENT_FILE_4: claim_item.attachment_file_4,
						POLICY_YEAR: claim_item.policy_year
					});

					if (i >= itemCountDb) {
						// create new item
						oListBinding = oModel.bindList("/ZCLAIM_ITEM");
						var oContext = oListBinding.create(oBody.getData());
						await oContext.created().then(() => {
							console.log("New claim item created");
						});
					}
					else {
						oListBinding = oModel.bindList("/ZCLAIM_ITEM", null, null,
							[
								new Filter({ path: "CLAIM_ID", operator: FilterOperator.EQ, value1: claim_item.claim_id }),
								new Filter({ path: "CLAIM_SUB_ID", operator: FilterOperator.EQ, value1: claim_item.claim_sub_id })
							],
							{
								$$ownRequest: true,
								$$groupId: "$auto",
								$$updateGroupId: "$auto"
							}
						);

						aCtx = await oListBinding.requestContexts(0, 1);
						oCtx = aCtx[0];

						if (!oCtx) {
							throw new Error("Claim item not found in database");
						}
						else {
							for (const [key, value] of Object.entries(oBody.getData())) {
								oCtx.setProperty(key, value);
							}

							await oModel.submitBatch("$auto");

							console.log("Save claim item success");
						}
					}
				} catch (e) {
					console.error(e.message);
					BusyIndicator.hide();
					return false;
				}
			})

			// for each item to be deleted
			delItems.forEach(async (claim_item) => {
				try {
					oModel = this.getOwnerComponent().getModel();
					oListBinding = null;

					oListBinding = oModel.bindList("/ZCLAIM_ITEM", null, null,
						[
							new Filter({ path: "CLAIM_ID", operator: FilterOperator.EQ, value1: claim_item.getProperty("CLAIM_ID") }),
							new Filter({ path: "CLAIM_SUB_ID", operator: FilterOperator.EQ, value1: claim_item.getProperty("CLAIM_SUB_ID") })
						],
						{
							$$ownRequest: true,
							$$groupId: "$auto",
							$$updateGroupId: "$auto"
						}
					);

					var aCtx = await oListBinding.requestContexts(0, 1);
					var oCtx = aCtx[0];

					await oCtx.delete().then(function () {
						console.log("Claim item deleted");
					});
				} catch (e) {
					console.error(e.message);
					BusyIndicator.hide();
					return false;
				}
			})
			BusyIndicator.hide();
			return true;
		},

		_getJsonDate: function (iDate) {
			if (iDate) {
				var oDate = new Date(iDate);
				var oDateString = oDate.toLocaleString('default', { day: '2-digit' }) + " " + oDate.toLocaleString('default', { month: 'short' }) + " " + oDate.toLocaleString('default', { year: 'numeric' });
				return oDateString;
			} else {
				return null;
			}
		},

		_nonNan: function (iNumber) {
			if (isNaN(iNumber)) {
				return 0;
			} else {
				return iNumber;
			}
		},

		_getCurrentReportNumber: async function (rangeId) {
			const oModel = this.getOwnerComponent().getModel();

			try {
				var oListBinding = oModel.bindList(
					"/ZNUM_RANGE",
					null,
					null,
					[
						new Filter({
							path: "RANGE_ID",
							operator: FilterOperator.EQ,
							value1: rangeId
						})
					],
					{
						$$ownRequest: true,
						$$groupId: "$auto",
						$select: "RANGE_ID,CURRENT,PREFIX"
					}
				);

				var aCtx = await oListBinding.requestContexts(0, 1);
				var oCtx = aCtx[0];

				if (!oCtx) {
					throw new Error(`${rangeId} not found`);
				}

				var row = oCtx.getObject();
				if (row.CURRENT == null) {
					throw new Error(`${rangeId} missing CURRENT`);
				}

				var current = Number(row.CURRENT);
				var prefix = row.PREFIX;
				var yy = String(new Date().getFullYear()).slice(-2);
				var result = `${prefix}${yy}${String(current).padStart(9, "0")}`;

				// verify result is not in database
				oListBinding = oModel.bindList(
					"/ZCLAIM_HEADER",
					null,
					null,
					[
						new Filter({
							path: "CLAIM_ID",
							operator: FilterOperator.EQ,
							value1: result
						})
					],
					{
						$$ownRequest: true,
						$$groupId: "$auto",
					}
				);

				aCtx = await oListBinding.requestContexts(0, 1);
				oCtx = aCtx[0];

				if (!oCtx) {
					return { result, current };
				}
				else {
					row = oCtx.getObject();
					console.warn(`Claim ${oCtx.CLAIM_ID} already exists in DB, please update number range`);
					result = 'X';
					return { result, current };
				}

			} catch (err) {
				MessageBox.error(Utility.getText("msg_claimsubmission_numrange_err", [err]));
				return null;
			}
		},

		_updateCurrentReportNumber: async function (rangeId, currentNumber) {
			const oModel = this.getOwnerComponent().getModel();
			const sGroup = "updateRange";
			const nextNumber = currentNumber + 1;

			try {
				const sPath = `/ZNUM_RANGE(RANGE_ID='${rangeId.replace(/'/g, "''")}')`;

				const oCtxBinding = oModel.bindContext(sPath, null, {
					$$updateGroupId: sGroup,
					$$ownRequest: true
				});

				await oCtxBinding.requestObject();
				const oCtx = oCtxBinding.getBoundContext();

				oCtx.setProperty("CURRENT", String(nextNumber));

				await oModel.submitBatch(sGroup);

				return { CURRENT: nextNumber };

			} catch (err) {
				console.error("Error updating number range:", err);
				return null;
			}
		},

		onBack_ClaimSubmission: async function (oSideNav) {
			// remove approval log fragment
			if (await this._getFormFragment("approval_log")) {
				this._setApprovalLog(false);
			}

			// reset UI from approver page
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			if (oClaimSubmissionModel.getProperty("/view_only")) {
				this._setClaimItemTableToolbar(true);
			}
			if (oSideNav) {
				return;
			} else {
				this._refreshActionState("SUMMARY");
				if (oClaimSubmissionModel.getProperty("/is_approver")) {

					// return to approver screen
					this.getMyApproverPAReq();
					this.getMyApproverClaim();

					var oRouter = this.getOwnerComponent().getRouter();
					this._onNavBack();
				}
				else {
					this._onNavBack();
				}
			}
		},

		_newDialog: function (oTitle, oContent, onPress, onPressE) {
			this.oDialog = new Dialog({
				title: oTitle,
				type: "Message",
				state: "None",
				content: [new Label({ text: oContent })],
				beginButton: new Button({
					type: "Emphasized",
					text: Utility.getText("button_claimsummary_confirm"),
					press: async function () {
						this.oDialog.close();
						await onPress();
					}.bind(this)
				}),
				endButton: new Button({
					text: Utility.getText("button_claimsummary_cancel"),
					press: async function () {
						this.oDialog.close();
						if (onPressE) {
							await onPressE();
						}
					}.bind(this)
				})
			});
			this.oDialog.open();
		},

		/**
		 * @private
		 * Filters the Fare Type dropdown based on Claim Type and Claim Item.
		 */
		_filterFareType: function () {
			var oSelect = this.byId("select_claimdetails_input_fare_type_id");
			var oBinding = oSelect.getBinding("items");
			if (!oBinding) return;
			var oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			var oInputModel = this.getView().getModel("claimitem_input");
			var sClaimTypeId = oClaimSubmissionModel.getProperty("/claim_header/claim_type_id");
			var sClaimTypeItemId = oInputModel.getProperty("/claim_item/claim_type_item_id");
			var aFareTypeFilters = ClaimUtility.getFareTypeFilters(sClaimTypeId, sClaimTypeItemId);
			oBinding.filter(aFareTypeFilters);
		},

		// App Control Visibility
		getFieldVisibility_ClaimTypeItem: async function () {
			const oModel = this.getOwnerComponent().getModel();
			var oInputModel = this.getView().getModel("claimitem_input");

			const sClaimTypeItemFromModel = oInputModel.getProperty("/claim_item/claim_type_item_id");
			const sClaimTypeID = oInputModel.getProperty("/claim_item/claim_type_id");
			const sClaim_type_item = sClaimTypeItemFromModel;

			if (!sClaim_type_item) {
				console.warn("No claim item found.");
				return;
			}

			const oListBinding = oModel.bindList("/ZDB_STRUCTURE", null, null, [
				new Filter("SUBMISSION_TYPE", FilterOperator.EQ, this._oConstant.ClaimFieldVisibilityConfig.SUBMISSION_TYPE),
				new Filter("COMPONENT_LEVEL", FilterOperator.EQ, this._oConstant.ClaimFieldVisibilityConfig.ITEM),
				new Filter("CLAIM_TYPE_ITEM_ID", FilterOperator.EQ, sClaim_type_item),
				new Filter("CLAIM_TYPE_ID", FilterOperator.EQ, sClaimTypeID)
			]);

			try {
				const aCtx = await oListBinding.requestContexts(0, Infinity);

				if (!aCtx || aCtx.length === 0) {
					MessageBox.error("No configuration rows for claim type item:", sClaim_type_item);
					this._setAllControlsVisible(false);
					return;
				}
				const oData = aCtx[0].getObject();

				const aFieldIds = oData.FIELD.replace(/[\[\]\s]/g, "").split(",");

				if (aFieldIds != []) {
					oInputModel.setProperty("/screen_array", aFieldIds);
					this._setAllControlsVisible(false);
					aFieldIds.forEach(id => {
						const control = this._resolveControl(id, "claimsubmission_claimdetails_input");
						if (control && typeof control.setVisible === "function") {
							control.setVisible(true);
						} else {
							console.warn("Control not found or not visible-capable:", id);
						}
					});
				} else {
					this._setAllControlsVisible(false);
				}

				// ------------------------------------------------------------------
				// Force correct visibility of state & location fields on screen load
				// ------------------------------------------------------------------
				var sLocType = oInputModel.getProperty("/claim_item/location_type");
				if (sLocType === this._oConstant.LocationType.OTHER) { // Other Location

					// Show Other Location fields (Input)
					this.byId("input_claimdetails_input_from_location")?.setVisible(true);
					this.byId("input_claimdetails_input_to_location")?.setVisible(true);

					// Hide KWSP Office fields (Select)
					this.byId("select_claimdetails_input_from_state_id")?.setVisible(false);
					this.byId("select_claimdetails_input_to_state_id")?.setVisible(false);
					this.byId("select_claimdetails_input_from_location")?.setVisible(false);
					this.byId("select_claimdetails_input_to_location")?.setVisible(false);
				}
				else if (sLocType === this._oConstant.LocationType.KWSP) { // KWSP Office	

					// Hide Other Location fields (Input)
					this.byId("input_claimdetails_input_from_location")?.setVisible(false);
					this.byId("input_claimdetails_input_to_location")?.setVisible(false);

					// Show KWSP Office fields (Select)
					this.byId("select_claimdetails_input_from_state_id")?.setVisible(true);
					this.byId("select_claimdetails_input_to_state_id")?.setVisible(true);
					this.byId("select_claimdetails_input_from_location")?.setVisible(true);
					this.byId("select_claimdetails_input_to_location")?.setVisible(true);
				}

			} catch (err) {
				console.error("OData bindList failed:", err);
			}
		},

		_setAllControlsVisible: function (bVisible) {
			const aControlIds = [
				"select_claimdetails_input_special_to_state_id",
				"select_claimdetails_input_depedent_or_anggota",
				"select_claimdetails_input_type_of_professional_body",
				"input_claimdetails_input_policy_number",
				"select_claimdetails_input_funeral_transportation",
				"input_claimdetails_input_actual_amount",
				"input_claimdetails_input_subsidised_amount",
				"input_claimdetails_input_request_approval_amount",
				"input_claimdetails_input_amount",
				"input_claimdetails_input_percentage_compensation",
				"input_claimdetails_input_course_title",
				"select_claimdetails_input_study_levels_id",
				"input_claimdetails_input_receipt_number",
				"datepicker_claimdetails_input_receipt_date",
				"input_claimdetails_input_purpose",
				"datepicker_claimdetails_input_startdate",
				"timepicker_claimdetails_input_starttime",
				"datepicker_claimdetails_input_enddate",
				"timepicker_claimdetails_input_endtime",
				"select_claimdetails_input_insurance_provider_id",
				"select_claimdetails_input_insurance_package_id",
				"datepicker_claimdetails_input_insurance_purchase_date",
				"datepicker_claimdetails_input_insurance_cert_start_date",
				"datepicker_claimdetails_input_insurance_cert_end_date",
				"input_claimdetails_input_no_of_days",
				"select_claimdetails_input_vehicle_type",
				"select_claimdetails_input_vehicle_ownership_id",
				"input_claimdetails_input_km",
				"input_claimdetails_input_rate_per_km",
				"select_claimdetails_input_fare_type_id",
				"select_claimdetails_input_flight_class",
				"input_claimdetails_input_toll",
				"checkbox_claimdetails_input_parking",
				"select_claimdetails_input_location_type",
				"select_claimdetails_input_from_state_id",
				"input_claimdetails_input_from_location",
				"select_claimdetails_input_to_state_id",
				"input_claimdetails_input_to_location",
				"select_claimdetails_input_room_type",
				"select_claimdetails_input_country",
				"input_claimdetails_input_location",
				"checkbox_claimdetails_input_needforeigncurrency",
				"datepicker_claimdetails_input_trip_start_date",
				"timepicker_claimdetails_input_trip_starttime",
				"timepicker_claimdetails_input_departure_time",
				"datepicker_claimdetails_input_trip_end_date",
				"timepicker_claimdetails_input_trip_endtime",
				"timepicker_claimdetails_input_arrival_time",
				"input_claimdetails_input_travel_duration_day",
				"input_claimdetails_input_travel_duration_hour",
				"input_claimdetails_input_provided_breakfast",
				"input_claimdetails_input_provided_lunch",
				"input_claimdetails_input_provided_dinner",
				"input_claimdetails_input_entitled_breakfast",
				"input_claimdetails_input_entitled_lunch",
				"input_claimdetails_input_entitled_dinner",
				"input_claimdetails_input_lodging_address",
				"select_claimdetails_input_region",
				"select_claimdetails_input_area",
				"select_claimdetails_input_lodging_category",
				"input_claimdetails_input_no_of_family_member",
				"select_claimdetails_input_claim_category",
				"select_claimdetails_input_mobile_category_purpose_id",
				"input_claimdetails_input_bill_no",
				"input_claimdetails_input_account_no",
				"datepicker_claimdetails_input_bill_date",
				"input_claimdetails_input_phone_no",
				"checkbox_claimdetails_input_disclaimer",
				"input_claimdetails_input_remarks",
				"fileuploader_claimdetails_input_attachment_file_1",
				"fileuploader_claimdetails_input_attachment_file_2",
				"select_claimdetails__input_marriagecategory",
				"input_claimdetails_meter_cube_actual",
				"input_claimdetails_meter_cube",
				"input_claimdetails_input_tips",
				"input_claimdetails_input_exclude_tips",
				"input_claimdetails_input_daily_allowance",
				"input_claimdetails_input_number_of_travellers",
				"select_claimdetails_input_insurance_medical_provider_id",
				"datepicker_claimdetails_input_insurance_policy_start_date",
				"datepicker_claimdetails_input_insurance_policy_end_date",
				"fileuploader_claimdetails_input_attachment_file_3",
				"fileuploader_claimdetails_input_attachment_file_4",
				"label_past_year_policy",
				"text_past_year_policy",
				"label_current_year_policy",
				"text_current_year_policy",
				"label_future_year_policy",
				"text_future_year_policy"
			];

			aControlIds.forEach(id => {
				const c = this._resolveControl(id, "claimsubmission_claimdetails_input");
				if (c && typeof c.setVisible === "function") {
					c.setVisible(bVisible);
				}
			});
		},

		_resolveControl: function (sId, sFragmentId) {
			let c = this.getView().byId(sId);
			if (c) return c;

			if (sFragmentId) {
				c = Fragment.byId(this.getView().createId(sFragmentId), sId);
				if (c) return c;

				c = Fragment.byId(sFragmentId, sId);
				if (c) return c;
			}

			return sap.ui.getCore().byId(`${sFragmentId}--${sId}`) || sap.ui.getCore().byId(sId);
		},

		_getFieldEditable_ClaimTypeItem: async function () {
			const oModel = this.getOwnerComponent().getModel();
			var oInputModel = this.getView().getModel("claimitem_input");
			var screenArray = oInputModel.getProperty("/screen_array");

			if (!screenArray) {
				console.warn("Cannot get field list for claim items");
				this._setAllControlsEditable(true);
				return;
			}
			else {
				this._setAllControlsEditable(true);
				this.byId("select_claimdetails_input_claimitem").setEditable(false);
				screenArray.forEach(id => {
					const control = this._resolveControl(id, "claimsubmission_claimdetails_input");

					if (!control) {
						console.warn("Control not found or not editable-capable:", id);
						return;
					}

					if (control && typeof control.setEditable === "function") {
						control.setEditable(false);
					} else if (control.getMetadata().getName().includes("FileUploader")) {
						control.setVisible(false);
					} else if (control instanceof sap.ui.mdc.Field) {
						control.setEditMode("Display");
					}
				});
			}
		},

		_setAllControlsEditable: function (bEditable) {
			const aControlIds = [
				"select_claimdetails_input_special_to_state_id",
				"select_claimdetails_input_depedent_or_anggota",
				"select_claimdetails_input_type_of_professional_body",
				"input_claimdetails_input_policy_number",
				"select_claimdetails_input_funeral_transportation",
				"input_claimdetails_input_actual_amount",
				"input_claimdetails_input_request_approval_amount",
				"input_claimdetails_input_amount",
				"input_claimdetails_input_percentage_compensation",
				"input_claimdetails_input_course_title",
				"select_claimdetails_input_study_levels_id",
				"input_claimdetails_input_receipt_number",
				"datepicker_claimdetails_input_receipt_date",
				"input_claimdetails_input_purpose",
				"datepicker_claimdetails_input_startdate",
				"timepicker_claimdetails_input_starttime",
				"datepicker_claimdetails_input_enddate",
				"timepicker_claimdetails_input_endtime",
				"select_claimdetails_input_insurance_provider_id",
				"select_claimdetails_input_insurance_package_id",
				"datepicker_claimdetails_input_insurance_purchase_date",
				"datepicker_claimdetails_input_insurance_cert_start_date",
				"datepicker_claimdetails_input_insurance_cert_end_date",
				"input_claimdetails_input_no_of_days",
				"select_claimdetails_input_vehicle_type",
				"select_claimdetails_input_vehicle_ownership_id",
				"input_claimdetails_input_km",
				"select_claimdetails_input_fare_type_id",
				"select_claimdetails_input_flight_class",
				"input_claimdetails_input_toll",
				"checkbox_claimdetails_input_parking",
				"select_claimdetails_input_location_type",
				"select_claimdetails_input_from_state_id",
				"input_claimdetails_input_from_location",
				"select_claimdetails_input_to_state_id",
				"input_claimdetails_input_to_location",
				"select_claimdetails_input_room_type",
				"select_claimdetails_input_country",
				"input_claimdetails_input_location",
				"datepicker_claimdetails_input_trip_start_date",
				"timepicker_claimdetails_input_trip_starttime",
				"timepicker_claimdetails_input_departure_time",
				"datepicker_claimdetails_input_trip_end_date",
				"timepicker_claimdetails_input_trip_endtime",
				"timepicker_claimdetails_input_arrival_time",
				"input_claimdetails_input_provided_breakfast",
				"input_claimdetails_input_provided_lunch",
				"input_claimdetails_input_provided_dinner",
				"input_claimdetails_input_lodging_address",
				"select_claimdetails_input_region",
				"select_claimdetails_input_area",
				"select_claimdetails_input_lodging_category",
				"input_claimdetails_input_no_of_family_member",
				"select_claimdetails_input_claim_category",
				"select_claimdetails_input_mobile_category_purpose_id",
				"input_claimdetails_input_bill_no",
				"input_claimdetails_input_account_no",
				"datepicker_claimdetails_input_bill_date",
				"input_claimdetails_input_phone_no",
				"checkbox_claimdetails_input_disclaimer",
				"input_claimdetails_input_remarks",
				"fileuploader_claimdetails_input_attachment_file_1",
				"fileuploader_claimdetails_input_attachment_file_2",
				"select_claimdetails__input_marriagecategory",
				"input_claimdetails_meter_cube_actual",
				"input_claimdetails_meter_cube",
				"input_claimdetails_input_tips",
				"input_claimdetails_input_exclude_tips",
				"input_claimdetails_input_daily_allowance",
				"input_claimdetails_input_number_of_travellers",
				"fileuploader_claimdetails_input_attachment_file_3",
				"datepicker_claimdetails_input_insurance_policy_start_date",
				"datepicker_claimdetails_input_insurance_policy_end_date",
				"fileuploader_claimdetails_input_attachment_file_4"
			];

			aControlIds.forEach(id => {
				const c = this._resolveControl(id, "claimsubmission_claimdetails_input");
				if (c && typeof c.setEditable === "function") {
					c.setEditable(bEditable);
				} else {
					console.warn("Control not found or not editable-capable:", id);
				}
			});
		},

		//Aiman Salim - 08/03/2026 - MyApproval - My Pre-Approval Request Status;
		getMyApproverPAReq: async function () {
			const oReq = this.getOwnerComponent().getModel("request_status");
			const oEmployeeViewModel = this.getOwnerComponent().getModel("employee_view");
			var sUserId = this._oSessionModel.getProperty("/userId");

			const oApproverOrSub = new Filter({
				filters: [
					new Filter("APPROVER_ID", FilterOperator.EQ, sUserId),
					new Filter("SUBSTITUTE_APPROVER_ID", FilterOperator.EQ, sUserId)
				],
				and: false // OR condition between the two
			});

			const oStatusPending = new Filter(
				"STATUS",
				FilterOperator.EQ,
				this._oConstant.ClaimStatus.PENDING_APPROVAL // use the exact code/value your backend expects
			);
			// (APPROVER = id OR SUBSTITUTE_APPROVER = id) AND STATUS = 'PENDING APPROVAL'
			const oCombined = new Filter({
				filters: [oApproverOrSub, oStatusPending],
				and: true // AND between groups
			});


			const oListBinding = oEmployeeViewModel.bindList("/ZEMP_APPROVER_REQUEST_DETAILS", undefined,
				[new Sorter("STATUS", true)], // desc by STATUS
				[oCombined],
				{
					$$ownRequest: true,
					$$groupId: "$auto",
					$$updateGroupId: "$auto",
					$count: true
				}
			);

			try {
				const aCtx = await oListBinding.requestContexts(0, Infinity);
				const a = aCtx.map((ctx) => ctx.getObject());

				a.forEach((it) => {
					if (it.PREAPPROVAL_AMOUNT == null) it.PREAPPROVAL_AMOUNT = 0.0;
				});

				oReq.setProperty("/req_header_list", a);
				oReq.setProperty("/req_header_count", a.length);

				return a;
			} catch (err) {
				console.error("OData bindList failed:", err);
				oReq.setProperty("/req_header_list", []);
				oReq.setProperty("/req_header_count", 0);
				return [];
			}
		},
		//MyApproval - Claim Request Status;

		getMyApproverClaim: async function () {
			const oReq = this.getOwnerComponent().getModel("claim_status");
			const oEmployeeViewModel = this.getOwnerComponent().getModel("employee_view");
			var sUserId = this._oSessionModel.getProperty("/userId");

			const oApproverOrSub = new Filter({
				filters: [
					new Filter("APPROVER_ID", FilterOperator.EQ, sUserId),
					new Filter("SUBSTITUTE_APPROVER_ID", FilterOperator.EQ, sUserId)
				],
				and: false // OR condition between the two
			});

			const oStatusPending = new Filter(
				"STATUS",
				FilterOperator.EQ,
				this._oConstant.ClaimStatus.PENDING_APPROVAL // use the exact code/value your backend expects
			);
			// (APPROVER = id OR SUBSTITUTE_APPROVER = id) AND STATUS = 'PENDING APPROVAL'
			const oCombined = new Filter({
				filters: [oApproverOrSub, oStatusPending],
				and: true // AND between groups
			});
			const oListBinding = oEmployeeViewModel.bindList("/ZEMP_APPROVER_CLAIM_DETAILS", undefined,
				[new Sorter("STATUS", true)], // desc by STATUS
				[oCombined],

				{
					$$ownRequest: true,
					$$groupId: "$auto",
					$$updateGroupId: "$auto",
					$count: true
				}
			);

			try {
				const aCtx = await oListBinding.requestContexts(0, Infinity);
				const a = aCtx.map((ctx) => ctx.getObject());

				a.forEach((it) => {
					if (it.TOTAL_CLAIM_AMOUNT == null) it.TOTAL_CLAIM_AMOUNT = 0.0;
				});

				oReq.setProperty("/claim_header_list", a);
				oReq.setProperty("/claim_header_count", a.length);

				return a;
			} catch (err) {
				console.error("OData bindList failed:", err);
				oReq.setProperty("/claim_header_list", []);
				oReq.setProperty("/claim_header_count", 0);
				return [];
			}
		},

		/**
		 * Event handler for change of currency rate input
		 * Recalculates claim amount based on currency rate and currency amount
		 * @public
		 */
		onChange_ClaimDetails_CurrencyRate: function () {
			var oInputModel = this.getView().getModel("claimitem_input");
			if (this.byId("input_claimdetails_input_currency_rate").getVisible() && !!oInputModel.getProperty("/claim_item/currency_rate")) {
				var nAmountMYR = (oInputModel.getProperty("/claim_item/currency_rate") * oInputModel.getProperty("/claim_item/currency_amount"));
				oInputModel.setProperty("/claim_item/amount", nAmountMYR);
			}
		},

		/**
		 * Updates entitlement amount and related claim item fields 
		 * @public
		 * @param {sap.ui.model.json.JSONModel} oClaimInputModel name of the resource
		 */
		_updateEntitlementAmount: function (oClaimItemInputModel,oClaimSubmissionModel) {
			BusyIndicator.show(0);

			return ClaimUtility.fetchAndApplyEntitlement.bind(this)(oClaimItemInputModel,oClaimSubmissionModel).then(oResult => {
				if (!oResult || oResult.amount === 0) {
					//reset amount
					oClaimItemInputModel.setProperty("/claim_item/amount", 0);
					oClaimItemInputModel.setProperty("/claim_item/tips", 0);
					oClaimItemInputModel.setProperty("/claim_item/daily_allowance", 0);
					if (this.byId("select_claimdetails_input_currency_code").getVisible()) {
						oClaimItemInputModel.setProperty("/claim_item/currency_amount", 0);
					}
					MessageToast.show(Utility.getText("msg_claim_no_entitlement"));
					return;
				}

				if (this.byId("select_claimdetails_input_currency_code").getVisible()) {
					oClaimItemInputModel.setProperty("/claim_item/currency_code", oResult.currency_code);
					oClaimItemInputModel.setProperty("/claim_item/currency_amount", oResult.amount);
					//initialize amount(MYR)
					oClaimItemInputModel.setProperty("/claim_item/amount", 0);
					if (this.byId("input_claimdetails_input_currency_rate").getVisible() && !!oClaimItemInputModel.getProperty("/claim_item/currency_rate")) {
						var nAmountMYR = (oClaimItemInputModel.getProperty("/claim_item/currency_rate") * oClaimItemInputModel.getProperty("/claim_item/currency_amount"));
						oClaimItemInputModel.setProperty("/claim_item/amount", nAmountMYR);
					}
				} else if (this.byId("input_claimdetails_input_amount").getVisible()) {
					oClaimItemInputModel.setProperty("/claim_item/amount", oResult.amount);
				}

				if (this.byId("input_claimdetails_input_tips").getVisible()) {
					oClaimItemInputModel.setProperty("/claim_item/tips", oResult.tips_amount);
				}

				if (this.byId("input_claimdetails_input_daily_allowance").getVisible()) {
					oClaimItemInputModel.setProperty(
						"/claim_item/daily_allowance",
						oResult.daily_allowance
					);
				}

			}).catch(err => {
				MessageBox.error(
					Utility.getText("msg_claimdetails_input_entmeals_err", [err])
				);
			}).finally(() => BusyIndicator.hide());
		},

		_saveDraftItems: async function () {
			const oClaimSubmissionModel = this.getView().getModel("claimsubmission_input");
			const aItems = oClaimSubmissionModel.getProperty("/claim_items") || [];
			const oInputItemModel = this.getView().getModel("claimitem_input");

			CustomValidator.init(this.getOwnerComponent(), this.getView());
			var bCanProceed = await CustomValidator.validate(this._oConstant.SubmissionTypePrefix.CLAIMHEADER);
			if (!bCanProceed) {
				return;
			}

			for (let item of aItems) {

				if (item.is_new === true) {
					oInputItemModel.setProperty("/claim_item", {});
					oInputItemModel.setProperty("/claim_item", item);
					oInputItemModel.setProperty("/claim_item/claim_id",
						oClaimSubmissionModel.getProperty("/claim_header/claim_id")
					);
					oInputItemModel.setProperty("/claim_item/is_new", true);
					await this._saveClaimItem();
					item.is_new = false;
				}
			}
			oClaimSubmissionModel.setProperty("/claim_items", aItems);
		},
		_resetClaimItemInputs: async function (oInputModel) {
			Object.keys(oInputModel.getData().claim_item).forEach((sKey) => {
				if (sKey === this._oConstant.ExcludeField.CLAIM_TYPE_ID ||
					sKey === this._oConstant.ExcludeField.CLAIM_TYPE_ITEM_ID ||
					sKey === this._oConstant.ExcludeField.CLAIM_ID ||
					sKey === this._oConstant.ExcludeField.CLAIM_SUB_ID ||
					sKey === this._oConstant.ExcludeField.DESCR ||
					sKey === this._oConstant.ExcludeField.GL_ACCOUNT ||
					sKey === this._oConstant.ExcludeField.COST_CENTER ||
					sKey === this._oConstant.ExcludeField.IS_NEW
				) {
					return;
				}
				oInputModel.setProperty(`/claim_item/${sKey}`, null);
			})

			Object.keys(oInputModel.getData().claim_item.descr).forEach((sKey) => {
				if (sKey === this._oConstant.ExcludeField.CLAIM_TYPE_ID ||
					sKey === this._oConstant.ExcludeField.CLAIM_TYPE_ITEM_ID
				) {
					return;
				}
				oInputModel.setProperty(`/claim_item/descr/${sKey}`, null);
			})
		},
		onSelect_ExcludeTips: async function () {
			await this._calculatePerDiem();
		},
		/**
		 * Handles checkbox toggle for Need Foreign Currency. Resets value to null when tick
		 *
		 * @param {sap.ui.base.Event} oEvent - Checkbox event
		 */
		onNeedForeignCurrencySelected: function (oEvent) {
			var bIsSelected = oEvent.getParameter("selected");
			var oCurrencyRate = this.byId("input_claimdetails_input_currency_rate");
			var oCurrencyAmount = this.byId("input_claimdetails_input_currency_amount");
			var oClaimItemModel = this.getView().getModel("claimitem_input");

			if (bIsSelected) {
				this.onChange_ClaimDetails_CurrencyRate();
			}
			else {
				oClaimItemModel.setProperty("/claim_item/currency_code", null);
				oClaimItemModel.setProperty("/claim_item/currency_rate", null);
				oClaimItemModel.setProperty("/claim_item/currency_amount", null);

				oCurrencyRate.setValueState(ValueState.None);
				oCurrencyAmount.setValueState(ValueState.None);
			}
		},
		/**
		 * Handles recalculation check for 3% Matawang. 
		 * Private function
		 * @param {sap.ui.model.json.JSONModel} oSubmissionModel - Claim Submission model
		 * @param {sap.ui.model.json.JSONModel} oInputModel - Claim Input model
		 * @param {function} fnSaveClaimItem - Function to Create or Update item
		 */
		_recalculateMatawangIfNeeded: async function (
			oSubmissionModel,
			oInputModel,
			fnSaveClaimItem
		) {
			const aClaimItems = oSubmissionModel.getProperty("/claim_items") || [];
			const iMatawangIndex = aClaimItems.findIndex(
				oItem =>
					oItem.claim_type_item_id ===
					this._oConstant.ClaimTypeItem.MATAWANG
			);
			if (iMatawangIndex === -1) {
				return false;
			}
			const bIsSaveFlow = !!oInputModel?.getProperty("/claim_item/claim_sub_id");
			const bIsEditingMatawang =
				bIsSaveFlow &&
				oInputModel.getProperty("/claim_item/claim_type_item_id") ===
				this._oConstant.ClaimTypeItem.MATAWANG;

			if (bIsEditingMatawang) {
				return false;
			}
			await ClaimUtility.calculateMatawangAmount();
			await ClaimUtility.saveUpdatedMatawang(fnSaveClaimItem);
			return true;
		},
		/**
		 * Handles checkbox toggle for RoundTrip function. Multiply by 2 if active.
		 *
		 * @param {sap.ui.base.Event} oEvent - Checkbox event
		 */
		onSelectRoundTrip: async function (oEvent) {
			const oResult = await Utility.handleRoundTrip(
				Constants.SubmissionTypePrefix.CLAIM,
				oEvent
			);

			if (oResult?.error) {
				MessageBox.error(oResult.error);
				return;
			}

			if (oResult?.km !== undefined) {
				this.getView().getModel("claimitem_input").setProperty("/claim_item/rtkm", oResult.km);
			}
			// claim-specific recalculation
			this._calculateRatePerKm(false);
		},

		onSelect_ClaimDetails_FuneralTransport: async function(oEvent){
			const sFuneralTransportID = oEvent.getParameter("selectedItem").getKey();
			const oInputModel = this.getView().getModel("claimitem_input");
			
			if(oInputModel.getProperty("/claim_item/funeral_transportation") == this._oConstant.TransportPassing.DALAM_STESEN ||
				oInputModel.getProperty("/claim_item/funeral_transportation") == this._oConstant.TransportPassing.LUAR_STESEN){
				const iEligibleAmount = await ClaimUtility.getFuneralTransportEligibleAmount(sFuneralTransportID, oInputModel.getProperty("/claim_item/claim_type_item_id"), oInputModel.getProperty("/claim_item/claim_type_id"));
				if(!iEligibleAmount) return;
				oInputModel.setProperty("/claim_item/amount", iEligibleAmount);
			}else{
				oInputModel.setProperty("/claim_item/amount", 0)
			}

		},

		onSelect_ClaimDetails_DependentOrAnggota: async function(oEvent) {
			const oInputModel = this.getView().getModel("claimitem_input");
			oInputModel.setProperty("/claim_item/anggota_id", null);
			oInputModel.setProperty("/claim_item/anggota_name", null);
			oInputModel.setProperty("/claim_item/dependent", null);

			if (oInputModel.getProperty("/claim_item/claim_type_item_id") === this._oConstant.ClaimTypeItem.KEMATIAN) {
				var fEligibleAmount = await ClaimUtility.getBantuanKematianEligibleAmount(oInputModel.getProperty("/claim_item/dependent_type"));
				oInputModel.setProperty("/claim_item/amount", fEligibleAmount);
			}
		},
		formatCCCSwitchVisibility: function (sCardNo, sClaimTypeItemId) {
			if (!sCardNo || !sClaimTypeItemId) return false;
			return !!this._oConstant.TravelClaimItems[sClaimTypeItemId];
		},

		/**
		 * For CCC (corporate credit card) holders creating/editing a CASH_REPAY
		 * claim item: if there is no cash advance on the claim, the item must be
		 * charged to the CCC, so the switch defaults to ON and is locked. If a
		 * cash advance amount is present, the user is free to decide, so the
		 * switch is left editable (existing value, if any, is preserved).
		 */
		_applyCashRepayCCCDefault: function (oInputModel, oClaimSubmissionModel) {
			var oPropertyModel = this.getView().getModel("claimitem_property");
			if (!oInputModel || !oClaimSubmissionModel || !oPropertyModel) return;

			var sClaimTypeItemId = oInputModel.getProperty("/claim_item/claim_type_item_id");
			if (sClaimTypeItemId !== this._oConstant.ClaimTypeItem.CASH_REPAY) {
				return;
			}

			// Only applies to corporate credit card holders
			var sCardNo = oClaimSubmissionModel.getProperty("/claim_header/card_no");
			if (!sCardNo) {
				return;
			}

			var nCashAdvanceAmount = Math.max(0, Number(oClaimSubmissionModel.getProperty("/claim_header/cash_advance_amount")) || 0);

			if (nCashAdvanceAmount === 0) {
				// No cash advance to draw from - must be charged to CCC, and locked
				oInputModel.setProperty("/claim_item/charged_to_ccc", true);
				oPropertyModel.setProperty("/charged_to_ccc/is_editable", false);
			} else {
				// Cash advance available - let the user decide
				oPropertyModel.setProperty("/charged_to_ccc/is_editable", true);
			}
		},

		_calculateClaimTotal: function () {
			var oInputModel = this.getView().getModel("claimsubmission_input");
			var aClaimItems = oInputModel.getProperty("/claim_items") || [];
			var sClaimTypeId = oInputModel.getProperty("/claim_header/claim_type_id");
			var sCardNo = oInputModel.getProperty("/claim_header/card_no");

			var nCashAdvAmt = Math.max(0, Number(oInputModel.getProperty("/claim_header/cash_advance_amount")) || 0);

			var bIsTravelClaimType = !!this._oConstant.TravelClaimType[sClaimTypeId];
			var bHasCard = !!sCardNo;

			if (bHasCard && bIsTravelClaimType) {
				// Total Claim Amount includes everything except POTONGAN_ELAUN and
				// CASH_REPAY, regardless of charged_to_ccc status.
				var nTotal = aClaimItems
					.filter((it) => it.claim_type_item_id !== this._oConstant.ClaimTypeItem.POTONGAN_ELAUN
						&& it.claim_type_item_id !== this._oConstant.ClaimTypeItem.CASH_REPAY)
					.reduce((s, it) => s + (Number(it.amount) || 0), 0);

				// Final Amount to Receive additionally excludes charged_to_ccc items
				// (they get settled via the corporate card advance offset instead) -
				// but not POTONGAN_ELAUN or CASH_REPAY again, since both are already
				// excluded from nTotal above and would otherwise be double-subtracted.
				var nChargedToCccExcludingPotongan = aClaimItems
					.filter((it) => it.charged_to_ccc
						&& it.claim_type_item_id !== this._oConstant.ClaimTypeItem.POTONGAN_ELAUN
						&& it.claim_type_item_id !== this._oConstant.ClaimTypeItem.CASH_REPAY)
					.reduce((s, it) => s + (Number(it.amount) || 0), 0);

				// POTONGAN_ELAUN items are actively deducted from Final Amount to
				// Receive, on top of already being excluded from nTotal above.
				var nPotonganElaunAmt = aClaimItems
					.filter((it) => it.claim_type_item_id === this._oConstant.ClaimTypeItem.POTONGAN_ELAUN)
					.reduce((s, it) => s + (Number(it.amount) || 0), 0);

				// Rounded to 2dp so the on-screen preview matches what the backend
				// will persist, avoiding floating-point residue in the subtraction.
				var nNewTotal = Math.round((nTotal - nChargedToCccExcludingPotongan - nCashAdvAmt - nPotonganElaunAmt) * 100) / 100;
				oInputModel.setProperty("/claim_header/total_claim_amount", nTotal);
				oInputModel.setProperty("/claim_header/final_amount_to_receive", nNewTotal);
				return;
			}

			// Default: not a travel claim with a corporate credit card - simple
			// sum of everything, minus cash advance only.
			var nTotalDefault = aClaimItems.reduce((s, it) => s + (Number(it.amount) || 0), 0);
			var nFinal = Math.round((nTotalDefault - nCashAdvAmt) * 100) / 100;
			oInputModel.setProperty("/claim_header/total_claim_amount", nTotalDefault);
			oInputModel.setProperty("/claim_header/final_amount_to_receive", nFinal);
		},

		_calculateCardAdvanceAmount: function () {
			var oInputModel = this.getView().getModel("claimsubmission_input");

			if (oInputModel.getProperty("/view_only")) {
				return;
			}

			var aClaimItems = oInputModel.getProperty("/claim_items") || [];
			var nOriginalCardAdvanceAmount = Number(oInputModel.getProperty("/claim_header/original_card_advance_amount")) || 0;

			var nChargedToCccAmount = aClaimItems
				.filter((it) => it.charged_to_ccc)
				.reduce((s, it) => s + (Number(it.amount) || 0), 0);

			var nCardAdvanceAmount = nOriginalCardAdvanceAmount - nChargedToCccAmount;

			oInputModel.setProperty("/claim_header/card_advance_amount", nCardAdvanceAmount);
		},

		onChange_Dependent: async function (oEvent) {

			const oInputModel = this.getView().getModel("claimitem_input");
			const sDependentNo = oEvent.getSource().getSelectedKey();

			const oAction = this._oModel.bindContext("/getDependentNationalId(...)");

			oAction.setParameter("dependentNo", sDependentNo);

			await oAction.execute();

			const sNationalId = oAction.getBoundContext().getObject().value;

			oInputModel.setProperty("/claim_item/dependent_national_id",sNationalId);

			await this._refreshPolicyInfo();
		},

		onChange_PolicyStartDate: async function (oEvent) {

			const oInputModel = this.getView().getModel("claimitem_input");
			const dPolicyStartDate = oEvent.getSource().getDateValue();
			const sPolicyYear = dPolicyStartDate
				? dPolicyStartDate.getFullYear().toString()
				: null;

			oInputModel.setProperty("/claim_item/policy_year",sPolicyYear);
			await this._refreshPolicyInfo();
		},

		_refreshPolicyInfo: async function () {

			const oInputModel = this.getView().getModel("claimitem_input");
			const sNationalId = oInputModel.getProperty("/claim_item/dependent_national_id");

			if (!sNationalId) {
				return;
			}

			try {

				const oAction = this._oModel.bindContext("/getPolicyInfo(...)");

				oAction.setParameter(
					"dependentNationalId",
					sNationalId
				);

				await oAction.execute();

				const oResult = oAction.getBoundContext().getObject();
				const aPolicies = oResult.policies || [];
				const iCurrentYear = new Date().getFullYear();

				const oPrevious = aPolicies.find(
					p => Number(p.POLICY_YEAR) === iCurrentYear - 1
				);

				const oCurrent = aPolicies.find(
					p => Number(p.POLICY_YEAR) === iCurrentYear
				);

				const oNext = aPolicies.find(
					p => Number(p.POLICY_YEAR) === iCurrentYear + 1
				);

				oInputModel.setProperty(
					"/claim_item/previous_policy_number",
					oPrevious
						? `${oPrevious.POLICY_YEAR} - ${oPrevious.POLICY_NUMBER}`
						: null
				);

				oInputModel.setProperty(
					"/claim_item/current_policy_number",
					oCurrent
						? `${oCurrent.POLICY_YEAR} - ${oCurrent.POLICY_NUMBER}`
						: null
				);

				oInputModel.setProperty(
					"/claim_item/next_policy_number",
					oNext
						? `${oNext.POLICY_YEAR} - ${oNext.POLICY_NUMBER}`
						: null
				);

			} catch (error) {

			}
		},


		onMedicalPolicyYes: function (oEvent) {

			var oDialog = oEvent.getSource().getParent();

			oDialog.close();

			if (!this._oMedicalDeclarationDialog) {

				Fragment.load({
					name: "claima.fragment.medicaldeclaration",
					id: "medicalDeclarationDialogFrag",
					controller: this
				}).then(function (oMedicalDeclarationDialog) {

					this._oMedicalDeclarationDialog = oMedicalDeclarationDialog;

					this.getView().addDependent(this._oMedicalDeclarationDialog);

					this._oMedicalDeclarationDialog.open();

				}.bind(this));

			} else {

				this._oMedicalDeclarationDialog.open();

			}
		},

		onMedicalPolicyNo: function (oEvent) {

			var oDialog = oEvent.getSource().getParent();

			oDialog.close();

			this._bSkipMedicalPolicyDialog = true;

			this.onSelect_ClaimDetails_ClaimItem({
				getParameters: () => ({
					selectedItem: this._oPendingClaimItem
				})
			});
		},

		onMedicalDeclarationClose: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();

			oDialog.close();

			var oInputModel = this.getView().getModel("claimitem_input");

			oInputModel.setProperty("/claim_item/claim_type_item_id", "");

			this.byId("select_claimdetails_input_claimitem")
				?.setSelectedKey("");

			this._resetClaimItemInputs(oInputModel);
		},

		_refreshActionState: function (sScreen) {
			var oHeader = this.getView().getModel("claimsubmission_input").getProperty("/claim_header");
			ActionStateService.apply(ActionStateService.buildContext({
				screen:        sScreen,
				header:        oHeader,
				itemCount:	   this.getView().getModel("claimsubmission_input").getProperty("/claim_items")?.length,
				items:         this.getView().getModel("claimsubmission_input").getProperty("/claim_items"),
				currentUserId: this.getOwnerComponent().getModel("session").getProperty("/userId"),
				approvalList:  this._oApprovalLog.getProperty("/approval"),
			}));
		}
	});
});