sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("claima.controller.dashboard", {
        onInit() {
            var that = this;
        }
    });
});